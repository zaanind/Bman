<?php
// acc_category_db - WordPress table creation script

function zn_acc_categories_create_table() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $full_table_name = $wpdb->prefix . 'zn_acc_categories';
    
    $sql = "CREATE TABLE $full_table_name (
        id INT AUTO_INCREMENT,
        category TEXT,
        PRIMARY KEY (id),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // Add version option to track updates
   // add_option('zn_acc_categories_db_version', '1.0');
}


zn_acc_categories_create_table();

?>
