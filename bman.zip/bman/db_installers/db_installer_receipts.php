<?php
// met_requests_db - WordPress table creation script


 function create_receipts_tablekk(){
    global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_receipts';
	$sql = "CREATE TABLE " . $table_name . " (
        r_id INT AUTO_INCREMENT,
        customer_id INT,
        order_id INT,
        payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
		items TEXT,
        n_payment FLOAT,
		g_subtotal FLOAT,
        g_total_amount FLOAT,
		g_discount FLOAT,
		g_grand_total FLOAT,
		g_tax FLOAT,
		g_paid FLOAT,
		g_due FLOAT,
        payment_method TEXT,
		payment_states TEXT,
		payment_location TEXT,
        notes TEXT,
        terms TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (r_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
 }



create_receipts_tablekk();

?>
