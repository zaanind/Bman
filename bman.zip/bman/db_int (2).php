<?php
    
    
function create_ar_table(){

	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'zn_system_ar';
	$sql = "CREATE TABLE " . $table_name . " (
	   id int auto_increment,
       date DATETIME DEFAULT CURRENT_TIMESTAMP,
   	   type text,
	   ref_no text,
	   payee text,
       paid FLOAT,
       due FLOAT,
       amount FLOAT,
       PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);


}

 function create_orders_table(){
    global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'pos_system_orders';
	$sql = "CREATE TABLE " . $table_name . " (
        order_id INT AUTO_INCREMENT,
        customer_id INT,
        order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        order_status TEXT,
		notes TEXT,
		type TEXT,
		items TEXT,
		g_subtotal FLOAT,
        g_total_amount FLOAT,
		g_discount FLOAT,
		g_grand_total FLOAT,
		g_tax FLOAT,
		g_paid FLOAT,
		g_due FLOAT,
        shipping_address TEXT,
        billing_address TEXT,
        payment_method TEXT,
		payment_states TEXT,
		payment_location TEXT,
        barcode TEXT,
        terms TEXT,
        ar_id TEXT,
        attr TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (order_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
 }
	


 function create_invoice_table(){
    global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_invoices';
	$sql = "CREATE TABLE " . $table_name . " (
        order_id INT AUTO_INCREMENT,
        customer_id INT,
        order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        order_status TEXT,
		notes TEXT,
		items TEXT,
		g_subtotal FLOAT,
        g_total_amount FLOAT,
		g_discount FLOAT,
		g_grand_total FLOAT,
		g_tax FLOAT,
		g_paid FLOAT,
		g_due FLOAT,
        shipping_address TEXT,
        billing_address TEXT,
        payment_method TEXT,
		payment_states TEXT,
		payment_location TEXT,
        terms TEXT,
        ar_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (order_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
 }
	



function create_customers_table(){
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'pos_system_customers';
    
	$sql = "CREATE TABLE " . $table_name . " (
        customer_id INT AUTO_INCREMENT,
        name text,
        email text UNIQUE,
        phone_number text,
        address text,
		total_spent text,
		type text,
		image text,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (customer_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function create_meta_table(){
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'zn_system_meta';
	$sql = "CREATE TABLE " . $table_name . " (
	   id int auto_increment,
   	   meta_key text,
	   meta_value text,
       PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
	
}





function create_stock_categories_table(){
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'pos_system_categories';
	$sql = "CREATE TABLE " . $table_name . " (
	   category_id int auto_increment,
   	   category_name text,
	   category_description text,
	   parent_category_id int,
	   created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
	   updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
       PRIMARY KEY  (category_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
	
}


function create_stock_brands_table(){
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'pos_system_brands';
	$sql = "CREATE TABLE " . $table_name . " (
	   brand_id int auto_increment,
   	   brand_name text,
	   brand_description text,
       PRIMARY KEY  (brand_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
	
}

function create_suppliers_table(){
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'pos_system_suppliers';
	$sql = "CREATE TABLE " . $table_name . " (
	   supplier_id int auto_increment,
   	   supplier_name text,
	   type text,
	   contact_name text,
	   contact_phone text,
	   contact_email text,
	   address text,
	   created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
       updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
       PRIMARY KEY  (supplier_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
	
}






  function create_projects_table() {
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_projects';
    
    $sql = "CREATE TABLE " . $table_name . " (
        project_id int auto_increment,
        order_id int,
		project_title text,
		type text,
		quotation text,
		project_description text,
        project_status text,
		project_location text,
		project_employees text,
		project_meterials text,
		project_company_tools text,
		project_gallery text, 
        project_cost text,  
        project_credit text,
		customer text,
        barcode text,
        attrs text,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (project_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
  
  }

function create_boq_table() {
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_boq';
    
    $sql = "CREATE TABLE " . $table_name . " (
        boq_id int auto_increment,
        order_id int,
        customer_id INT,
		project_id text,
		q_id text,
        pr_id text,
		description text,
		title text,
        location text,
		items text,
        g_subtotal FLOAT,
        g_total_amount FLOAT,
		g_discount FLOAT,
		g_grand_total FLOAT,
		g_tax FLOAT,
		g_paid FLOAT,
		g_due FLOAT,
		attrs text,
        profit FLOAT,
        billing_address text,
        shipping_address text,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (boq_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
  
  }



function create_stocks_table() {
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_stocks';
    
    $sql = "CREATE TABLE " . $table_name . " (
        stock_id int auto_increment,
        order_id int,
		project_id text,
        item_id text,
        item_name text,
        brand_name TEXT,
        supplier text,
        product_description TEXT,
        category TEXT,
        price FLOAT,
        states TEXT,
        type text,
        exp_date DATETIME,
		quantity INT,
        image TEXT,
        location text,
        is_request_passed INT,
		attrs text,
        location_history text,
        checked_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (stock_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
  
}



function create_quotation_table() {
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_quotations';
    
    $sql = "CREATE TABLE " . $table_name . " (
        q_id int auto_increment,
        project_id int,
        order_id int,
		type text,
		title text,
		description text,
        status text,  
		customer text,
        boq_id int,
		items text,
        g_subtotal FLOAT,
        g_total_amount FLOAT,
		g_discount FLOAT,
        g_paid FLOAT,
        g_due FLOAT,
		g_grand_total FLOAT,
		g_tax FLOAT,
        terms text,
        notes text,
        billing_address text,
        shipping_address text,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (q_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
  
  }


  
function create_prs_table() {
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_prs';
    
    $sql = "CREATE TABLE " . $table_name . " (
        pr_id int auto_increment,
        q_id int,
        order_id int,
		type text,
		title text,
		description text,
        status text,  
		customer text,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (pr_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
  
  }






function create_products_table(){
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'pos_system_inventory_products';
	$sql = "CREATE TABLE " . $table_name . " (
	   product_id INT auto_increment,
   	   product_name TEXT,
	   brand_name TEXT,
	   supplier text,
	   product_description TEXT,
	   category TEXT,
	   price FLOAT,
	   states TEXT,
	   quantity INT,
	   image TEXT,
       barcode TEXT,
	   attrs TEXT,
       exp_date DATETIME,
	   created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
       updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
       PRIMARY KEY  (product_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
	
}







function create_company_tools_table(){
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'zn_inventory_comp_tools';
	$sql = "CREATE TABLE " . $table_name . " (
	   tool_id INT auto_increment,
   	   tool_name text,
	   tool_type text,
	   tool_locations text,
	   brand_name text,
	   supplier text,
	   tool_description text,
	   category text,
	   price FLOAT,
	   states text,
	   quantity INT,
	   attrs text,
       location_history text,
       location text,
       barcode text,
	   image text,
       exp_date DATETIME,
	   created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
       updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
       PRIMARY KEY  (tool_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
	
}

function create_company_meterials_table(){
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'zn_inventory_comp_meterials';
	$sql = "CREATE TABLE " . $table_name . " (
	   item_id INT auto_increment,
   	   item_name TEXT,
	   type text,
	   color text,
	   brand_name TEXT,
	   supplier text,
	   item_description TEXT,
	   category TEXT,
	   price FLOAT,
	   states TEXT,
	   quantity INT,
       barcode text,
       location TEXT,
	   attrs text,
       location_history text,
	   image text,
       exp_date DATETIME,
	   created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
       updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
       PRIMARY KEY  (item_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
	
}



function create_employee_table() { //--------------------------- old -----------------------
	global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_employee';
    
    $sql = "CREATE TABLE " . $table_name . " (
        employee_id int,
		name text,
		phone_number text,
		address text,
        role text,
        salary text,
		departmet text,
		email text,
		branch text,
		image text,
		location text,
		company_loan text,
		company_tools text,
        last_payment text,
        next_payment text,
        payment_type text,
		attrs text,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (employee_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
  
  }
  



/**
 * 2) Create the Departments table
 */
function create_departments_table() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_departments';

    $sql = "CREATE TABLE $table_name (
        department_id INT NOT NULL AUTO_INCREMENT,
        department_name TEXT,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (department_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * 3) Create the Locations table (branches, head offices, project sites, etc.)
 */
function create_locations_table() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_locations';

    $sql = "CREATE TABLE $table_name (
        location_id INT NOT NULL AUTO_INCREMENT,
        location_name TEXT,
        location_type TEXT,
        address TEXT,
        phone TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (location_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * 4) Create the Employee Salaries table (handles daily/weekly/monthly pay)
 */
function create_employee_salaries_table() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_employee_salaries';

    $sql = "CREATE TABLE $table_name (
        salary_id INT(11) NOT NULL AUTO_INCREMENT,
        employee_id INT(11) NOT NULL,
        salary_type TEXT,         -- e.g. 'daily', 'weekly', 'monthly'
        amount DECIMAL(10,2) NOT NULL,   -- numeric pay amount
        currency TEXT,           -- optional currency code (USD, GBP, etc.)
        effective_from DATE,      -- start date for this salary
        effective_to DATE,        -- end date (NULL if still active)
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (salary_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}


function create_attendance_table() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_attendance';

    $sql = "CREATE TABLE $table_name (
        attendance_id INT NOT NULL AUTO_INCREMENT,
        employee_id INT NOT NULL,
        check_in DATETIME DEFAULT NULL,
        check_out DATETIME DEFAULT NULL,
        work_hours DECIMAL(10,2) DEFAULT NULL,
        status TEXT DEFAULT 'Absent', 
        remarks TEXT DEFAULT NULL,
        verification TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (attendance_id)
       
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}



function create_credits_table() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_credits';

    $sql = "CREATE TABLE $table_name (
        credit_id INT NOT NULL AUTO_INCREMENT,
        sender_id INT,
        sender_info TEXT,
        receiver_id INT,
        receiver_info TEXT,
        amount INT,
        type text,
        due_date DATETIME DEFAULT NULL,
        status TEXT, 
        purpose TEXT,
        for_sys TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (credit_id)
       
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}



function create_cheque_book_table() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'zn_system_cheque_book';

    $sql = "CREATE TABLE $table_name (
        id INT NOT NULL AUTO_INCREMENT,
        cheque_no INT,
        payee TEXT,
        bank_account TEXT,
        payment TEXT,
        deposit TEXT,
        location TEXT,
        memo TEXT,
        ref_no TEXT,
        ref_type text,
        status TEXT, 
        mailing_address TEXT,
        payment_date DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
       
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}


 function make_dbs(){
	 
	 
	 create_stock_categories_table();
     create_suppliers_table();
     create_customers_table();
	 create_projects_table();
	 create_orders_table();
	 create_products_table();
	 create_stock_brands_table();
	 create_meta_table();
	 create_employee_table();
	 create_quotation_table();
	 create_company_tools_table();
	 create_company_meterials_table();
	 
	 create_employee_table();
	 //create_departments_table();
	// create_employee_salaries_table();
	 create_attendance_table();
     create_credits_table();
     create_boq_table();
     create_stocks_table();


     create_prs_table();
	 create_ar_table();
     create_cheque_book_table();
	 //create_invoice_table();
 }


?>