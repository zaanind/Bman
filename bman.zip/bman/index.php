<?php
/*
Plugin Name: Wp Bman Suite
Description: Business Management System for Wordpress
Version: 1.0
Author:  Sahan Induvara (Zaanind)
Author URI: t.me/zaanind
*/



//https://wordpress.stackexchange.com/questions/195533/how-to-make-http-request-to-a-php-file-present-in-plugin-directory-of-wordpress
//https://rudrastyh.com/wordpress/how-to-add-images-to-media-library-from-uploaded-files-programmatically.html

include_once('includer.php');

define('POS_NAMESPACE', 'custom-login-api/v1');
define('POS_API_VERSION', '1.0');


/**
 * Load all PHP files in a directory
 * 
 * @param string $directory Path to the directory containing PHP files
 * @param bool $recursive Whether to load files from subdirectories
 * @throws Exception if directory doesn't exist or isn't readable
 */
function load_php_files($directory, $recursive = false) {
    // Check if directory exists and is readable
    if (!is_dir($directory) || !is_readable($directory)) {
        throw new Exception("Directory {$directory} does not exist or is not readable");
    }
    
    // Get all files in the directory
    $files = scandir($directory);
    
    foreach ($files as $file) {
        // Skip current and parent directory references
        if ($file === '.' || $file === '..') {
            continue;
        }
        
        $fullPath = $directory . DIRECTORY_SEPARATOR . $file;
        
        if (is_dir($fullPath) && $recursive) {
            // Recursively load files in subdirectory
            load_php_files($fullPath, true);
        } elseif (is_file($fullPath) && pathinfo($fullPath, PATHINFO_EXTENSION) === 'php') {
            // Require the PHP file
            require_once $fullPath;
        }
    }
}


function register_custom_image_sizes() {
    add_image_size('table_90x90', 90, 90, false); // No cropping
}
add_action('after_setup_theme', 'register_custom_image_sizes');


function create_db_tables_on_activate(){
 make_dbs();
    
    try {
    // Load all PHP files in the '' directory (non-recursive)
    load_php_files(__DIR__ . '/db_installers');
    
} catch (Exception $e) {
    echo 'Error loading files: ' . $e->getMessage();
}
    
}
register_activation_hook(__FILE__, 'create_db_tables_on_activate');

function custom_permalink_settings() {
    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure('/%postname%/');
    $wp_rewrite->flush_rules();
}
register_activation_hook(__FILE__, 'custom_permalink_settings');

register_activation_hook(__FILE__, 'add_custom_role');


function hide_admin_bar_for_non_admins() {
    if (!current_user_can('manage_options')) {
        show_admin_bar(false);
    }
}
add_action('after_setup_theme', 'hide_admin_bar_for_non_admins');





?>