<?php
session_start();
require_once('bcore.php');

// 1. Access Control
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = ["administrator"];

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Validate and fetch the bank to edit
global $wpdb;
$table_name = $wpdb->prefix . 'zn_acc_bank_list';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = 'Invalid Bank ID.';
    wp_redirect($homeurl . '/accounting/banks/');
    exit;
}

$id = (int) $_GET['id'];

// Fetch the existing bank data
$bank = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_name} WHERE id = %d",
    $id
));

if (!$bank) {
    $_SESSION['error'] = 'Bank not found.';
    wp_redirect($homeurl . '/accounting/banks/');
    exit;
}

// 3. Handle POST (Form Submission for Editing)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Initialize error array
    $errors = [];

    // Validate and sanitize form data

    // Validate bank_name
    $bank_name = isset($_POST['bank_name']) ? trim($_POST['bank_name']) : '';
    if (empty($bank_name)) {
        $errors[] = 'Bank Name is required';
    } else {
        $bank_name = sanitize_text_field(trim($_POST['bank_name']));
    }

    // Validate amount
    $amount = isset($_POST['amount']) ? trim($_POST['amount']) : '';
    if (empty($amount)) {
        $errors[] = 'Available Amount is required';
    } else {
        $amount = floatval($_POST['amount']);
    }

    // If no errors, proceed with database update
    if (empty($errors)) {

        global $wpdb;
        $table_name = $wpdb->prefix . 'zn_acc_bank_list';

        // Prepare data for update
        $data = array(
            'bankname' => $bank_name,
            'amount' => $amount,
            'updated_at' => current_time('mysql')
        );

        $where = array(
            'id' => $id
        );

        // Update the database
        $updated = $wpdb->update($table_name, $data, $where);

        if ($updated === false) {
            $errors[] = 'Failed to update bank record. Please try again.';
            $_SESSION['errors'] = $errors;
            $_SESSION['old_input'] = $_POST;
            wp_redirect($homeurl . '/accounting/banks/edit?id=' . $id);
            exit;
        }

        // Redirect on success
        $_SESSION['success'] = 'Bank Updated Successfully';
        wp_redirect($homeurl . '/accounting/banks');
        exit;
    } else {
        // Store errors in session and repopulate form
        $_SESSION['errors'] = $errors;
        $_SESSION['old_input'] = $_POST;
        wp_redirect($homeurl . '/accounting/banks/edit?id=' . $id);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Edit Bank | <?php echo get_bloginfo('name'); ?></title>

    <style>
        /* Custom CSS */

        /* Suggestions styling */
        .suggestions {
            border: 1px solid #ccc;
            max-height: 150px;
            overflow-y: auto;
            position: absolute;
            background: white;
            width: 100%;
            z-index: 1000;
            display: none;
        }
        .suggestion-item {
            cursor: pointer;
            padding: 8px;
        }
        .suggestion-item:hover {
            background: #f0f0f0;
        }
        .is-invalid {
            border-color: #dc3545 !important;
        }
        .invalid-feedback {
            color: #dc3545;
            display: none;
            width: 100%;
            margin-top: 0.25rem;
            font-size: 0.875em;
        }
    </style>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Edit Bank</h1>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <div class="alert-message">
                            <strong>Error:</strong> <?php echo htmlspecialchars($_SESSION['error']); ?>
                        </div>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>

                <?php if (isset($_SESSION['errors'])): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <div class="alert-message">
                            <strong>Error:</strong> Please fix the following issues:
                            <ul>
                                <?php foreach ($_SESSION['errors'] as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <?php unset($_SESSION['errors']); ?>
                <?php endif; ?>


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Edit Bank</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo esc_url($homeurl . '/accounting/banks/edit?id=' . $id); ?>" >

                                    <div class="mb-3">
                                        <label class="form-label">Bank Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="bank_name" id="bank_name" required
                                               value="<?php echo isset($_SESSION['old_input']['bank_name']) ? htmlspecialchars($_SESSION['old_input']['bank_name']) : htmlspecialchars($bank->bankname); ?>">
                                        <div class="invalid-feedback" id="bank_name-error"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Available Amount <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control" name="amount" id="amount"
                                               min="0" step="any" required
                                               value="<?php echo isset($_SESSION['old_input']['amount']) ? htmlspecialchars($_SESSION['old_input']['amount']) : htmlspecialchars($bank->amount); ?>">
                                        <div class="invalid-feedback" id="amount-error"></div>
                                    </div>


                                    <div class="row mt-4">
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary float-end">Update Bank</button>
                                            <a href="<?php echo $homeurl . '/accounting/banks/'; ?>" class="btn btn-secondary">Cancel</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<script>
jQuery(document).ready(function($) {

    // Client-side validation
    function validateForm() {
        let isValid = true;

        // Validate bank_name
        const bank_name = $('#bank_name').val().trim();
        if (!bank_name) {
            $('#bank_name').addClass('is-invalid');
            $('#bank_name-error').text('Bank Name is required').show();
            isValid = false;
        } else {
            $('#bank_name').removeClass('is-invalid');
            $('#bank_name-error').hide();
        }

        // Validate amount
        const amount = $('#amount').val().trim();
        if (!amount) {
            $('#amount').addClass('is-invalid');
            $('#amount-error').text('Available Amount is required').show();
            isValid = false;
        } else {
            $('#amount').removeClass('is-invalid');
            $('#amount-error').hide();
        }

        return isValid;
    }

    // Form submission handler
    $('form').on('submit', function(e) {
        if (!validateForm()) {
            e.preventDefault();
            $('.is-invalid').first().focus();
        }
    });

});
</script>
</body>
</html>