<?php
session_start();
require_once('bcore.php');

// 1. Access Control
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = ["administrator"];

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Handle POST (Form Submission)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Initialize error array
    $errors = [];

    // Validate and sanitize form data
    
    // Validate category_name
    $category_name = isset($_POST['category_name']) ? trim($_POST['category_name']) : '';
    if (empty($category_name)) {
        $errors[] = 'Category is required';
    } else {
        $category_name = sanitize_text_field(trim($_POST['category_name']));
    }


    // If no errors, proceed with database operations
    if (empty($errors)) {
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'zn_acc_categories';
        
        // Prepare data for insertion
        $data = array(
            'category' => $category_name,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        );
        
        // Insert into database
        $inserted = $wpdb->insert($table_name, $data);
        
        if (!$inserted) {
            $errors[] = 'Failed to save record. Please try again.';
            $_SESSION['errors'] = $errors;
            $_SESSION['old_input'] = $_POST;
            wp_redirect($homeurl . '/accounting/categories/add');
            exit;
        }


        // Redirect on success
        $_SESSION['success'] = '';
        wp_redirect($homeurl . '/accounting/categories');
        exit;
    } else {
        // Store errors in session and repopulate form
        $_SESSION['errors'] = $errors;
        $_SESSION['old_input'] = $_POST;
        wp_redirect($homeurl . '/accounting/categories/add');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Add Categories | <?php echo get_bloginfo('name'); ?></title>
    
    <style>
        /* Custom CSS */
        
        
        /* Suggestions styling */
        .suggestions {
            border: 1px solid #ccc;
            max-height: 150px;
            overflow-y: auto;
            position: absolute;
            background: white;
            width: 100%;
            z-index: 1000;
            display: none;
        }
        .suggestion-item {
            cursor: pointer;
            padding: 8px;
        }
        .suggestion-item:hover {
            background: #f0f0f0;
        }
        .is-invalid {
            border-color: #dc3545 !important;
        }
        .invalid-feedback {
            color: #dc3545;
            display: none;
            width: 100%;
            margin-top: 0.25rem;
            font-size: 0.875em;
        }
    </style>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Add Categories</h1>
                
                <?php if (isset($_SESSION['errors'])): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <div class="alert-message">
                            <strong>Error:</strong> Please fix the following issues:
                            <ul>
                                <?php foreach ($_SESSION['errors'] as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <?php unset($_SESSION['errors']); ?>
                <?php endif; ?>
                
               

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Add Categories</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo esc_url($homeurl . '/accounting/categories/add'); ?>" >
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Category <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="category_name" id="category_name" required
                   value="">
                                        <div class="invalid-feedback" id="category_name-error"></div>
                                    </div>

                                    
                                    <div class="row mt-4">
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary float-end">Add Category</button>
                                            <a href="<?php echo $homeurl . '/accounting/categories'; ?>" class="btn btn-secondary">Cancel</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<!-- JavaScript -->
<script>
jQuery(document).ready(function($) {
    
    // Client-side validation
    function validateForm() {
        let isValid = true;

        // Validate category_name
        const category_name = $('#category_name').val().trim();
        if (!category_name) {
            $('#category_name').addClass('is-invalid');
            $('#category_name-error').text('Category is required').show();
            isValid = false;
        } else {
            $('#category_name').removeClass('is-invalid');
            $('#category_name-error').hide();
        }

        return isValid;
    }
    
    // Form submission handler
    $('form').on('submit', function(e) {
        if (!validateForm()) {
            e.preventDefault();
            $('.is-invalid').first().focus();
        }
    });

});
</script>
</body>
</html>
