<?php


$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator',);


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}



?>


 <!DOCTYPE html>
<html lang="en">
<head>



   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title> Cheque Book  | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



	<main class="content">
	<div class="container-fluid p-0">
	<a href="<?php echo get_site_url(); ?>/accounting/chequebook/add" class="btn btn-primary float-end mt-n1"><i class="fas fa-plus"></i> New Cheque</a>

					<div class="mb-3">
						<h1 class="h3 d-inline align-middle"> Cheque Book</h1>
					</div>

					<div class="row">
						<div class="col-12">
							
							<div class="card">
								
								<div class="card-body">
<table id="datatables-reponsive" class="table table-striped" style="width:100%">
    <thead>
        <tr>
       <th>Date</th>
        <th>C No.</th>
        <th>R Type</th>
        <th>Payee</th>
       <!--th>Memo</th>   
       <th>Location</th-->
       <th>Payment</th>
       <th>Deposit</th>
            <th>Action</th>
        </tr>
    </thead>

    <?php
    global $wpdb;
    // Query to fetch the relevant data from wp_pos_system_suppliers
    $res = $wpdb->get_results("SELECT * FROM wp_zn_system_cheque_book");
    ?>

    <tbody>
    <?php 
    foreach ($res as $row) {
        echo '<tr>';

        // Display supplier name
        echo "<td>" . $row->payment_date . "</td>";

        // Display contact name and phone
        echo "<td>" . $row->cheque_no . "</td>";
        
          echo "<td>" . $row->ref_type . "</td>";
          echo "<td>" . $row->payee . "</td>";
          echo "<!--td>" . $row->memo . "</td>";
          echo "<td>" . $row->location . "</td-->";  
          echo "<td>" . $row->payment . "</td>";
          echo "<td>" . $row->deposit . "</td>";

        // Action buttons (Delete in this case)
        echo "<td>
                <div class='btn-group'>
                    <button type='button' class='btn btn-primary dropdown-toggle' data-bs-toggle='dropdown' aria-expanded='false'>Actions</button> 
                    <ul class='dropdown-menu'>
                    <li><a class='dropdown-item' href='" .get_site_url() ."/accounting/chequebook/edit?id=". $row->id."'>Edit</a></li>
                      <li><a class='dropdown-item' href='" .get_site_url() ."/accounting/chequebook/delete?id=". $row->id."'>Delete</a></li>
					</ul>
                </div>
              </td>";

        echo '</tr>';
    }
    ?>
    </tbody>
</table>

	</div>
	</div>
	</div>
	</div>
    </div>
	
	
	
	</main>
	
			
			<?php include_once('footer.php');?>
		</div>
	</div>

			<script>
		document.addEventListener("DOMContentLoaded", function() {
			// Datatables Responsive
			$("#datatables-reponsive").DataTable({
				responsive: true
		
			});
		});
	</script>
	
</body>

</html>