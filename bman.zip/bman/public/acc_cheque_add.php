<?php
session_start();

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator');  // Modify this with roles that can access this page

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}


   global $wpdb;
    $table_name = $wpdb->prefix . 'zn_system_cheque_book';
    
    $last_cheque = $wpdb->get_var("SELECT cheque_no FROM $table_name ORDER BY id DESC LIMIT 1");

    $next_cheque_no = $last_cheque ? $last_cheque + 1 : 1;  // If no record exists, start from 1



if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    global $wpdb;
    $table_name = $wpdb->prefix . 'zn_system_cheque_book';
    
    $last_cheque = $wpdb->get_var("SELECT cheque_no FROM $table_name ORDER BY id DESC LIMIT 1");

    $next_cheque_no = $last_cheque ? $last_cheque + 1 : 1;  // If no record exists, start from 1

    
    $homeurl = get_site_url();

    // Sanitize and collect form data
    $cheque_no = sanitize_text_field($_POST['cheque_no']);
    $payee = sanitize_text_field($_POST['payee']);
    $bank_account = sanitize_text_field($_POST['bank_account']);
    $payment = sanitize_text_field($_POST['payment']);
    $deposit = sanitize_text_field($_POST['deposit']);
    $location = sanitize_text_field($_POST['location']);
    $memo = sanitize_textarea_field($_POST['memo']);
    $ref_no = sanitize_text_field($_POST['ref_no']);
    $ref_type = sanitize_text_field($_POST['ref_type']);
    $status = sanitize_text_field($_POST['status']);
    $mailing_address = sanitize_text_field($_POST['mailing_address']);
    $payment_date = sanitize_text_field($_POST['payment_date']);

    // Prepare data for insertion into the database
    $data = array(
        'cheque_no' => $cheque_no,
        'payee' => $payee,
        'bank_account' => $bank_account,
        'payment' => $payment,
        'deposit' => $deposit,
        'location' => $location,
        'memo' => $memo,
        'ref_no' => $ref_no,
        'ref_type' => $ref_type,
        'status' => $status,
        'mailing_address' =>  $mailing_address,
        'payment_date' => $payment_date,
    );

    // Insert data into the database
    $inserted = $wpdb->insert($table_name, $data);

    if ($inserted === false) {
        $_SESSION['error'] = 'Failed to add cheque book record.';
        header('location:' . $homeurl . '/accounting/chequebook/add');
        exit;
    }

    // Redirect after success
    header('location:' . $homeurl . '/accounting/chequebook');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Add Cheque Book | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
    <div class="wrapper">
        <?php include_once('sidebar.php'); ?>
        <div class="main">
            <?php include_once('navbar.php'); ?>
            <main class="content">
                <?php
                if (isset($_SESSION['error'])) {
                    $err = $_SESSION['error'];
                    unset($_SESSION['error']);
                    ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <div class="alert-message">
                            <strong>Error:</strong> <?php echo $err; ?>
                        </div>
                    </div>
                <?php } ?>

                <div class="container-fluid p-0">
                    <h1 class="h3 mb-3">Add New Cheque</h1>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <form method="POST" action="<?php echo get_site_url(); ?>/accounting/chequebook/add" enctype="multipart/form-data" onsubmit="return validateForm()">
                                        <div class="mb-3">
                                            <label class="form-label">Cheque Number:</label>
                                            <input type="number" class="form-control" name="cheque_no" required value="<?php echo $next_cheque_no; ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Payee:</label>
                                            <input type="text" class="form-control" name="payee" required>
                                        </div>
										
										
										
                                        <div class="mb-3">
                                            <label class="form-label">Bank Account:</label>
                                            <!--input type="text" class="form-control" name="bank_account" required-->
											
											 <select class="form-control" name="bank_account" required>
											<?php 
											global $wpdb;
											$brand_list =  $wpdb->get_results("SELECT * FROM wp_zn_acc_bank_list");
										    echo "<option>Select</option>";
											foreach ($brand_list as $row) { echo "<option>". $row->bankname ."</option>";}
											?>
											    
											 

											</select>
                                        </div>
										
											
										
										
										
										
                                        <div class="mb-3">
                                            <label class="form-label">Payment Amount:</label>
                                            <input type="text" class="form-control" name="payment" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Deposit Amount:</label>
                                            <input type="text" class="form-control" name="deposit" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Location:</label>
                                            <input type="text" class="form-control" name="location" required>
                                        </div>
                                                
                                                
                                                
                                             <div class="mb-3">
                                            <label class="form-label">Mailing Address:</label>
                                            <textarea class="form-control" name="mailing_address"></textarea>
                                        </div>
                                                
                                                
                                                
                                        <div class="mb-3">
                                            <label class="form-label">Memo:</label>
                                            <textarea class="form-control" name="memo"></textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Reference Number:</label>
                                            <input type="text" class="form-control" name="ref_no">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Reference Type:</label>
                                            <input type="text" class="form-control" name="ref_type">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Status:</label>
                                            <input type="text" class="form-control" name="status" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Payment Date:</label>
                                            <input type="date" class="form-control" name="payment_date" required>
                                        </div>
                                        <button class="btn btn-outline-primary float-end">Add Cheque Book</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <?php include_once('footer.php'); ?>
        </div>
    </div>
</body>
</html>