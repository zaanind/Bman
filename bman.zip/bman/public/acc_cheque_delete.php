<?php 
    
    // delete_cheque.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $cheque_id = intval($_GET['id']); // Sanitize input

    // Delete the cheque record from the database
    $deleted = $wpdb->delete('wp_zn_system_cheque_book', ['id' => $cheque_id]);

    if ($deleted !== false) {
        // Redirect back to the cheque book list after deletion
        wp_redirect($homeurl . '/accounting/chequebook');
        exit;
    } else {
        echo "Failed to delete cheque record.";
    }
} else {
    echo 'No Cheque ID provided';
}
?>