<?php
session_start();
require_once('bcore.php');

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = ["administrator"];

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'zn_system_cheque_book';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = 'Invalid Cheque ID.';
    wp_redirect($homeurl . '/accounting/chequebook');
    exit;
}

$id = (int) $_GET['id'];

$cheque = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_name} WHERE id = %d",
    $id
));

if (!$cheque) {
    $_SESSION['error'] = 'Cheque not found.';
    wp_redirect($homeurl . '/accounting/chequebook');
    exit;
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];

    $data = [
        'cheque_no'       => sanitize_text_field($_POST['cheque_no']),
        'payee'           => sanitize_text_field($_POST['payee']),
        'bank_account'    => sanitize_text_field($_POST['bank_account']),
        'payment'         => sanitize_text_field($_POST['payment']),
        'deposit'         => sanitize_text_field($_POST['deposit']),
        'location'        => sanitize_text_field($_POST['location']),
        'memo'            => sanitize_textarea_field($_POST['memo']),
        'ref_no'          => sanitize_text_field($_POST['ref_no']),
        'ref_type'        => sanitize_text_field($_POST['ref_type']),
        'status'          => sanitize_text_field($_POST['status']),
        'mailing_address' => sanitize_text_field($_POST['mailing_address']),
        'payment_date'    => sanitize_text_field($_POST['payment_date']),
    ];

    // Update DB
    $updated = $wpdb->update($table_name, $data, ['id' => $id]);

    if ($updated === false) {
        $_SESSION['error'] = 'Failed to update cheque record.';
        $_SESSION['old_input'] = $_POST;
        wp_redirect($homeurl . '/accounting/chequebook/edit?id=' . $id);
        exit;
    }

    $_SESSION['success'] = 'Cheque updated successfully.';
    wp_redirect($homeurl . '/accounting/chequebook');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Edit Cheque | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Edit Cheque</h1>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        <strong>Error:</strong> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                    </div>
                <?php endif; ?>



                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <form method="POST" action="">
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Cheque Number:</label>
                                        <input type="number" class="form-control" name="cheque_no" required value="<?php echo $cheque->cheque_no; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Payee:</label>
                                        <input type="text" class="form-control" name="payee" required value="<?php echo  $cheque->payee; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Bank Account:</label>
                                        <input type="text" class="form-control" name="bank_account" required value="<?php echo  $cheque->bank_account; ?>">
                                        
										
										
											    <select class="form-control" name="bank_account" required >
											<?php 
											global $wpdb;
											$brand_list =  $wpdb->get_results("SELECT * FROM SELECT * FROM wp_zn_acc_bank_list");
										    echo "<option>Select</option>";
											
											foreach ($brand_list as $row) { 
											
											
											if($cheque->bank_account == $row->bankname){
											 echo "<option selected>". $row->bankname ."</option>";
												
											} else {
											
											 echo "<option>". $row->bankname ."</option>"; }
											
											}
											?>
											    
											 

											</select>


								   </div>

                                    <div class="mb-3">
                                        <label class="form-label">Payment Amount:</label>
                                        <input type="text" class="form-control" name="payment" required value="<?php echo  $cheque->payment; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Deposit Amount:</label>
                                        <input type="text" class="form-control" name="deposit" required value="<?php echo $cheque->deposit; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Location:</label>
                                        <input type="text" class="form-control" name="location" required value="<?php echo  $cheque->location; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Mailing Address:</label>
                                        <textarea class="form-control" name="mailing_address"><?php echo  $cheque->mailing_address; ?></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Memo:</label>
                                        <textarea class="form-control" name="memo"><?php echo $cheque->memo; ?></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Reference Number:</label>
                                        <input type="text" class="form-control" name="ref_no" value="<?php echo  $cheque->ref_no; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Reference Type:</label>
                                        <input type="text" class="form-control" name="ref_type" value="<?php echo  $cheque->ref_type; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Status:</label>
                                        <input type="text" class="form-control" name="status" required value="<?php echo $cheque->status; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Payment Date:</label>
                                        <input type="date" class="form-control" name="payment_date" required value="<?php echo  $cheque->payment_date; ?>">
                                    </div>

                                    <button type="submit" class="btn btn-primary float-end">Update Cheque</button>
                                    <a href="<?php echo $homeurl . '/accounting/chequebook'; ?>" class="btn btn-secondary">Cancel</a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>
</body>
</html>
<?php unset($_SESSION['old_input']); ?>
