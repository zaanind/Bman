<?php
session_start();

// Restrict to admin or whomever can add credits
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator'); // adjust as needed

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

global $wpdb;
$credits_table_name = $wpdb->prefix . 'zn_system_credits'; // Table to insert credit record into
$projects_table_name = $wpdb->prefix . 'zn_system_projects'; // Table to update project credit in

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $type     = sanitize_text_field($_POST['type']);      // e.g., "send" or "get"

    if ($type === 'send') {
        // 1) Hard-code the sender to "Company" for "send" type
        $sender_id    = get_current_user_id();           // current WP user ID
        $sender_name  = "Company";                       // fixed name
        $sender_email = "company@example.com";           // your company's email
        $sender_phone = ""; // no phone for company as sender for 'send' type, can be adjusted if needed
    } elseif ($type === 'get') {
        // 1) Get sender info from form for "get" type
        $sender_id    = 0; // or null, as it's external sender.  sender_id is primarily for internal users.
        $sender_name  = sanitize_text_field($_POST['sender_name']);
        $sender_email = sanitize_email($_POST['sender_email']);
        $sender_phone = sanitize_text_field($_POST['sender_phone']);
    } else {
        // Handle invalid type if needed, maybe set error and redirect
        $_SESSION['error'] = 'Invalid credit type selected.';
        wp_redirect($homeurl . '/accounting/credits/add');
        exit;
    }


    // 2) Determine receiver based on for_sys (receiver logic remains the same)
    $for_sys        = sanitize_text_field($_POST['for_sys']); // project, employee, shop, or other
    $receiver_id    = 0;
    $receiver_name  = sanitize_text_field($_POST['receiver_name']);
    $receiver_email = sanitize_email($_POST['receiver_email']);
    $receiver_phone = sanitize_text_field($_POST['receiver_phone']);

    if ($for_sys === 'project') {
        // Use the project_id field for receiver_id
        $receiver_id = !empty($_POST['project_id']) ? intval($_POST['project_id']) : 0;
        // Receiver name/email/phone are not needed in this case, can be empty.
        $receiver_name = '';
        $receiver_email = '';
        $receiver_phone = '';
    } elseif ($for_sys === 'employee') {
        // Use the employee_id field for receiver_id
        $receiver_id = !empty($_POST['employee_id']) ? intval($_POST['employee_id']) : 0;
        // Receiver name/email/phone are not needed in this case, can be empty.
        $receiver_name = '';
        $receiver_email = '';
        $receiver_phone = '';
    }
    // If shop/other, we just leave receiver_id=0 and store the free-form name/email/phone.

    // 3) Collect other fields (rest remains the same)
    $amount   = floatval($_POST['amount']);
    $due_date = sanitize_text_field($_POST['due_date']);
    $status   = sanitize_text_field($_POST['status']);
    $purpose  = sanitize_text_field($_POST['purpose']);


    // 4) Convert name/email/phone into JSON (sender and receiver info updated based on type)
    $sender_info = json_encode([
        'name'  => $sender_name,
        'email' => $sender_email,
        'phone' => $sender_phone
    ]);
    $receiver_info = json_encode([
        'name'  => $receiver_name,
        'email' => $receiver_email,
        'phone' => $receiver_phone
    ]);

    // 5) Insert into DB (data array remains same, just using updated variables)
    $data = [
        'sender_id'     => $sender_id,
        'sender_info'   => $sender_info,
        'receiver_id'   => $receiver_id,
        'receiver_info' => $receiver_info,
        'amount'        => $amount,
        'due_date'      => $due_date,
        'status'        => $status,
        'purpose'       => $purpose,
        'for_sys'       => $for_sys,
        'type'          => $type,
    ];

    $inserted = $wpdb->insert($credits_table_name, $data);
    if ($inserted === false) {
        $_SESSION['error'] = 'Failed to add credit record.';
        wp_redirect($homeurl . '/accounting/credits/add');
        exit;
    } else {
        // Update project credit if for_sys is project
        if ($for_sys === 'project' && $receiver_id > 0) {
            $project_id = $receiver_id;
            $new_credit_amount = $amount;

            // Get current project credit
            $current_credit = $wpdb->get_var( $wpdb->prepare(
                "SELECT project_credit FROM {$projects_table_name} WHERE project_id = %d",
                $project_id
            ) );

            $current_credit = floatval($current_credit); // Ensure it's a float
            $updated_credit = $current_credit + $new_credit_amount;

            // Update project_credit in wp_zn_system_projects table
            $updated_project_credit = $wpdb->update(
                $projects_table_name,
                array( 'project_credit' => $updated_credit ),
                array( 'project_id' => $project_id )
            );

            if ($updated_project_credit === false) {
                // Log error or handle it as needed. For now, set session error.
                $_SESSION['error'] = 'Credit record added successfully, but failed to update project credit.';
                wp_redirect($homeurl . '/accounting/credits/add');
                exit;
            }
        }
        // On success, go back to credits list
        wp_redirect($homeurl . '/accounting/credits');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Add Credit | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            if (isset($_SESSION['error'])) {
                echo '<div class="alert alert-danger alert-dismissible" role="alert">';
                echo '  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                echo '  <div class="alert-message"><strong>Error:</strong> ' . esc_html($_SESSION['error']) . '</div>';
                echo '</div>';
                unset($_SESSION['error']);
            }
            ?>
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Add New Credit</h1>
                <div class="card">
                    <div class="card-body">

                        <form method="POST" action="<?php echo get_site_url(); ?>/accounting/credits/add">

                            <!-- TYPE Field -->
                            <div class="row mb-3">
                                <div class="col-md-3">
                                    <label class="form-label">Sender Type</label>
                                    <select name="type" class="form-select" id="type">
                                        <option value="send" selected>By Company (Credit)</option>
                                        <option value="get">From External Company (Loan)</option>
                                    </select>
                                </div>
                            </div>


                            <!-- SENDER Section: Conditional based on Type -->
                            <div id="companySenderFields" > <!-- Shown when type is 'send' -->
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label class="form-label">Sender Name</label>
                                        <input type="text"  class="form-control" name="sender_name_company" value="Company" readonly>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label class="form-label">Sender Email</label>
                                        <input type="text" class="form-control" name="sender_email_company" value="company@example.com" readonly>
                                    </div>
                                </div>
                            </div>

                            <div id="externalSenderFields" style="display:none;"> <!-- Shown when type is 'get' -->
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label class="form-label">Sender Name</label>
                                        <input type="text" class="form-control" name="sender_name" placeholder="e.g. Bank XYZ" >
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label class="form-label">Sender Email</label>
                                        <input type="email" class="form-control" name="sender_email" placeholder="e.g. contact@bankxyz.com">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label class="form-label">Sender Phone</label>
                                        <input type="text" name="sender_phone" class="form-control" placeholder="e.g. +1987654321">
                                    </div>
                                </div>
                            </div>


                            <!-- RECEIVER Section (Conditional based on for_sys) -->
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label class="form-label">Receiver Type</label>
                                    <select name="for_sys" class="form-select" id="for_sys">
                                        <option value="project">Project</option>
                                        <!--option value="employee">Employee</option-->
                                        <option value="shop">Shop</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Project ID Fields (Shown if for_sys=project) -->
                            <div id="projectFields" style="display:none;">
                                <div class="row mb-3">
                                    <div class="col-md-3">
                                        <label class="form-label">Project ID</label>
                                        <input type="number" name="project_id" id="projectId" class="form-control" placeholder="e.g. 101" readonly>
                                    </div>
                                    <div class="col-md-5">
                                        <label class="form-label">Project Title</label>
                                        <input type="text" class="form-control" id="projectTitle" autocomplete="off">
                                        <div id="projectTitle_suggestions" class="project_suggestions"></div>
                                    </div>
                                </div>
                            </div>

                            <!-- Employee ID Fields (Shown if for_sys=employee) -->
                            <div id="employeeFields" style="display:none;">
                                <div class="row mb-3">
                                    <div class="col-md-3">
                                        <label class="form-label">Employee ID</label>
                                        <input type="number" name="employee_id" class="form-control" placeholder="e.g. 25">
                                    </div>
                                </div>
                            </div>

                            <!-- Receiver Name/Email/Phone (Conditionally Shown) -->
                            <div id="receiverNameFields">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label class="form-label">Receiver Name</label>
                                        <input type="text" name="receiver_name" class="form-control" placeholder="e.g. ABC Shop or John (Employee)">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Receiver Email</label>
                                        <input type="email" name="receiver_email" class="form-control" placeholder="e.g. contact@xyz.com">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Receiver Phone</label>
                                        <input type="text" name="receiver_phone" class="form-control" placeholder="e.g. +987654321">
                                    </div>
                                </div>
                            </div>


                            <!-- AMOUNT / DUE DATE / STATUS / PURPOSE (remains same) -->
                            <div class="row mb-3">
                                <div class="col-md-3">
                                    <label class="form-label">Amount</label>
                                    <input type="number" step="0.01" name="amount" class="form-control" required placeholder="e.g. 50000">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Due Date</label>
                                    <input type="date" name="due_date" class="form-control" placeholder="YYYY-MM-DD">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Status</label>
                                    <select name="status" class="form-select">
                                        <option value="Pending">Pending</option>
                                        <option value="Paid">Paid</option>
                                        <option value="Approved">Approved</option>
                                        <option value="Overdue">Overdue</option>
                                        <option value="Closed">Closed</option>
                                    </select>
                                </div>
                            </div>


                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Purpose</label>
                                    <input type="text" name="purpose" class="form-control" placeholder="e.g. Loan for building materials or Loan from Bank XYZ">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-outline-primary float-end">
                                Add Credit
                            </button>
                        </form>
                    </div><!-- card-body -->
                </div><!-- card -->
            </div><!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<!-- jQuery Toggling Logic for Sender and Project/Employee Fields -->
<script>
jQuery(document).ready(function($){
    function toggleSenderFields(typeVal) {
        if (typeVal === 'get') {
            $('#externalSenderFields').show();
            $('#companySenderFields').hide();
        } else { // default to 'send' or any other case
            $('#externalSenderFields').hide();
            $('#companySenderFields').show();
        }
    }

    function toggleReceiverFields(forSysVal) {
        if (forSysVal === 'project') {
            $('#projectFields').show();
            $('#employeeFields').hide();
            $('#receiverNameFields').hide(); // Hide receiver name/email/phone
            $('#employeeFields').find('input').val(''); // Clear employee fields when project is shown
            $('#receiverNameFields').find('input').val(''); // Clear receiver name fields
        } else if (forSysVal === 'employee') {
            $('#projectFields').hide();
            $('#employeeFields').show();
            $('#receiverNameFields').hide(); // Hide receiver name/email/phone
            $('#projectFields').find('input').val(''); // Clear project fields when employee is shown
            $('#receiverNameFields').find('input').val(''); // Clear receiver name fields
        } else {
            // shop or other
            $('#projectFields').hide();
            $('#employeeFields').hide();
            $('#receiverNameFields').show(); // Show receiver name/email/phone
            $('#projectFields').find('input').val(''); // Clear project fields when shop/other is shown
            $('#employeeFields').find('input').val(''); // Clear employee fields when shop/other is shown
        }
    }


    // On page load, check the default selections
    toggleSenderFields($('#type').val());
    toggleReceiverFields($('#for_sys').val());


    // On change of 'type'
    $('#type').change(function(){
        toggleSenderFields($(this).val());
    });

    // On change of 'for_sys'
    $('#for_sys').change(function(){
        toggleReceiverFields($(this).val());
    });


    function fetchProjectData(fieldId) {
        let query = $(fieldId).val();
        let suggestionBox = fieldId + "_suggestions";

        if (query.length > 2) { // More than 2 characters to start searching
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api", // Use same API endpoint
                method: "POST",
                data: { search_project_query_name: query }, // Changed data parameter for project search
                success: function(data) {
                 //   console.log("API Response:", data);
                    let suggestions = "";

                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(project => {
                            suggestions += `<div class='suggestion-item'
                                            data-project-id='${project.id || ""}'
                                            data-project-name='${project.name || ""}'>
                                            ${project.name || "Unknown"} - ID: ${project.id || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    }

    // Event Listeners for Project Search
    $("#projectTitle").keyup(function() {
        fetchProjectData("#projectTitle");
    });


    // Click event for selecting project suggestion
    $(document).on("click", ".suggestion-item", function() {
        let selectedProjectId = $(this).data("project-id");
        let selectedProjectName = $(this).data("project-name");


        $("#projectId").val(selectedProjectId);
        $("#projectTitle").val(selectedProjectName);


        $(".project_suggestions").hide();
    });

    // Hide project suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest(".project_suggestions, #projectTitle").length) {
            $(".project_suggestions").hide();
        }
    });


});
</script>
</body>
</html>