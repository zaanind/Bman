<?php

  //make work in ids

if (isset($_POST['search_product_query_name'])) {
    global $wpdb;
    $query = $_POST['search_product_query_name'];
    $searchPattern = '%' . implode('%', str_split($query)) . '%';


    $sql = $wpdb->prepare(
        "SELECT product_id,product_name,price,quantity FROM wp_pos_system_inventory_products  WHERE product_name LIKE %s;",
        $searchPattern
    );

    $result = $wpdb->get_results($sql);

   header('Content-Type: application/json');
   if (!empty($result)) {
    $response = [];
    foreach ($result as $row) {
        $response[] = [
		  
            'name' => $row->product_name,
            'id' => $row->product_id,
            'price' => $row->price,
            'stock' => $row->quantity,
			'discount' => '0',
            
        ];
    }
    echo json_encode($response); 
	} else {  echo json_encode(['message' => 'No results found']);}
   
  
}




if (isset($_POST['search_project_query_name'])) {
    global $wpdb;
    $query = sanitize_text_field($_POST['search_project_query_name']);
    $searchPattern = '%' . $wpdb->esc_like($query) . '%';

    $sql = $wpdb->prepare(
        "SELECT project_id, project_title FROM wp_zn_system_projects WHERE project_title LIKE %s",
        $searchPattern
    );

    $results = $wpdb->get_results($sql);

    header('Content-Type: application/json');
    if (!empty($results)) {
        $response = array_map(function($row) {
            return [
                'id' => $row->project_id,
                'name' => $row->project_title
            ];
        }, $results);
        echo json_encode($response);
    } else {
        echo json_encode([]);
    }
    exit;
}




if (isset($_POST['search_employee_query_name'])) {
    global $wpdb;
    $query = $_POST['search_employee_query_name'];

    // Convert input into a character-by-character search pattern
    $searchPattern = '%' . implode('%', str_split($query)) . '%';

    // Use prepared statement to prevent SQL injection
    $sql = $wpdb->prepare(
        "SELECT * FROM wp_zn_system_employee WHERE name LIKE %s ",
        $searchPattern
    );

    $result = $wpdb->get_results($sql);

   header('Content-Type: application/json');
   if (!empty($result)) {
    $response = [];
    foreach ($result as $row) {
        $response[] = [
            'name' => $row->name,
            'id' => $row->employee_id,
            'mobile' => $row->phone_number,
            'email' => $row->email
        ];
    }
    echo json_encode($response); 
	} else {  echo json_encode(['message' => 'No results found']);}
   
   
   
   
}

   
   


if (isset($_POST['search_customer_query_name'])) {
    global $wpdb;
    $query = $_POST['search_customer_query_name'];

    // Convert input into a character-by-character search pattern
    $searchPattern = '%' . implode('%', str_split($query)) . '%';

    // Use prepared statement to prevent SQL injection
    $sql = $wpdb->prepare(
        "SELECT name,phone_number,email,address FROM wp_pos_system_customers WHERE name LIKE %s ",
        $searchPattern
    );

    $result = $wpdb->get_results($sql);

   header('Content-Type: application/json');
   if (!empty($result)) {
    $response = [];
    foreach ($result as $row) {
        $response[] = [
            'name' => $row->name,
            'contact_number' => $row->phone_number,
            'email' => $row->email,
            'address' => $row->address
        ];
    }
    echo json_encode($response); 
	} else {  echo json_encode(['message' => 'No results found']);}
   
   
   
   
}




if (isset($_POST['search_customer_query_phone'])) {
    global $wpdb;
    $query = $_POST['search_customer_query_phone'];

    // Convert input into a character-by-character search pattern
    $searchPattern = '%' . implode('%', str_split($query)) . '%';

    // Use prepared statement to prevent SQL injection
    $sql = $wpdb->prepare(
        "SELECT name,phone_number,email,address FROM wp_pos_system_customers WHERE phone_number LIKE %s ",
        $searchPattern
    );

    $result = $wpdb->get_results($sql);

   header('Content-Type: application/json');
   if (!empty($result)) {
    $response = [];
    foreach ($result as $row) {
        $response[] = [
            'name' => $row->name,
            'contact_number' => $row->phone_number,
            'email' => $row->email,
            'address' => $row->address
        ];
    }
    echo json_encode($response); 
	} else {  echo json_encode(['message' => 'No results found']);}
}
  
  
  if (isset($_POST['search_customer_query_email'])) {
    global $wpdb;
    $query = $_POST['search_customer_query_email'];

    // Convert input into a character-by-character search pattern
    $searchPattern = '%' . implode('%', str_split($query)) . '%';

    // Use prepared statement to prevent SQL injection
    $sql = $wpdb->prepare(
        "SELECT name,phone_number,email,address FROM wp_pos_system_customers WHERE email LIKE %s ",
        $searchPattern
    );

    $result = $wpdb->get_results($sql);

   header('Content-Type: application/json');
   if (!empty($result)) {
    $response = [];
    foreach ($result as $row) {
        $response[] = [
            'name' => $row->name,
            'contact_number' => $row->phone_number,
            'email' => $row->email,
            'address' => $row->address
        ];
    }
    echo json_encode($response); 
	} else {  echo json_encode(['message' => 'No results found']);}
   
   
   
}




?>