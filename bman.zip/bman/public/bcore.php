<?php 





function save_comp_material_store($data) {
    global $wpdb;
    $table_name = 'wp_zn_inventory_comp_meterials';

    // Check if 'id' exists for update
    if (!empty($data['item_id'])) {
        $id = $data['item_id'];
        unset($data['item_id']);
        $updated = $wpdb->update($table_name, $data, ['item_id' => $id]);

        if ($wpdb->last_error) {
            error_log("MySQL Error (Update): " . $wpdb->last_error);
            return false;
        }

        return $updated !== false ? $id : false;
    } else {
        // Insert new record
        $inserted = $wpdb->insert($table_name, $data);

        if ($wpdb->last_error) {
            error_log("MySQL Error (Insert): " . $wpdb->last_error);
            return false;
        }

        return $inserted ? $wpdb->insert_id : false;
    }
}




function save_cashbook($data) {
    global $wpdb;
    $table_name = 'wp_zn_sys_cashbook';

    // Check if 'id' exists for update
    if (!empty($data['id'])) {
        $id = $data['id'];
        unset($data['id']);
        $updated = $wpdb->update($table_name, $data, ['id' => $id]);

        if ($wpdb->last_error) {
            error_log("MySQL Error (Update): " . $wpdb->last_error);
            return false;
        }

        return $updated !== false ? $id : false;
    } else {
        // Insert new record
        $inserted = $wpdb->insert($table_name, $data);

        if ($wpdb->last_error) {
            error_log("MySQL Error (Insert): " . $wpdb->last_error);
            return false;
        }

        return $inserted ? $wpdb->insert_id : false;
    }
}



function save_cheque_data($data) {
    global $wpdb;
    $table_name = 'wp_zn_system_cheque_book';

    // Check if 'id' exists for update
    if (!empty($data['id'])) {
        $id = $data['id'];
        unset($data['id']);
        $updated = $wpdb->update($table_name, $data, ['id' => $id]);

        if ($wpdb->last_error) {
            error_log("MySQL Error (Update): " . $wpdb->last_error);
            return false;
        }

        return $updated !== false ? $id : false;
    } else {
        // Insert new record
        $inserted = $wpdb->insert($table_name, $data);

        if ($wpdb->last_error) {
            error_log("MySQL Error (Insert): " . $wpdb->last_error);
            return false;
        }

        return $inserted ? $wpdb->insert_id : false;
    }
}



function save_ar_data($data) {
    global $wpdb;
    $table_name = 'wp_zn_system_ar';

    // Check if 'id' exists for update
    if (!empty($data['id'])) {
        $id = $data['id'];
        unset($data['id']);
        $updated = $wpdb->update($table_name, $data, ['id' => $id]);

        if ($wpdb->last_error) {
            error_log("MySQL Error (Update): " . $wpdb->last_error);
            return false;
        }

        return $updated !== false ? $id : false;
    } else {
        // Insert new record
        $inserted = $wpdb->insert($table_name, $data);

        if ($wpdb->last_error) {
            error_log("MySQL Error (Insert): " . $wpdb->last_error);
            return false;
        }

        return $inserted ? $wpdb->insert_id : false;
    }
}

    
function save_receipt_data($data) {
    global $wpdb;
    $table_name = 'wp_zn_system_receipts';

    // Check if receipt ID is provided (for update)
    if (!empty($data['r_id'])) {
        $r_id = $data['r_id'];
        unset($data['r_id']);
        // Update the existing receipt record
        $updated = $wpdb->update($table_name, $data, array('r_id' => $r_id));
        if ($wpdb->last_error) {
            error_log("MySQL Error: " . $wpdb->last_error);
            return false;
        }
        return $updated !== false ? $r_id : false;
    } else {
        // Insert a new receipt record
        $inserted = $wpdb->insert($table_name, $data);
        if ($wpdb->last_error) {
            error_log("MySQL Error: " . $wpdb->last_error);
            return false;
        }
        return $inserted ? $wpdb->insert_id : false;
    }
}

    
 function save_order_data($data) {
    global $wpdb;
    $table_name = 'wp_pos_system_orders';

    if (!empty($data['order_id'])) {
        $order_id = $data['order_id'];
        unset($data['order_id']);
        $updated = $wpdb->update($table_name, $data, array('order_id' => $order_id));
        if ($wpdb->last_error) {
            error_log("MySQL Error: " . $wpdb->last_error);
            return false;
        }
        return $updated !== false ? $order_id : false;
    } else {
        $inserted = $wpdb->insert($table_name, $data);
        if ($wpdb->last_error) {
            error_log("MySQL Error: " . $wpdb->last_error);
            return false;
        }
        return $inserted ? $wpdb->insert_id : false;
    }
}
   
    
function save_project_data($data) {
    global $wpdb;
    $table_name = 'wp_zn_system_projects';


    if (!empty($data['project_id'])) {
        $project_id = $data['project_id'];
        unset($data['project_id']); 

        $updated = $wpdb->update(
            $table_name,
            $data,
            array('project_id' => $project_id)
        );

        // Error handling
        if ($wpdb->last_error) {
            $error_message = "MySQL Error: " . $wpdb->last_error;
            error_log($error_message); // Log the error
            exit;
        }

        return $updated !== false ? $project_id : false; // Return ID if update successful
    } else {
        // Insert new record
        $inserted = $wpdb->insert($table_name, $data);

        // Error handling
        if ($wpdb->last_error) {
            $error_message = "MySQL Error: " . $wpdb->last_error;
            error_log($error_message); // Log the error
            exit;
        }

        return $inserted ? $wpdb->insert_id : false;
    }
}



function save_quotation_data($data) {
    global $wpdb;
    $table_name = 'wp_zn_system_quotations'; // Adjust the table name as needed

    // Check if `q_id` is provided for updating
    if (!empty($data['q_id'])) {
        $q_id = $data['q_id'];
        unset($data['q_id']); // Remove ID from data array to avoid conflicts

        $updated = $wpdb->update(
            $table_name,
            $data,
            array('q_id' => $q_id)
        );


        //error handle
        if($wpdb->last_error){
        $error_message = "MySQL Error: " . $wpdb->last_error;
        error_log($error_message); // Log the error
        exit;
         }

        return $updated !== false ? $q_id : false; // Return ID if update successful
    } else {
        // Insert new record
        $inserted = $wpdb->insert($table_name, $data);

        //error handle
        if($wpdb->last_error){
                    $error_message = "MySQL Error: " . $wpdb->last_error;
                    error_log($error_message); // Log the error
                    exit;
           }

        return $inserted ? $wpdb->insert_id : false; // Return new ID if insert successful
    }
}



function save_prs_data($data) {
    global $wpdb;
    $table_name = 'wp_zn_system_prs';

    // Check if `pr_id` is provided for updating
    if (!empty($data['pr_id'])) {
        $pr_id = $data['pr_id'];
        unset($data['pr_id']); // Remove ID from data array to avoid conflicts

        $updated = $wpdb->update(
            $table_name,
            $data,
            array('pr_id' => $pr_id)
        );
        
        //error handle
        if($wpdb->last_error){
            $error_message = "MySQL Error: " . $wpdb->last_error;
            error_log($error_message); // Log the error
            exit;  }

        return $updated !== false ? $pr_id : false; // Return ID if update successful
    } else {
        // Insert new record
        $inserted = $wpdb->insert($table_name, $data);
        
        //error handle
        if($wpdb->last_error){
            $error_message = "MySQL Error: " . $wpdb->last_error;
            error_log($error_message); // Log the error
            exit;
           }

        return $inserted ? $wpdb->insert_id : false; // Return new ID if insert successful
    }
}


function save_boq_data($data) {
    global $wpdb;
    $table_name = 'wp_zn_system_boq';

    // Check if boq_id is provided
    if (!empty($data['boq_id'])) {
        // Update existing record
        $boq_id = $data['boq_id'];
        unset($data['boq_id']); // Remove ID from data array to avoid conflicts

        $updated = $wpdb->update(
            $table_name,
            $data,
            array('boq_id' => $boq_id)
        );
                
        //error handle
        if($wpdb->last_error){
            $error_message = "MySQL Error: " . $wpdb->last_error;
            error_log($error_message); // Log the error
            exit;}

        return $updated !== false ? $boq_id : false; // Return ID if update successful
    } else {
        // Insert new record
        $inserted = $wpdb->insert($table_name, $data);
        
        //error handle
        if($wpdb->last_error){
            $error_message = "MySQL Error: " . $wpdb->last_error;
            error_log($error_message); // Log the error
            exit;}

        return $inserted ? $wpdb->insert_id : false; // Return new ID if insert successful
    }
}



/*
//-------------------------Examples---------------------------------------


$data = array(
    'order_id'        => 123,
    'project_id'      => 'P456',
    'description'     => 'Project description',
    'title'           => 'New Project',
    'location'        => 'New York',
    'items'           => json_encode([]),
    'customer_id'     => 1,
    'g_subtotal'      => 100.00,
    'g_total_amount'  => 120.00,
    'g_discount'      => 10.00,
    'g_tax'           => 5.00,
    'g_paid'          => 50.00,
    'g_due'           => 70.00,
    'billing_address' => '123 Street, NY',
    'shipping_address'=> '456 Avenue, NY'
);

// Insert new
$new_id = save_boq_data($data);

// Update existing
$data['boq_id'] = $new_id;
$data['title'] = 'Updated Project';
save_boq_data($data);
*/



function get_customer_info($identifier) {
    global $wpdb;
    $table_name = 'wp_pos_system_customers';

    // Determine if identifier is an email or customer_id (numeric)
    if (is_numeric($identifier)) {
        $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE customer_id = %d", $identifier);
    } else {
        $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE email = %s", $identifier);
    }

    return $wpdb->get_row($sql, ARRAY_A); // Fetch associative array
}

/*
//-------------------------------- Usage Example---------------------------
$customer_info = get_customer_info(1); // Fetch by customer ID
//$customer_info = get_customer_info('customer@example.com'); // Fetch by email

if ($customer_info) {
    print_r($customer_info); // Display customer details
} else {
    echo "Customer not found.";
}

*/





?>