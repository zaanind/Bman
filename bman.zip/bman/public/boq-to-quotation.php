<?php


$homeurl = get_site_url();


include_once('bcore.php');


if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb; 
    $id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // 1. Check if the quotation exists and retrieve its details
    $ob = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM wp_zn_system_boq WHERE boq_id = %d;",
            $id
        )
    );

    if ($ob) {
      //  $wpdb->update('wp_zn_system_prs', ['status' => 'Boq Created'], ['pr_id' => $id]);

        

        $customer_id = $ob->customer_id;

       
        if (!empty($customer_id)) {
            $customer_info = get_customer_info($customer_id);
        }



        $q_data =   array(
                'boq_id' => $id,
                'customer'  => $customer_id, 
                'title'      => $ob->title,
                'description'  => $ob->description,
                'items' => $ob->items,
                'g_subtotal' =>  $ob->g_subtotal,
                'g_total_amount' =>  $ob->g_total_amount,
                'g_discount' =>  $ob->g_discount,
                'g_grand_total' =>  $ob->g_grand_total,
                'g_tax' =>  $ob->g_tax,
                'g_paid' => $ob->g_paid ,
                'g_due' => $ob->g_due,
                'shipping_address'  => $customer_info['address'],
                'billing_address'   => $customer_info['address'],

            );


        $new_order_id  = save_quotation_data($q_data);

  


        // After insertion, you can redirect wherever you want
        wp_redirect($homeurl . '/orders/quotations');
        exit;

    } else {
        echo "not found.";
    }
} else {
    echo 'No ID provided.';
}
?>