<?php
// brand_delete.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if(isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $brand_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Fetch brand details (optional, but good practice to check if brand exists)
    $sql = $wpdb->prepare("SELECT brand_id FROM wp_pos_system_brands WHERE brand_id = %d;", $brand_id);
    $result = $wpdb->get_results($sql);

    if (!empty($result)) {
        // Delete the brand from the database
        $sql = $wpdb->prepare("DELETE FROM wp_pos_system_brands WHERE brand_id = %d;", $brand_id);
        $wpdb->query($sql);

        status_header(200);
        wp_redirect($homeurl . '/inventory/brands');
        exit;
    } else {
        echo "Brand not found.";
    }

} else {
    echo 'No ID provided';
}
?>