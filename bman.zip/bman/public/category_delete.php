<?php
// category_delete.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $category_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Fetch category details (optional, but good practice to check if category exists)
    $sql = $wpdb->prepare("SELECT category_id FROM wp_pos_system_categories WHERE category_id = %d;", $category_id);
    $result = $wpdb->get_results($sql);

    if (!empty($result)) {
        // Delete the category from the database
        $sql = $wpdb->prepare("DELETE FROM wp_pos_system_categories WHERE category_id = %d;", $category_id);
        $wpdb->query($sql);

        status_header(200);
        wp_redirect($homeurl . '/inventory/categories');
        exit;
    } else {
        echo "Category not found.";
    }
} else {
    echo 'No ID provided';
}
?>
