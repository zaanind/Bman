<?php
// company_tools_delete.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $tool_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Fetch the tool details including the image
    $sql = $wpdb->prepare("SELECT tool_id, image FROM wp_zn_inventory_comp_tools WHERE tool_id = %d;", $tool_id);
    $result = $wpdb->get_row($sql);

    if ($result) {
        // Delete image from media library if it exists
        if (!empty($result->image)) {
            $image_data = json_decode($result->image, true);
            if (isset($image_data['id'])) {
                wp_delete_attachment($image_data['id'], true); // Delete the image permanently
            }
        }

        // Delete the tool from the database
        $sql = $wpdb->prepare("DELETE FROM wp_zn_inventory_comp_tools WHERE tool_id = %d;", $tool_id);
        $wpdb->query($sql);

        status_header(200);
        wp_redirect($homeurl . '/inventory/company-tools');
        exit;
    } else {
        echo "Tool not found.";
    }
} else {
    echo 'No ID provided';
}
?>
