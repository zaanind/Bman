<?php
session_start();

// 1. Access Control
$homeurl       = get_site_url();
$wpuser_ob     = wp_get_current_user();
$allowed_roles = array('administrator');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Retrieve existing credit record
global $wpdb;
$credits_table_name  = $wpdb->prefix . 'zn_system_credits';
$projects_table_name = $wpdb->prefix . 'zn_system_projects';

// Check if "id" is in the query string
$credit_id = 0;
$credit    = null;
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $credit_id = (int) $_GET['id'];
    $credit    = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$credits_table_name} WHERE credit_id = %d",
        $credit_id
    ));
}

// If no valid record and not posting yet, handle gracefully
if (!$credit && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = 'Invalid credit ID.';
    wp_redirect($homeurl . '/accounting/credits');
    exit;
}

// 3. Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Safety check: ensure we have a valid credit_id in POST
    if (!isset($_POST['credit_id']) || empty($_POST['credit_id'])) {
        $_SESSION['error'] = 'Missing credit ID.';
        wp_redirect($homeurl . '/accounting/credits');
        exit;
    }

    $credit_id = (int) $_POST['credit_id'];

    // Retrieve the old row (for optional project-credit difference logic)
    $old_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$credits_table_name} WHERE credit_id = %d",
        $credit_id
    ));
    if (!$old_data) {
        $_SESSION['error'] = 'Credit record not found.';
        wp_redirect($homeurl . '/accounting/credits');
        exit;
    }

    // --- (A) Gather new form data ---

    // 1) Type (send/get)
    $type = sanitize_text_field($_POST['type']);

    // If "send", we treat the sender as "Company"
    if ($type === 'send') {
        $sender_id    = get_current_user_id(); // or 0 if you prefer
        $sender_name  = "Company";
        $sender_email = "company@example.com";
        $sender_phone = "";
    }
    // If "get", the sender is external
    elseif ($type === 'get') {
        $sender_id    = 0;
        $sender_name  = sanitize_text_field($_POST['sender_name']);
        $sender_email = sanitize_email($_POST['sender_email']);
        $sender_phone = sanitize_text_field($_POST['sender_phone']);
    } else {
        // If an invalid type is submitted, handle it
        $_SESSION['error'] = 'Invalid credit type.';
        wp_redirect($homeurl . '/accounting/credits/edit?id=' . $credit_id);
        exit;
    }

    // 2) Receiver
    $for_sys = sanitize_text_field($_POST['for_sys']);
    $receiver_id    = 0;
    $receiver_name  = sanitize_text_field($_POST['receiver_name']);
    $receiver_email = sanitize_email($_POST['receiver_email']);
    $receiver_phone = sanitize_text_field($_POST['receiver_phone']);

    if ($for_sys === 'project') {
        $receiver_id    = !empty($_POST['project_id']) ? intval($_POST['project_id']) : 0;
        // If using a project, you typically ignore free-form receiver_name/email/phone
        $receiver_name  = '';
        $receiver_email = '';
        $receiver_phone = '';
    } elseif ($for_sys === 'employee') {
        $receiver_id    = !empty($_POST['employee_id']) ? intval($_POST['employee_id']) : 0;
        // If using an employee, also typically ignore free-form fields
        $receiver_name  = '';
        $receiver_email = '';
        $receiver_phone = '';
    }
    // If shop/other, we just leave receiver_id=0 and keep the free-form fields.

    // 3) Other fields
    $amount   = floatval($_POST['amount']);
    $due_date = sanitize_text_field($_POST['due_date']);
    $status   = sanitize_text_field($_POST['status']);
    $purpose  = sanitize_text_field($_POST['purpose']);

    // 4) Build JSON for sender_info and receiver_info
    $sender_info_json = json_encode([
        'name'  => $sender_name,
        'email' => $sender_email,
        'phone' => $sender_phone
    ]);
    $receiver_info_json = json_encode([
        'name'  => $receiver_name,
        'email' => $receiver_email,
        'phone' => $receiver_phone
    ]);

    // --- (B) (Optional) Adjust old/new project credit if changed ---
    // If you want to handle the scenario where the user changes from one project to another
    // or changes the amount, you can do the difference approach:
    //
    // 1. If old_for_sys === 'project', subtract old_amount from that old project's credit.
    // 2. If new_for_sys === 'project', add new_amount to the new project's credit.
    //
    // That way, the project's total credit is kept in sync.  
    // If you do NOT need this logic, remove it or skip it.

    $old_for_sys   = $old_data->for_sys;
    $old_amount    = floatval($old_data->amount);
    $old_receiver  = intval($old_data->receiver_id);

    // Subtract old amount from old project if old_for_sys == 'project'
    if ($old_for_sys === 'project' && $old_receiver > 0) {
        // Get current credit
        $current_credit = $wpdb->get_var($wpdb->prepare(
            "SELECT project_credit FROM {$projects_table_name} WHERE project_id = %d",
            $old_receiver
        ));
        $current_credit = floatval($current_credit);
        $updated_credit = $current_credit - $old_amount;
        // Update old project
        $wpdb->update(
            $projects_table_name,
            ['project_credit' => $updated_credit],
            ['project_id' => $old_receiver]
        );
    }

    // We'll update the new project after we do the main DB update
    // so that if the update fails, we won't have inconsistent data.
    // But for simplicity, we’ll do it right away—just be aware of potential partial updates.

    // --- (C) Perform the main credits table update ---
    $data = [
        'type'          => $type,
        'sender_id'     => $sender_id,
        'sender_info'   => $sender_info_json,
        'receiver_id'   => $receiver_id,
        'receiver_info' => $receiver_info_json,
        'amount'        => $amount,
        'due_date'      => $due_date,
        'status'        => $status,
        'purpose'       => $purpose,
        'for_sys'       => $for_sys,
        // You can add 'updated_at' => current_time('mysql') if your table has that column
    ];
    $where = ['credit_id' => $credit_id];

    $updated = $wpdb->update($credits_table_name, $data, $where);
    if ($updated === false) {
        $_SESSION['error'] = 'Failed to update credit record.';
        wp_redirect($homeurl . '/accounting/credits/edit?id=' . $credit_id);
        exit;
    }

    // --- (D) If new_for_sys == 'project', add the new amount to that project
    if ($for_sys === 'project' && $receiver_id > 0) {
        $current_credit = $wpdb->get_var($wpdb->prepare(
            "SELECT project_credit FROM {$projects_table_name} WHERE project_id = %d",
            $receiver_id
        ));
        $current_credit = floatval($current_credit);
        $updated_credit = $current_credit + $amount;

        $proj_upd = $wpdb->update(
            $projects_table_name,
            ['project_credit' => $updated_credit],
            ['project_id' => $receiver_id]
        );
        if ($proj_upd === false) {
            $_SESSION['error'] = 'Credit updated, but failed to update project credit.';
            wp_redirect($homeurl . '/accounting/credits/edit?id=' . $credit_id);
            exit;
        }
    }

    // If everything’s successful, redirect to credits list
    wp_redirect($homeurl . '/accounting/credits');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // Standard includes for your layout
    $active_page  = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Edit Credit | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            if (isset($_SESSION['error'])) {
                echo '<div class="alert alert-danger alert-dismissible" role="alert">';
                echo '  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                echo '  <div class="alert-message"><strong>Error:</strong> ' . esc_html($_SESSION['error']) . '</div>';
                echo '</div>';
                unset($_SESSION['error']);
            }
            ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Edit Credit</h1>
                <div class="card">
                    <div class="card-body">

                        <?php if (!empty($credit)) : ?>
                            <?php
                            // Decode sender_info and receiver_info
                            $sender_info   = json_decode($credit->sender_info, true);
                            $receiver_info = json_decode($credit->receiver_info, true);

                            // Prepare some defaults
                            $sender_name  = isset($sender_info['name'])  ? $sender_info['name']  : '';
                            $sender_email = isset($sender_info['email']) ? $sender_info['email'] : '';
                            $sender_phone = isset($sender_info['phone']) ? $sender_info['phone'] : '';

                            $receiver_name  = isset($receiver_info['name'])  ? $receiver_info['name']  : '';
                            $receiver_email = isset($receiver_info['email']) ? $receiver_info['email'] : '';
                            $receiver_phone = isset($receiver_info['phone']) ? $receiver_info['phone'] : '';
                            ?>

                            <form method="POST" 
                                  action="<?php echo esc_url($homeurl . '/accounting/credits/edit?id=' . $credit->credit_id); ?>">

                                <!-- Hidden field for credit_id -->
                                <input type="hidden" name="credit_id" 
                                       value="<?php echo esc_attr($credit->credit_id); ?>">

                                <!-- TYPE Field (send/get) -->
                                <div class="row mb-3">
                                    <div class="col-md-3">
                                        <label class="form-label">Sender Type</label>
                                        <select name="type" class="form-select" id="type">
                                            <option value="send" <?php selected($credit->type, 'send'); ?>>
                                                By Company (Credit Out)
                                            </option>
                                            <option value="get" <?php selected($credit->type, 'get'); ?>>
                                                From External (Loan In)
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <!-- SENDER Fields -->
                                <div id="companySenderFields" style="display:none;">
                                    <!-- For 'send' type, we treat the sender as Company -->
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label">Sender Name (Company)</label>
                                            <input type="text" class="form-control" 
                                                   name="sender_name_company" 
                                                   value="Company" readonly>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label">Sender Email (Company)</label>
                                            <input type="text" class="form-control" 
                                                   name="sender_email_company" 
                                                   value="company@example.com" readonly>
                                        </div>
                                    </div>
                                </div>

                                <div id="externalSenderFields" style="display:none;">
                                    <!-- For 'get' type, the sender is external -->
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label">Sender Name</label>
                                            <input type="text" class="form-control" 
                                                   name="sender_name"
                                                   value="<?php echo esc_attr($sender_name); ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label">Sender Email</label>
                                            <input type="email" class="form-control" 
                                                   name="sender_email"
                                                   value="<?php echo esc_attr($sender_email); ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label">Sender Phone</label>
                                            <input type="text" name="sender_phone" class="form-control"
                                                   value="<?php echo esc_attr($sender_phone); ?>">
                                        </div>
                                    </div>
                                </div>

                                <!-- Receiver for_sys -->
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label class="form-label">Receiver Type</label>
                                        <select name="for_sys" class="form-select" id="for_sys">
                                            <option value="project"  <?php selected($credit->for_sys, 'project'); ?>>Project</option>
                                            <option value="employee" <?php selected($credit->for_sys, 'employee'); ?>>Employee</option>
                                            <option value="shop"     <?php selected($credit->for_sys, 'shop'); ?>>Shop</option>
                                            <option value="other"    <?php selected($credit->for_sys, 'other'); ?>>Other</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Project Fields -->
                                <div id="projectFields" style="display:none;">
                                    <div class="row mb-3">
                                        <div class="col-md-3">
                                            <label class="form-label">Project ID</label>
                                            <input type="number" name="project_id" id="projectId" class="form-control"
                                                   value="<?php echo ($credit->for_sys === 'project') ? esc_attr($credit->receiver_id) : ''; ?>">
                                        </div>
                                        <div class="col-md-5">
                                            <label class="form-label">Project Title</label>
                                            <input type="text" class="form-control" id="projectTitle" autocomplete="off">
                                            <div id="projectTitle_suggestions" class="project_suggestions"></div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Employee Fields -->
                                <div id="employeeFields" style="display:none;">
                                    <div class="row mb-3">
                                        <div class="col-md-3">
                                            <label class="form-label">Employee ID</label>
                                            <input type="number" name="employee_id" class="form-control"
                                                   value="<?php echo ($credit->for_sys === 'employee') ? esc_attr($credit->receiver_id) : ''; ?>">
                                        </div>
                                    </div>
                                </div>

                                <!-- Receiver Name/Email/Phone (for shop/other) -->
                                <div id="receiverNameFields" style="display:none;">
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label">Receiver Name</label>
                                            <input type="text" name="receiver_name" class="form-control"
                                                   value="<?php echo esc_attr($receiver_name); ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Receiver Email</label>
                                            <input type="email" name="receiver_email" class="form-control"
                                                   value="<?php echo esc_attr($receiver_email); ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Receiver Phone</label>
                                            <input type="text" name="receiver_phone" class="form-control"
                                                   value="<?php echo esc_attr($receiver_phone); ?>">
                                        </div>
                                    </div>
                                </div>

                                <!-- Amount / Due Date / Status / Purpose -->
                                <div class="row mb-3">
                                    <div class="col-md-3">
                                        <label class="form-label">Amount</label>
                                        <input type="number" step="0.01" name="amount" class="form-control" required
                                               value="<?php echo esc_attr($credit->amount); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Due Date</label>
                                        <input type="date" name="due_date" class="form-control"
                                               value="<?php 
                                               $due =  date("Y-m-d", strtotime($credit->due_date));
                                               echo esc_attr($due); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Status</label>
                                        <select name="status" class="form-select">
                                            <option value="Pending"  <?php selected($credit->status, 'Pending'); ?>>Pending</option>
                                            <option value="Paid"     <?php selected($credit->status, 'Paid'); ?>>Paid</option>
                                            <option value="Approved" <?php selected($credit->status, 'Approved'); ?>>Approved</option>
                                            <option value="Overdue"  <?php selected($credit->status, 'Overdue'); ?>>Overdue</option>
                                            <option value="Closed"   <?php selected($credit->status, 'Closed'); ?>>Closed</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Purpose</label>
                                        <input type="text" name="purpose" class="form-control"
                                               value="<?php echo esc_attr($credit->purpose); ?>">
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-outline-primary float-end">
                                    Update Credit
                                </button>
                            </form>
                        <?php else : ?>
                            <p>Invalid or missing credit data.</p>
                        <?php endif; ?>
                    </div><!-- card-body -->
                </div><!-- card -->
            </div><!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<!-- jQuery Toggling Logic for Sender and Project/Employee Fields -->
<script>
jQuery(document).ready(function($){
    function toggleSenderFields(typeVal) {
        if (typeVal === 'get') {
            $('#externalSenderFields').show();
            $('#companySenderFields').hide();
        } else { // 'send' or anything else
            $('#externalSenderFields').hide();
            $('#companySenderFields').show();
        }
    }

    function toggleReceiverFields(forSysVal) {
        if (forSysVal === 'project') {
            $('#projectFields').show();
            $('#employeeFields').hide();
            $('#receiverNameFields').hide();
        } else if (forSysVal === 'employee') {
            $('#projectFields').hide();
            $('#employeeFields').show();
            $('#receiverNameFields').hide();
        } else {
            // shop or other
            $('#projectFields').hide();
            $('#employeeFields').hide();
            $('#receiverNameFields').show();
        }
    }

    // On page load, set up the correct visibility
    toggleSenderFields($('#type').val());
    toggleReceiverFields($('#for_sys').val());

    // On change of 'type'
    $('#type').change(function(){
        toggleSenderFields($(this).val());
    });

    // On change of 'for_sys'
    $('#for_sys').change(function(){
        toggleReceiverFields($(this).val());
    });

    // (Optional) AJAX for searching projects by title
    function fetchProjectData(fieldId) {
        let query = $(fieldId).val();
        let suggestionBox = fieldId + "_suggestions";

        if (query.length > 2) { // More than 2 characters
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api", // or a dedicated projects API
                method: "POST",
                data: { search_project_query_name: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(project => {
                            suggestions += `<div class='suggestion-item'
                                              data-project-id='${project.id || ""}'
                                              data-project-name='${project.name || ""}'>
                                                ${project.name || "Unknown"} - ID: ${project.id || "N/A"}
                                            </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    }

    // Project search keyup
    $("#projectTitle").keyup(function() {
        fetchProjectData("#projectTitle");
    });

    // Select a project from suggestions
    $(document).on("click", ".suggestion-item", function() {
        let selectedProjectId   = $(this).data("project-id");
        let selectedProjectName = $(this).data("project-name");

        $("#projectId").val(selectedProjectId);
        $("#projectTitle").val(selectedProjectName);
        $(".project_suggestions").hide();
    });

    // Hide suggestions if clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest(".project_suggestions, #projectTitle").length) {
            $(".project_suggestions").hide();
        }
    });
});
</script>
</body>
</html>