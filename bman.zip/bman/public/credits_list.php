<?php
session_start();

// Restrict to admin or whichever roles can view credits
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator'); // Adjust if needed

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'zn_system_credits';

// Fetch all credits in descending order
$credits = $wpdb->get_results("
    SELECT * 
    FROM $table_name
    ORDER BY credit_id DESC
");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // For sidebar highlighting
    $active_page = get_query_var('active_page_wp_pos'); 
    $active_sub_m = get_query_var('active_sub_m'); 
    include_once('header.php');
    ?>
    <title>Credits | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <!-- "New Credit" button -->
                <a href="<?php echo get_site_url(); ?>/accounting/credits/add" 
                   class="btn btn-primary float-end mt-n1">
                    <i class="fas fa-plus"></i> New Credit
                </a>

                <h1 class="h3 mb-3">Credits List</h1>

                <div class="card">
                    <div class="card-body">
                        <table id="creditsTable" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <!--th>Credit ID</th-->
                                    <th>Sender</th>
                                    <th> Receiver</th>
                                    <th>Amount</th>
                                    <th>Due</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($credits): ?>
                                    <?php foreach ($credits as $row): ?>
                                        <?php
                                        // Decode JSON for sender/receiver
                                        $sender_info   = !empty($row->sender_info) ? json_decode($row->sender_info, true) : [];
                                        $receiver_info = !empty($row->receiver_info) ? json_decode($row->receiver_info, true) : [];

                                        // Build "sender" display text
                                        // e.g., "ABC Pvt Ltd (info@abc.com)"
                                        $sender_display = '';
                                        if (!empty($sender_info['name'])) {
                                            $sender_display = $sender_info['name'];
                                            if (!empty($sender_info['email'])) {
                                              //  $sender_display .= " ({$sender_info['email']})";
                                            }
                                        } else {
                                            // fallback: show the sender_id
                                            $sender_display = "ID: " . $row->sender_id;
                                        }

                                        // Build "receiver" display text
                                        $receiver_display = '';
                                        if (!empty($receiver_info['name'])) {
                                            $receiver_display = $receiver_info['name'];
                                            if (!empty($receiver_info['email'])) {
                                              //  $receiver_display .= " ({$receiver_info['email']})";
                                            }
                                        } else {
                                            // fallback: show the receiver_id
                                            $receiver_display = "ID: " . $row->receiver_id;
                                        }

                                        // Format due_date if present
                                        $due_date_str = '-';
                                        if (!empty($row->due_date) && $row->due_date !== '0000-00-00 00:00:00') {
                                            $due_date_str = date('Y-m-d', strtotime($row->due_date));
                                        }
                                        ?>
                                        <tr>
                                            <!--td><?php echo esc_html($row->credit_id); ?></td-->
                                            <td><?php echo esc_html($sender_display); ?></td>
                                            <td><?php echo esc_html($receiver_display); ?></td>
                                            <td><?php echo number_format($row->amount, 2); ?></td>
                                            <td><?php echo esc_html($due_date_str); ?></td>
                                            <td><?php echo esc_html($row->status); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button" 
                                                            class="btn btn-primary dropdown-toggle" 
                                                            data-bs-toggle="dropdown" 
                                                            aria-expanded="false">
                                                        Actions
                                                    </button>
                                                    <ul class="dropdown-menu">
                                                        <!--li><a class="dropdown-item" href="#">View</a></li-->
                                                        <li><a class='dropdown-item' href='<?php echo get_site_url(); ?>/accounting/credits/edit?id=<?php echo $row->credit_id; ?>'>Edit</a></li>
                                                        <li><a class="dropdown-item" href="<?php echo get_site_url(); ?>/accounting/credits/delete?id=<?php echo $row->credit_id; ?>" >Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div><!-- card-body -->
                </div><!-- card -->
            </div><!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // Initialize DataTables
    jQuery("#creditsTable").DataTable({
        responsive: true
    });
});
</script>
</body>
</html>
