<?php


$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator',);


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}




 ?>


 <!DOCTYPE html>
<html lang="en">
<head>



   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title>Customers | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



	<main class="content">
	<div class="container-fluid p-0">
	<a href="<?php echo get_site_url(); ?>/customers/add" class="btn btn-primary float-end mt-n1"><i class="fas fa-plus"></i> New Customer</a>

					<div class="mb-3">
						<h1 class="h3 d-inline align-middle">Customers</h1>
					</div>

					<div class="row">
						<div class="col-12">
							
							<div class="card">
								
								<div class="card-body">
									<table id="datatables-reponsive" class="table table-striped" style="width:100%">
										<thead>
											<tr>
												<th>Customer Name</th>
												<th>Email</th>
												<th>Phone number</th>
												<th>Action</th>
											</tr>
										</thead>
										
	<?php
     global $wpdb;
     $customers = $wpdb->get_results("SELECT customer_id ,name,email,phone_number,address FROM wp_pos_system_customers");                               


	?>
										<tbody>
										
	<?php 
										
     foreach ($customers as $row) {
           echo '<tr>';
   
           echo "<td>" . $row->name . "</td>";
		   echo "<td>" . $row->email . "</td>";
		    echo "<td>" . $row->phone_number . "</td>";

		   echo "<td> <div class='btn-group'> <button type='button' class='btn btn-primary dropdown-toggle' data-bs-toggle='dropdown' aria-expanded='false'>Actions</button> 
		   <ul class='dropdown-menu'>
		   <li><a class='dropdown-item' href='" .get_site_url() ."/customers/view?id=". $row->customer_id."'>View</a></li>

		   <li><a class='dropdown-item' href='" .get_site_url() ."/customers/edit?id=". $row->customer_id."'>Edit</a></li>
		   <li><a class='dropdown-item' href='" .get_site_url() ."/customers/delete?id=". $row->customer_id."'>Delete</a></li>

		   </ul></div>
		   </td>";

           echo '</tr>';
    }
																	
										
	?>
									
	</tbody></table>
	</div>
	</div>
	</div>
	</div>
    </div>
	
	
	
	</main>
	
			
			<?php include_once('footer.php');?>
		</div>
	</div>

			<script>
		document.addEventListener("DOMContentLoaded", function() {
			// Datatables Responsive
			$("#datatables-reponsive").DataTable({
				responsive: true
		
			});
		});
	</script>
	
</body>

</html>