<?php
session_start();

// 1. Access Control
$homeurl       = get_site_url();
$wpuser_ob     = wp_get_current_user();
$allowed_roles = array('administrator');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Retrieve the customer record to edit
global $wpdb;
$table_name = $wpdb->prefix . 'pos_system_customers';

// Check for a valid "id" in the query string
$customer_id = 0;
$customer    = null;
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $customer_id = (int) $_GET['id'];
    $customer    = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table_name} WHERE customer_id = %d",
        $customer_id
    ));
}

// If no valid record found (and not posting yet), handle gracefully
if (!$customer && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = 'Invalid customer ID.';
    wp_redirect($homeurl . '/customers/');
    exit;
}

// 3. Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Safety check: ensure we have a customer_id in POST
    if (!isset($_POST['customer_id']) || empty($_POST['customer_id'])) {
        $_SESSION['error'] = 'Missing customer ID.';
        wp_redirect($homeurl . '/customers/');
        exit;
    }

    $customer_id = (int) $_POST['customer_id'];

    // Gather form data (sanitize as needed)
    $pname       = sanitize_text_field($_POST['name']);
    $pemail      = sanitize_text_field($_POST['email']);
    $pnumber     = sanitize_text_field($_POST['phone_number']);
    $paddress    = sanitize_text_field($_POST['address']);

    // Build data array for update
    $data = array(
        'name'         => $pname,
        'email'        => $pemail,
        'phone_number' => $pnumber,
        'address'      => $paddress,
        'updated_at'   => current_time('mysql'), // optional, if you have an updated_at column
    );

    $where = array('customer_id' => $customer_id);

    // Perform the update
    $updated = $wpdb->update($table_name, $data, $where);

    if ($updated === false) {
        // If false, there was a DB error
        $_SESSION['error'] = 'Failed to update customer.';
        wp_redirect($homeurl . '/customers/edit?id=' . $customer_id);
        exit;
    }

    // On success (or no changes = 0 rows affected), redirect to listing
    wp_redirect($homeurl . '/customers/');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // Standard includes for your theme
    $active_page  = get_query_var('active_page_wp_pos'); 
    $active_sub_m = get_query_var('active_sub_m'); 
    include_once('header.php'); 
    ?>
    <title>Edit Customer | <?php echo get_bloginfo('name'); ?></title>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            // Show error messages (if any)
            if (isset($_SESSION['error'])) {
                $err = $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Error:</strong> <?php echo esc_html($err); ?>
                    </div>
                </div>
            <?php } ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Edit Customer</h1>

                <div class="row">
                    <div class="col-12">
                        <div class="card">	
                            <div class="card-body">
                                <?php if (!empty($customer)) : ?>
                                    <form method="POST" 
                                          action="<?php echo esc_url($homeurl . '/customers/edit?id=' . $customer->customer_id); ?>">
                                        <!-- Hidden input for the customer ID -->
                                        <input type="hidden" name="customer_id" 
                                               value="<?php echo esc_attr($customer->customer_id); ?>">

                                        <!-- Name -->
                                        <div class="mb-3">
                                            <label class="form-label">Customer Name:</label>
                                            <input type="text" class="form-control" name="name" required
                                                   value="<?php echo esc_attr($customer->name); ?>">
                                        </div>

                                        <!-- Email -->
                                        <div class="mb-3">
                                            <label class="form-label">Customer Email:</label>
                                            <input type="text" class="form-control" name="email" required
                                                   value="<?php echo esc_attr($customer->email); ?>">
                                        </div>

                                        <!-- Phone Number -->
                                        <div class="mb-3">
                                            <label class="form-label">Customer Phone Number:</label>
                                            <input type="text" class="form-control" name="phone_number" required
                                                   value="<?php echo esc_attr($customer->phone_number); ?>">
                                        </div>

                                        <!-- Address -->
                                        <div class="mb-3">
                                            <label class="form-label">Address:</label>
                                            <input type="text" class="form-control" name="address"
                                                   value="<?php echo esc_attr($customer->address); ?>">
                                        </div>

                                        <button class="btn btn-outline-primary float-end" type="submit">Update</button>
                                    </form>
                                <?php else : ?>
                                    <p>No customer found or invalid ID.</p>
                                <?php endif; ?>
                            </div> <!-- card-body -->
                        </div> <!-- card -->
                    </div> <!-- col-12 -->
                </div> <!-- row -->
            </div> <!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>
</body>
</html>