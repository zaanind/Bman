<?php
session_start();

// 1) Check user roles
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator'); // Add 'employee' or others if needed

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2) Fetch the customer record from DB
global $wpdb;
$table_name = $wpdb->prefix . 'pos_system_customers'; // Matches your insert code

$customer_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$customer_id) {
    // If no ID provided, redirect back to listing
    wp_redirect($homeurl . '/customers');
    exit;
}

// Fetch the record
$customer = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table_name} WHERE customer_id = %d", $customer_id)
);

// If record not found, redirect
if (!$customer) {
    wp_redirect($homeurl . '/customers');
    exit;
}

// 3) Decode JSON for image (if stored as JSON with attachment ID)
$image_data = !empty($customer->image) ? json_decode($customer->image, true) : [];
$attachment_url = '';
if (!empty($image_data['id'])) {
    $attachment_url = wp_get_attachment_url($image_data['id']);
}

// 4) Include your standard WP-Pos header
$active_page = get_query_var('active_page_wp_pos');
$active_sub_m = get_query_var('active_sub_m');
include_once('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Customer | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">View Customer</h1>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Customer Details</h5>
                            </div>
                            <div class="card-body">
                                <!-- Name -->
                                <div class="mb-3">
                                    <label class="form-label">Name:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($customer->name); ?>" 
                                           readonly>
                                </div>

                                <!-- Email -->
                                <div class="mb-3">
                                    <label class="form-label">Email:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($customer->email); ?>" 
                                           readonly>
                                </div>

                                <!-- Phone Number -->
                                <div class="mb-3">
                                    <label class="form-label">Phone Number:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($customer->phone_number); ?>" 
                                           readonly>
                                </div>

                                <!-- Address -->
                                <div class="mb-3">
                                    <label class="form-label">Address:</label>
                                    <textarea class="form-control" rows="2" readonly><?php
                                        echo esc_textarea($customer->address);
                                    ?></textarea>
                                </div>

                                <!-- Total Spent -->
                                <!--div class="mb-3">
                                    <label class="form-label">Total Spent:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($customer->total_spent); ?>" 
                                           readonly>
                                </div-->

                                <!-- Created At -->
                                <div class="mb-3">
                                    <label class="form-label">Created At:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($customer->created_at); ?>" 
                                           readonly>
                                </div>

                                <!-- Updated At -->
                                <div class="mb-3">
                                    <label class="form-label">Updated At:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($customer->updated_at); ?>" 
                                           readonly>
                                </div>

                                <!-- Type -->
                                <!--div class="mb-3">
                                    <label class="form-label">Type:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($customer->type); ?>" 
                                           readonly>
                                </div-->

                                <!-- Image (if stored) -->
                                <?php if ($attachment_url): ?>
                                    <!--div class="mb-3">
                                        <label class="form-label d-block">Image:</label>
                                        <img src="<?php echo esc_url($attachment_url); ?>" 
                                             alt="Customer Image" 
                                             style="max-width: 300px; height:auto;">
                                    </div-->
                                <?php else: ?>
                                    <!--div class="mb-3">
                                        <label class="form-label">Image:</label>
                                        <p>No image available.</p>
                                    </div-->
                                <?php endif; ?>

                            </div> <!-- card-body -->
                        </div> <!-- card -->
                    </div> <!-- col-12 -->
                </div> <!-- row -->
            </div> <!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div> <!-- main -->
</div> <!-- wrapper -->
</body>
</html>
