<?php
// delete_credit.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $credit_id = intval($_GET['id']); // Sanitize input

    // Delete the credit record from the database
    $deleted = $wpdb->delete('wp_zn_system_credits', ['credit_id' => $credit_id]);

    if ($deleted !== false) {
        // Redirect back to the credits list after deletion
        wp_redirect($homeurl . '/accounting/credits');
        exit;
    } else {
        echo "Failed to delete credit record.";
    }
} else {
    echo 'No Credit ID provided';
}
?>