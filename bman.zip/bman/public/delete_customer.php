<?php
// delete_customer.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $customer_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Check if the customer exists
    $sql = $wpdb->prepare("SELECT customer_id FROM wp_pos_system_customers WHERE customer_id = %d;", $customer_id);
    $result = $wpdb->get_row($sql);

    if ($result) {
        // Delete the customer
        $sql = $wpdb->prepare("DELETE FROM wp_pos_system_customers WHERE customer_id = %d;", $customer_id);
        $wpdb->query($sql);

        status_header(200);
        wp_redirect($homeurl . '/customers');
        exit;
    } else {
        echo "Customer not found.";
    }
} else {
    echo 'No Customer ID provided';
}
?>
