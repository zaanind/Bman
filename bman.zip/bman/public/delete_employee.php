<?php
// delete_employee.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $employee_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Get employee details
    $employee = $wpdb->get_row($wpdb->prepare("SELECT * FROM wp_zn_system_employee WHERE employee_id = %d;", $employee_id));

    if ($employee) {
        // Delete associated image from WordPress media library
        if (!empty($employee->image)) {
            $image_data = json_decode($employee->image, true);
            if (!empty($image_data['id'])) {
                wp_delete_attachment($image_data['id'], true); // Delete the image permanently
            }
        }

        // Delete the WordPress user
        require_once(ABSPATH . 'wp-admin/includes/user.php');
        wp_delete_user($employee_id);

        // Delete the employee from the database
        $wpdb->delete('wp_zn_system_employee', ['employee_id' => $employee_id]);

        // Redirect back to the employee list
        wp_redirect($homeurl . '/hr/employee-list');
        exit;
    } else {
        echo "Employee not found.";
    }
} else {
    echo 'No Employee ID provided';
}
?>