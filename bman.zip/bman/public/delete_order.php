<?php 
// delete_order.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $order_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Fetch the barcode attachment ID from the database
    $sql = $wpdb->prepare("SELECT barcode FROM wp_pos_system_orders WHERE order_id = %d;", $order_id);
    $order = $wpdb->get_row($sql);

    if ($order) {
        $barcode_attachment_id = intval($order->barcode);

        if (!empty($order->barcode)) {

            wp_delete_attachment($order->barcode, true);


           
        }

        // Delete the order from the database
        $sql = $wpdb->prepare("DELETE FROM wp_pos_system_orders WHERE order_id = %d;", $order_id);
        $wpdb->query($sql);

        status_header(200);
        wp_redirect($homeurl . '/orders');
        exit;
    } else {
        echo "Order not found.";
    }
} else {
    echo 'No Order ID provided';
}
?>


<?php
// delete_order.php - located in the 'public' directory of your plugin
/*
$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $order_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Check if the order exists
    $sql = $wpdb->prepare("SELECT order_id FROM wp_pos_system_orders WHERE order_id = %d;", $order_id);
    $result = $wpdb->get_row($sql);

    if ($result) {
        // Delete the order
        $sql = $wpdb->prepare("DELETE FROM wp_pos_system_orders WHERE order_id = %d;", $order_id);
        $wpdb->query($sql);

        status_header(200);
        wp_redirect($homeurl . '/orders');
        exit;
    } else {
        echo "Order not found.";
    }
} else {
    echo 'No Order ID provided';
} */
?>