<?php
// delete_quotation.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $pr_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Debug: Output the ID being received
    echo "Received ID: " . $pr_id;  // Check if the ID is correct

    // Check if the quotation exists
    $sql = $wpdb->prepare("SELECT pr_id FROM wp_zn_system_prs WHERE pr_id = %d;", $pr_id);
    $result = $wpdb->get_row($sql);

    // Debug: Output SQL query for debugging
    echo "SQL Query: " . $wpdb->last_query;  // Check the actual query executed

    if ($result) {
        // Delete the quotation
        $sql = $wpdb->prepare("DELETE FROM wp_zn_system_prs WHERE pr_id = %d;", $pr_id);
        $deleted = $wpdb->query($sql);

        // Check if the deletion was successful
        if ($deleted !== false) {
            status_header(200);
            wp_redirect($homeurl . '/orders/purchase-requests'); // Redirect after successful deletion
            exit;
        } else {
            echo "Error: Deletion failed.";
        }
    } else {
        echo "Order not found for ID: " . $pr_id;  // Include the pr_id for better debugging
    }
} else {
    echo 'No ID provided';
}
?>