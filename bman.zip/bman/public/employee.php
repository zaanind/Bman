<!DOCTYPE html>
<html lang="en">
<head>
   
   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   include_once('header.php'); ?>
	<title><?php echo get_bloginfo( 'name' ); ?></title>


</head>

<?php
global $wpdb;


$sales = 0;
$sales_db = $wpdb->get_results("SELECT items FROM wp_pos_system_orders");

foreach ($sales_db as $row) {
    $itemjson = $row->items;
    $decoded_json = json_decode($itemjson, true); 

    foreach ($decoded_json as $item) {
        
        $sales += $item['quantity'];
    }
}


$today_sales = 0;
$today_sales_db = $wpdb->get_results("SELECT items FROM wp_pos_system_orders WHERE DATE(updated_at) = CURDATE()");
foreach ($today_sales_db as $row) {
    $itemjson = $row->items;
    $decoded_json = json_decode($itemjson, true); 

    foreach ($decoded_json as $item) {
        
        $today_sales += $item['quantity'];
    }
}


$earnings =0;
$earnings_db =  $wpdb->get_results("SELECT g_paid FROM wp_pos_system_orders");
foreach ($earnings_db as $row) {
    $grand_paid = (int) $row->g_paid;
    $earnings += $grand_paid;
}






$order_count = 0;
$orders_db = $wpdb->get_var("SELECT COUNT(*) FROM wp_pos_system_orders");


$today_earnings = 0;
$today_earnings_db =  $wpdb->get_results("SELECT g_paid FROM wp_pos_system_orders WHERE DATE(updated_at) = CURDATE()");
foreach ($today_earnings_db as $row) {
    $today_grand_paid = (int) $row->g_paid;
    $today_earnings += $today_grand_paid;
}


$today_order_count = $wpdb->get_var("SELECT COUNT(*) FROM wp_pos_system_orders WHERE DATE(updated_at) = CURDATE()");


$customers = $wpdb->get_var("SELECT COUNT(*) FROM wp_pos_system_customers");


$today_customers = $wpdb->get_var("SELECT COUNT(*) FROM wp_pos_system_customers WHERE DATE(updated_at) = CURDATE()");


$products_c = $wpdb->get_var("SELECT COUNT(*) FROM wp_pos_system_inventory_products");

$today_products_c = $wpdb->get_var("SELECT COUNT(*) FROM wp_pos_system_inventory_products WHERE DATE(updated_at) = CURDATE()");

?>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>
			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3"><strong></strong>Employee Dashboard</h1>

					<div class="row">
						<div class="col-xl-6 col-xxl-5 d-flex">
							<div class="w-100">
								<div class="row">
									<div class="col-sm-4">
										<div class="card">
											<div class="card-body">
												<div class="row">
													<div class="col mt-0">
														<h5 class="card-title">No of Sales</h5>
													</div>

													<div class="col-auto">
														<div class="stat text-primary">
															<i class="align-middle" data-feather="truck"></i>
														</div>
													</div>
												</div>
												<h1 class="mt-1 mb-3"><?php echo $sales; ?></h1>
												<div class="mb-0">  
													<span class="text-success"> <i class="mdi mdi-arrow-bottom-right"></i> <?php echo $today_sales; ?> </span>
													<span class="text-muted">Today</span>
												</div>
											</div>
										</div>
										<div class="card">
											<div class="card-body">
												<div class="row">
													<div class="col mt-0">
														<h5 class="card-title">Customers</h5>
													</div>

													<div class="col-auto">
														<div class="stat text-primary">
															<i class="align-middle" data-feather="users"></i>
														</div>
													</div>
												</div>
												<h1 class="mt-1 mb-3"><?php echo $customers; ?></h1>
												<div class="mb-0">
													<span class="text-success"> <i class="mdi mdi-arrow-bottom-right"></i><?php echo $today_customers; ?> </span>
													<span class="text-muted">Today</span>
												</div>
											</div>
										</div>
								
									</div>
									
									
									<div class="col-sm-4">
										<div class="card">
											<div class="card-body">
												<div class="row">
													<div class="col mt-0">
														<h5 class="card-title">Earnings</h5>
													</div>

													<div class="col-auto">
														<div class="stat text-primary">
															<i class="align-middle" data-feather="dollar-sign"></i>
														</div>
													</div>
												</div>
												<h1 class="mt-1 mb-3"><?php echo '$'.$earnings; ?></h1>
												<div class="mb-0">
													<span class="text-success"> <i class="mdi mdi-arrow-bottom-right"></i> $<?php echo $today_earnings; ?>  </span>
													<span class="text-muted">Today</span>
												</div>
											</div>
										</div>
										<div class="card">
											<div class="card-body">
												<div class="row">
													<div class="col mt-0">
														<h5 class="card-title">Orders</h5>
													</div>

													<div class="col-auto">
														<div class="stat text-primary">
															<i class="align-middle" data-feather="shopping-cart"></i>
														</div>
													</div>
												</div>
												<h1 class="mt-1 mb-3"><?php echo $orders_db; ?></h1>
												<div class="mb-0">
													<span class="text-success"  old="text-danger"> <i class="mdi mdi-arrow-bottom-right"></i> <?php echo $today_order_count; ?> </span>
													<span class="text-muted">Today</span>
												</div>
											</div>
										</div>
									</div>
									
									
									<div class="col-sm-4">
									<div class="card">
											<div class="card-body">
												<div class="row">
													<div class="col mt-0">
														<h5 class="card-title">Total Products </h5>
												</div>

												<div class="col-auto">
											  	<div class="stat text-primary">
															<i class="align-middle" data-feather="box"></i>
														</div>
													</div>
												</div>
												<h1 class="mt-1 mb-3"><?php echo $products_c; ?></h1>
									
												<div class="mb-0">
													<span class="text-success"> <i class="mdi mdi-arrow-bottom-right"></i><?php echo $today_products_c; ?> </span>
													<span class="text-muted">Today</span>
												</div>
											</div>
										</div>

									</div>
								</div>
							</div>
						</div>

						<div class="col-xl-6 col-xxl-7">
							<div class="card flex-fill w-100">
								<div class="card-header">

									<h5 class="card-title mb-0"> Last 14 Day's Earnings</h5>
								</div>
								<div class="card-body py-3">
									<div class="chart chart-sm">
										<canvas id="chartjs-dashboard-line"></canvas>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-12 col-md-6 col-xxl-3 d-flex order-2 order-xxl-3">
							<div class="card flex-fill w-100">
								<div class="card-header">

									<h5 class="card-title mb-0">Browser Usage</h5>
								</div>
								<div class="card-body d-flex">
									<div class="align-self-center w-100">
										<div class="py-3">
											<div class="chart chart-xs">
												<canvas id="chartjs-dashboard-pie"></canvas>
											</div>
										</div>

										<table class="table mb-0">
											<tbody>
												<tr>
													<td>Chrome</td>
													<td class="text-end">4306</td>
												</tr>
												<tr>
													<td>Firefox</td>
													<td class="text-end">3801</td>
												</tr>
												<tr>
													<td>IE</td>
													<td class="text-end">1689</td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<!--div class="col-12 col-md-12 col-xxl-6 d-flex order-3 order-xxl-2">
							<div class="card flex-fill w-100">
								<div class="card-header">

									<h5 class="card-title mb-0">Real-Time</h5>
								</div>
								<div class="card-body px-4">
									<div id="world_map" style="height:350px;"></div>
								</div>
							</div>
						</div-->
						<div class="col-12 col-md-6 col-xxl-3 d-flex order-1 order-xxl-1">
							<div class="card flex-fill">
								<div class="card-header">

									<h5 class="card-title mb-0">Calendar</h5>
								</div>
								<div class="card-body d-flex">
									<div class="align-self-center w-100">
										<div class="chart">
											<div id="datetimepicker-dashboard"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-12 col-lg-8 col-xxl-9 d-flex">
							<div class="card flex-fill">
								<div class="card-header">

									<h5 class="card-title mb-0">Sales By Sales man</h5>
								</div>
								<table class="table table-hover my-0">
									<thead>
										<tr>
											<th>Name</th>
											<th class="d-none d-xl-table-cell">Start Date</th>
											<th class="d-none d-xl-table-cell">End Date</th>
											<th>Status</th>
											<th class="d-none d-md-table-cell">Assignee</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Project Apollo</td>
											<td class="d-none d-xl-table-cell">01/01/2023</td>
											<td class="d-none d-xl-table-cell">31/06/2023</td>
											<td><span class="badge bg-success">Done</span></td>
											<td class="d-none d-md-table-cell">Vanessa Tucker</td>
										</tr>
										<tr>
											<td>Project Fireball</td>
											<td class="d-none d-xl-table-cell">01/01/2023</td>
											<td class="d-none d-xl-table-cell">31/06/2023</td>
											<td><span class="badge bg-danger">Cancelled</span></td>
											<td class="d-none d-md-table-cell">William Harris</td>
										</tr>
										<tr>
											<td>Project Hades</td>
											<td class="d-none d-xl-table-cell">01/01/2023</td>
											<td class="d-none d-xl-table-cell">31/06/2023</td>
											<td><span class="badge bg-success">Done</span></td>
											<td class="d-none d-md-table-cell">Sharon Lessman</td>
										</tr>
										<tr>
											<td>Project Nitro</td>
											<td class="d-none d-xl-table-cell">01/01/2023</td>
											<td class="d-none d-xl-table-cell">31/06/2023</td>
											<td><span class="badge bg-warning">In progress</span></td>
											<td class="d-none d-md-table-cell">Vanessa Tucker</td>
										</tr>
										<tr>
											<td>Project Phoenix</td>
											<td class="d-none d-xl-table-cell">01/01/2023</td>
											<td class="d-none d-xl-table-cell">31/06/2023</td>
											<td><span class="badge bg-success">Done</span></td>
											<td class="d-none d-md-table-cell">William Harris</td>
										</tr>
										<tr>
											<td>Project X</td>
											<td class="d-none d-xl-table-cell">01/01/2023</td>
											<td class="d-none d-xl-table-cell">31/06/2023</td>
											<td><span class="badge bg-success">Done</span></td>
											<td class="d-none d-md-table-cell">Sharon Lessman</td>
										</tr>
										<tr>
											<td>Project Romeo</td>
											<td class="d-none d-xl-table-cell">01/01/2023</td>
											<td class="d-none d-xl-table-cell">31/06/2023</td>
											<td><span class="badge bg-success">Done</span></td>
											<td class="d-none d-md-table-cell">Christina Mason</td>
										</tr>
										<tr>
											<td>Project Wombat</td>
											<td class="d-none d-xl-table-cell">01/01/2023</td>
											<td class="d-none d-xl-table-cell">31/06/2023</td>
											<td><span class="badge bg-warning">In progress</span></td>
											<td class="d-none d-md-table-cell">William Harris</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
						<div class="col-12 col-lg-4 col-xxl-3 d-flex">
							<div class="card flex-fill w-100">
								<div class="card-header">

									<h5 class="card-title mb-0">Monthly Sales</h5>
								</div>
								<div class="card-body d-flex w-100">
									<div class="align-self-center chart chart-lg">
										<canvas id="chartjs-dashboard-bar"></canvas>
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

			
			
			
			
			<?php include_once('footer.php');?>
		</div>
	</div>

	<?php 
	
	
function calculateStepSize($earnings) {
    // Array defining ranges and corresponding step sizes in multiples of 10 (10x, 100x, 1000x, etc.)
    $ranges = [
       // [0, 10, 1],           // Earnings from 0 to 10, step size 1
        [10, 100, 10],        // Earnings from 10 to 100, step size 10
        [100, 1000, 100],     // Earnings from 100 to 1000, step size 100
        [1000, 10000, 1000],  // Earnings from 1000 to 10000, step size 1000
        [10000, 100000, 10000], // Earnings from 10000 to 100000, step size 10000
        [100000, 1000000, 100000], // Earnings from 100000 to 1000000, step size 100000
        [1000000, PHP_INT_MAX, 1000000]  // Earnings from 1000000 upwards, step size 1000000
    ];

    // Check if earnings is less than or equal to 0
    if ($earnings <= 0) {
        return 10;
    }

    // Loop through the ranges and return the corresponding step size
    foreach ($ranges as $range) {
        if ($earnings >= $range[0] && $earnings < $range[1]) {
            return $range[2];
        }
    }

    return 1;
}


$yAxis =  calculateStepSize($earnings);



//Chart Calculation 


$is_date = true;  // Set this to true for days, false for months
$today_earnings = [];
$dates_or_months = [];  // To store the corresponding dates or month names

if ($is_date) {
    // For last 12 days
    for ($i = 13; $i >= 0; $i--) {  // Start from 13 down to 0
        // Get the date for the last 12 days
        $date = date('Y-m-d', strtotime("-$i days"));
        $day_name = date('D', strtotime($date)); // Get the day of the week (e.g., Monday)

        // Get the earnings for that specific date
        $today_earnings_db = $wpdb->get_results(
            $wpdb->prepare("SELECT g_paid FROM wp_pos_system_orders WHERE DATE(updated_at) = %s", $date)
        );

        $daily_earnings = 0;
        foreach ($today_earnings_db as $row) {
            $daily_earnings += (int) $row->g_paid;
        }

        // Store earnings and corresponding day name
        $today_earnings[] = $daily_earnings;
        $dates_or_months[] = "$day_name"; //"$day_name, $date"; // Store the day name and the date
    }
}
 else {
    // For last 12 months
    for ($i = 0; $i < 12; $i++) {
        // Get the first day of the month for the last 12 months
        $month_start = date('Y-m-01', strtotime("-$i months"));
        $month_name = date('F', strtotime($month_start)); // Get the month name (e.g., January)

        // Get the earnings for that specific month
        $today_earnings_db = $wpdb->get_results(
            $wpdb->prepare("SELECT g_paid FROM wp_pos_system_orders WHERE DATE_FORMAT(updated_at, '%Y-%m') = %s", date('Y-m', strtotime($month_start)))
        );

        $monthly_earnings = 0;
        foreach ($today_earnings_db as $row) {
            $monthly_earnings += (int) $row->g_paid;
        }

        // Store earnings and corresponding month name
        $today_earnings[] = $monthly_earnings;
        $dates_or_months[] = $month_name; // Store the month name
    }
}




 ?>

	<script>
		document.addEventListener("DOMContentLoaded", function() {
			var ctx = document.getElementById("chartjs-dashboard-line").getContext("2d");
			var gradient = ctx.createLinearGradient(0, 0, 0, 225);
			gradient.addColorStop(0, "rgba(215, 227, 244, 1)");
			gradient.addColorStop(1, "rgba(215, 227, 244, 0)");
			// Line chart
			new Chart(document.getElementById("chartjs-dashboard-line"), {
				type: "line",
				data: {
					//labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
					labels: [
					<?php foreach ($dates_or_months as $key => $date_or_month) {
						echo '"'.$date_or_month.'",';
					}
					?>
					],
					datasets: [{
						label: "Earnings ($)",
						fill: true,
						backgroundColor: gradient,
						borderColor: window.theme.primary,
						data: [
							<?php foreach ($dates_or_months as $key => $date_or_month) {
						echo '"'.$today_earnings[$key].'",';
					}
					?>
						]
					}]
				},
				options: {
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					tooltips: {
						intersect: false
					},
					hover: {
						intersect: true
					},
					plugins: {
						filler: {
							propagate: false
						}
					},
					scales: {
						xAxes: [{
							reverse: true,
							gridLines: {
								color: "rgba(0,0,0,0.0)"
							}
						}],
						yAxes: [{
							ticks: {
								stepSize: <?php echo $yAxis; ?>
							},
							display: true,
							borderDash: [3, 3],
							gridLines: {
								color: "rgba(0,0,0,0.0)"
							}
						}]
					}
				}
			});
		});
	</script>
	<script>
		document.addEventListener("DOMContentLoaded", function() {
			// Pie chart
			new Chart(document.getElementById("chartjs-dashboard-pie"), {
				type: "pie",
				data: {
					labels: ["Chrome", "Firefox", "IE"],
					datasets: [{
						data: [4306, 3801, 1689],
						backgroundColor: [
							window.theme.primary,
							window.theme.warning,
							window.theme.danger
						],
						borderWidth: 5
					}]
				},
				options: {
					responsive: !window.MSInputMethodContext,
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					cutoutPercentage: 75
				}
			});
		});
	</script>
	<script>
		document.addEventListener("DOMContentLoaded", function() {
			// Bar chart
			new Chart(document.getElementById("chartjs-dashboard-bar"), {
				type: "bar",
				data: {
					labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
					datasets: [{
						label: "This year",
						backgroundColor: window.theme.primary,
						borderColor: window.theme.primary,
						hoverBackgroundColor: window.theme.primary,
						hoverBorderColor: window.theme.primary,
						data: [54, 67, 41, 55, 62, 45, 55, 73, 60, 76, 48, 79],
						barPercentage: .75,
						categoryPercentage: .5
					}]
				},
				options: {
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					scales: {
						yAxes: [{
							gridLines: {
								display: false
							},
							stacked: false,
							ticks: {
								stepSize: 20
							}
						}],
						xAxes: [{
							stacked: false,
							gridLines: {
								color: "transparent"
							}
						}]
					}
				}
			});
		});
	</script>
	<script>
		document.addEventListener("DOMContentLoaded", function() {
			var markers = [{
					coords: [31.230391, 121.473701],
					name: "Shanghai"
				},
				{
					coords: [28.704060, 77.102493],
					name: "Delhi"
				},
				{
					coords: [6.524379, 3.379206],
					name: "Lagos"
				},
				{
					coords: [35.689487, 139.691711],
					name: "Tokyo"
				},
				{
					coords: [23.129110, 113.264381],
					name: "Guangzhou"
				},
				{
					coords: [40.7127837, -74.0059413],
					name: "New York"
				},
				{
					coords: [34.052235, -118.243683],
					name: "Los Angeles"
				},
				{
					coords: [41.878113, -87.629799],
					name: "Chicago"
				},
				{
					coords: [51.507351, -0.127758],
					name: "London"
				},
				{
					coords: [40.416775, -3.703790],
					name: "Madrid "
				}
			];
			var map = new jsVectorMap({
				map: "world",
				selector: "#world_map",
				zoomButtons: true,
				markers: markers,
				markerStyle: {
					initial: {
						r: 9,
						strokeWidth: 7,
						stokeOpacity: .4,
						fill: window.theme.primary
					},
					hover: {
						fill: window.theme.primary,
						stroke: window.theme.primary
					}
				},
				zoomOnScroll: false
			});
			window.addEventListener("resize", () => {
				map.updateSize();
			});
		});
	</script>
	<script>
		document.addEventListener("DOMContentLoaded", function() {
			var date = new Date(Date.now()); // - 5 * 24 * 60 * 60 * 1000
			var defaultDate = date.getUTCFullYear() + "-" + (date.getUTCMonth() + 1) + "-" + date.getUTCDate();
			document.getElementById("datetimepicker-dashboard").flatpickr({
				inline: true,
				prevArrow: "<span title=\"Previous month\">&laquo;</span>",
				nextArrow: "<span title=\"Next month\">&raquo;</span>",
				defaultDate: defaultDate
			});
		});
	</script>

</body>

</html>