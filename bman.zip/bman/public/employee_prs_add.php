<?php
session_start();
require_once('bcore.php');

// 1. Access Control
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = ["administrator", "employee", "editor"];

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Handle POST (Form Submission)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Initialize error array
    $errors = [];

    // Validate and sanitize form data
    
    // Process name
    $name = isset($_POST['name']) ? sanitize_text_field(trim($_POST['name'])) : NULL;

    // Process description
    $description = isset($_POST['description']) ? sanitize_text_field(trim($_POST['description'])) : NULL;

    // Process expdate
    $expdate = isset($_POST['expdate']) ? sanitize_text_field($_POST['expdate']) : NULL;

    // Process image
    $image = isset($_POST['image']) ? $_FILES['image'] : NULL;

    // Process Type
    $Type = isset($_POST['Type']) ? sanitize_text_field(trim($_POST['Type'])) : NULL;

    // Process brand
    $brand = isset($_POST['brand']) ? sanitize_text_field(trim($_POST['brand'])) : NULL;

    // Process category
    $category = isset($_POST['category']) ? sanitize_text_field(trim($_POST['category'])) : NULL;

    // Process location
    $location = isset($_POST['location']) ? sanitize_text_field(trim($_POST['location'])) : NULL;

    // Process quantity
    $quantity = isset($_POST['quantity']) ? floatval($_POST['quantity']) : NULL;

    // Process price
    $price = isset($_POST['price']) ? floatval($_POST['price']) : NULL;


  if (isset($_FILES['image'])) {

	  	    require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            $file = $_FILES['image'];
            $upload = wp_handle_upload($file, ['test_form' => false]);
            if (isset($upload['error'])) { 
               $_SESSION['error'] = 'Image Upload Failed';
		       header('location:'.$homeurl.'/inventory/products/add');
		       exit;


              }

                  // Insert into media library
            $attachment = array(
               'guid'           => $upload['url'],
               'post_mime_type' => $upload['type'],
               'post_title'     => sanitize_file_name($file['name']),
               'post_content'   => '',
               'post_status'    => 'inherit',
                );
            $attach_id = wp_insert_attachment($attachment, $upload['file']);
            $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
            wp_update_attachment_metadata($attach_id, $attach_data);
            $rep =  [
                      'success' => true,
                      'id'      => $attach_id,
                      'url'     => wp_get_attachment_url($attach_id),
                  ];
            $json_image_info = json_encode($rep);
 }


    // If no errors, proceed with database operations
    if (empty($errors)) {
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'zn_met_requests';
        
        // Prepare data for insertion
        $data = array(
            'name' => $name,
            'description' => $description,
            'expdate' => $expdate,
            'type' => $Type,
			'image' => $json_image_info,
            'brand' => $brand,
            'category' => $category,
            'location' => $location,
            'quantity' => $quantity,
            'price' => $price,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        );
        
        // Insert into database
        $inserted = $wpdb->insert($table_name, $data);
        
        if (!$inserted) {
            $errors[] = 'Failed to save record. Please try again.';
            $_SESSION['errors'] = $errors;
            $_SESSION['old_input'] = $_POST;
            wp_redirect($homeurl . '/prs/add');
            exit;
        }

      


        // Redirect on success
        $_SESSION['success'] = 'Request sent';
        wp_redirect($homeurl . '/prs/add');
        exit;
    } else {
        // Store errors in session and repopulate form
        $_SESSION['errors'] = $errors;
        $_SESSION['old_input'] = $_POST;
        wp_redirect($homeurl . '/prs/add');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Buy Company Material | <?php echo get_bloginfo('name'); ?></title>
    
    <style>
        /* Custom CSS */
        
        
        /* Suggestions styling */
        .suggestions {
            border: 1px solid #ccc;
            max-height: 150px;
            overflow-y: auto;
            position: absolute;
            background: white;
            width: 100%;
            z-index: 1000;
            display: none;
        }
        .suggestion-item {
            cursor: pointer;
            padding: 8px;
        }
        .suggestion-item:hover {
            background: #f0f0f0;
        }
        .is-invalid {
            border-color: #dc3545 !important;
        }
        .invalid-feedback {
            color: #dc3545;
            display: none;
            width: 100%;
            margin-top: 0.25rem;
            font-size: 0.875em;
        }
    </style>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Buy Company Material</h1>
                
                <?php if (isset($_SESSION['errors'])): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <div class="alert-message">
                            <strong>Error:</strong> Please fix the following issues:
                            <ul>
                                <?php foreach ($_SESSION['errors'] as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <?php unset($_SESSION['errors']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <div class="alert-message">
                            <?php echo htmlspecialchars($_SESSION['success']); ?>
                        </div>
                    </div>
                    <?php unset($_SESSION['success']); ?>
                <?php endif; ?>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Buy Company Material</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo esc_url($homeurl . '/prs/add'); ?>" enctype="multipart/form-data">
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Name</label>
                                        <input type="text" class="form-control" name="name" id="name" 
                   value="<?php echo isset($_SESSION['old_input']['name']) ? htmlspecialchars($_SESSION['old_input']['name']) : ''; ?>">
                                        <div class="invalid-feedback" id="name-error"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">description</label>
                                        <input type="text" class="form-control" name="description" id="description" 
                   value="<?php echo isset($_SESSION['old_input']['description']) ? htmlspecialchars($_SESSION['old_input']['description']) : ''; ?>">
                                        <div class="invalid-feedback" id="description-error"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Expire Date</label>
                                        <input type="date" class="form-control" name="expdate" id="expdate" 
                   value="<?php echo isset($_SESSION['old_input']['expdate']) ? htmlspecialchars($_SESSION['old_input']['expdate']) : ''; ?>">
                                        <div class="invalid-feedback" id="expdate-error"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Image</label>
                                        <input type="file" class="form-control" name="image" id="image" >
                   <small class="text-muted"></small>
                                        <div class="invalid-feedback" id="image-error"></div>
                                    </div>

                                    <!--div class="mb-3">
                                        <label class="form-label">Type</label>
                                        <input type="text" class="form-control" name="Type" id="Type" 
                   value="<?php echo isset($_SESSION['old_input']['Type']) ? htmlspecialchars($_SESSION['old_input']['Type']) : ''; ?>">
                                        <div class="invalid-feedback" id="Type-error"></div>
                                    </div-->


					<div class="mb-3 ">
                                            <label  class="form-label">Brand:</label>
                                            <!--input type="text" class="form-control"  name="brand" required-->
											
										    <select class="form-control" name="brand" required>
											<?php 
											global $wpdb;
											$brand_list =  $wpdb->get_results("SELECT * FROM wp_pos_system_brands");
										    echo "<option>Select</option>";
											foreach ($brand_list as $row) { echo "<option>". $row->brand_name ."</option>";}
											?>
											    
											 

											</select>
                                        </div>
										
										
										<div class="mb-3 ">
                                            <label  class="form-label">Category:</label>
                                            <!--input type="text" class="form-control"  name="category" required-->
											
											 <select class="form-control" name="category" required>
											  	<?php 
											global $wpdb;
											$cat_list =  $wpdb->get_results("SELECT * FROM wp_pos_system_categories");
										    echo "<option>Select</option>";
											foreach ($cat_list as $row) { echo "<option>". $row->category_name ."</option>";}
											?>

											</select>
											
                                        </div>





                                    <!--div class="mb-3">
                                        <label class="form-label">Brand</label>
                                        <input type="text" class="form-control" name="brand" id="brand" 
                   value="<?php echo isset($_SESSION['old_input']['brand']) ? htmlspecialchars($_SESSION['old_input']['brand']) : ''; ?>">
                                        <div class="invalid-feedback" id="brand-error"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Category</label>
                                        <input type="text" class="form-control" name="category" id="category" 
                   value="<?php echo isset($_SESSION['old_input']['category']) ? htmlspecialchars($_SESSION['old_input']['category']) : ''; ?>">
                                        <div class="invalid-feedback" id="category-error"></div>
                                    </div-->
									
									
									
									
									
									
									

                                    <!--div class="mb-3">
                                        <label class="form-label">Location</label>
                                        <input type="text" class="form-control" name="location" id="location" 
                   value="<?php echo isset($_SESSION['old_input']['location']) ? htmlspecialchars($_SESSION['old_input']['location']) : ''; ?>">
                                        <div class="invalid-feedback" id="location-error"></div>
                                    </div-->

                                    <div class="mb-3">
                                        <label class="form-label">Quantity</label>
                                        <input type="number" class="form-control" name="quantity" id="quantity" 
                   
                   value="<?php echo isset($_SESSION['old_input']['quantity']) ? htmlspecialchars($_SESSION['old_input']['quantity']) : ''; ?>">
                                        <div class="invalid-feedback" id="quantity-error"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">price</label>
                                        <input type="number" class="form-control" name="price" id="price" 
                   step="any" 
                   value="<?php echo isset($_SESSION['old_input']['price']) ? htmlspecialchars($_SESSION['old_input']['price']) : ''; ?>">
                                        <div class="invalid-feedback" id="price-error"></div>
                                    </div>

                                    
                                    <div class="row mt-4">
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary float-end">Request</button>
                                            <a href="<?php echo $homeurl . '/'; ?>" class="btn btn-secondary">Cancel</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<!-- JavaScript -->
<script>
jQuery(document).ready(function($) {
    
    // Client-side validation
    function validateForm() {
        let isValid = true;

        return isValid;
    }
    
    // Form submission handler
    $('form').on('submit', function(e) {
        if (!validateForm()) {
            e.preventDefault();
            $('.is-invalid').first().focus();
        }
    });

});
</script>
</body>
</html>
