<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a class="text-muted" href="<?php echo get_site_url(); ?>" target="_blank"><strong>Wp BMan Suite</strong></a>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="https://t.me/zaanind" target="_blank">Support</a>
								</li>


								<li class="list-inline-item">
									<a class="text-muted" href="#" target="_blank">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#" target="_blank">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
<script src="<?php echo get_site_url(); ?>/wp-content/plugins/bman/public/css/jquery-3.7.1.min.js"></script>
			
			<script src="<?php echo get_site_url(); ?>/wp-content/plugins/bman/public/js/app.js"></script>
			<!--script src="<?php echo get_site_url(); ?>/wp-content/plugins/bman/public/css/apppro.js"></script-->
			
   <!--script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script-->
 
			
			<link href="<?php echo get_site_url(); ?>/wp-content/plugins/bman/public/css/datatables.min.css" rel="stylesheet">
 
<script src="<?php echo get_site_url(); ?>/wp-content/plugins/bman/public/css/datatables.min.js"></script>
			
			<?php
        echo "</div>";
        get_footer();

       ?>