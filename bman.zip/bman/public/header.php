	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Dashboard For WpPos Plugin">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="">

	<link rel="preconnect" href="https://fonts.gstatic.com">

<link href="<?php echo get_site_url(); ?>/wp-content/plugins/bman/public/css/light.css" rel="stylesheet">
	<link href="<?php echo get_site_url(); ?>/wp-content/plugins/bman/public/css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
	
<?php
	
//get_header();



echo"<div class='content' id='content_of_site'>";

?>

<style>
	<?php if (is_admin_bar_showing() && current_user_can('manage_options')) { ?>
	
	.content {
        margin-top: 32px;
    }
    <?php } ?>

    
	.footer-html-inner {display:none;}
	
	div#content_of_site {
    padding: 0px;
}
</style>