<?php
session_start();

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator',);


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}




   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	  global $wpdb;
	   
        
      $homeurl = get_site_url();

      
      $email = $_POST['email'];
      $user = $_POST['user'];
      $pass = $_POST['pass'];
	  $name = $_POST['name'];
	  $wsalary = $_POST['wsalary'];
	  $msalary = $_POST['msalary'];
	  $role = $_POST['role'];
	  $phone = $_POST['phone'];
	  $address = $_POST['address'];
      $hsalary = $_POST['hsalary'];
      $pay_type = $_POST['payment_type'];

	  if (isset($_FILES['image']) && $_FILES['image']['size'] > 0) {

	  	    require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            $file = $_FILES['image'];
            $upload = wp_handle_upload($file, ['test_form' => false]);
            if (isset($upload['error'])) { 
               $_SESSION['error'] = 'Image Upload Failed';
		       header('location:'.$homeurl.'/hr/add-employee');
		       exit;


              }

                  // Insert into media library
            $attachment = array(
               'guid'           => $upload['url'],
               'post_mime_type' => $upload['type'],
               'post_title'     => sanitize_file_name($file['name']),
               'post_content'   => '',
               'post_status'    => 'inherit',
                );
            $attach_id = wp_insert_attachment($attachment, $upload['file']);
            $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
            wp_update_attachment_metadata($attach_id, $attach_data);
            $rep =  [
                      'success' => true,
                      'id'      => $attach_id,
                      'url'     => wp_get_attachment_url($attach_id),
                  ];
            $json_image_info = json_encode($rep);



	  }
	  
	  
	  if (username_exists($user) || email_exists($email)) {
        $_SESSION['error'] = 'User already exists.';
		header('location:'.$homeurl.'/hr/add-employee');
		exit;
      }
	  
	  $user_id = wp_create_user($user, $pass, $email);
	  
	  if (is_wp_error($user_id)) {
        $_SESSION['error'] = 'Error creating user:'. $user_id->get_error_message();
		header('location:'.$homeurl.'/hr/add-employee');
		exit; }
		
    // Set role
    $userob = new WP_User($user_id);
    $userob->set_role($role);
	

    $salary_json = json_encode(array(
	'weekly' => $wsalary,
	'monthly' => $msalary,	
    'hourly' => $hsalary,
	));
	
	
    $table_name = $wpdb->prefix . 'zn_system_employee';
    $data = array(
        'employee_id' => $userob->ID,
	    'role' => $role,
	    'salary' => $salary_json,
	    'email' => $email,
		'phone_number' => $phone,
		'address' => $address,
		'name' => $name,
		'image'=> $json_image_info ,
        'payment_type' => $pay_type,	
      );
	
	
    $inserted = $wpdb->insert($table_name, $data);

	  
        if ($inserted === false) {
		  $_SESSION['error'] = 'Failed';
		  header('location:'.$homeurl.'/hr/add-employee');
		  exit;
      

	  }


    
	header('location:'.$homeurl.'/hr/employee-list');
}
		


?>


<!DOCTYPE html>
<html lang="en">
   <head>
   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title>Add Employee | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



			<main class="content">
			<?php
                   if (isset($_SESSION['error'])) {
                         $err = $_SESSION['error'];
                         unset($_SESSION['error']);?>
						 
						 			<div class="alert alert-danger alert-dismissible" role="alert">
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											<div class="alert-message">
												<strong>Error:</strong> <?php echo $err; ?>
											</div>
										</div>

						<?php }	?>
								
								
					
										
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Add New Employee</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
						
								<div class="card-body">
								       
                                      <form method="POST" action="<?php echo get_site_url(); ?>/hr/add-employee/" enctype="multipart/form-data" onsubmit="return validateForm()">
                                    
    									
										
										<div class="mb-3">
                                            <label  class="form-label">Email:</label>
                                            <input type="text" class="form-control"  name="email" required>
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">User name:</label>
                                            <input type="text" class="form-control"  name="user" required>
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Password:</label>
                                            <input type="text" class="form-control"  name="pass" required>
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Name:</label>
                                            <input type="text" class="form-control"  name="name" required>
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Phone Number:</label>
                                            <input type="text" class="form-control"  name="phone" required>
                                        </div>
			
			                            <div class="mb-3">
                                            <label  class="form-label">Address:</label>
                                            <input type="text" class="form-control"  name="address" >
                                        </div>
										
										
										<div class="mb-3">
                                            <label  class="form-label">Weekly Salary:</label>
                                            <input type="text" class="form-control"  name="wsalary" >
                                        </div>
										


                                        <div class="mb-3">
                                            <label  class="form-label">Monthly Salary:</label>
                                            <input type="text" class="form-control"  name="msalary" >
                                        </div>

                                        										
			                            <div class="mb-3">
                                            <label  class="form-label">Hourly Rate:</label>
                                            <input type="text" class="form-control"  name="hsalary" >
                                        </div>


                                        <div class="mb-3" style="margin-top:0px;">
                                            <label  class="form-label">Payment Type:</label>
                                            <select class="form-control" name="payment_type" required placeholder='Select'>
											    <option>Select</option>
											    <option>monthly</option>
											    <option>weekly</option>
											    <!--option>daily</option-->
											</select>
                                        </div>
			
										
										<div class="mb-3" style="margin-top:0px;">
                                            <label  class="form-label">Role:</label>
                                            <select class="form-control" name="role" required placeholder='Select'>
											    <option>Select</option>
											    <option>manager</option>
											    <option>employee</option>
											    <option>salesman</option>
											</select>
                                        </div>

                                        <div class="mb-3">
                                            <label  class="form-label">Image:</label></br>
                                            <input class="form-control form-control-lg" id="formFileLg" type="file" name="image">
                                        </div>
										
							          <!--div class="mb-3" style="margin-top:0px;">
                                            <label  class="form-label">Department:</label>
                                            <select class="form-control" name="role" required placeholder='Select'>
											    <option>Select</option>
											    <option>Manager</option>
											    <option>Employee</option>
											    <option>Sales Man</option>
											</select>
                                        </div-->
										
										

										
										<button class="btn btn-outline-primary float-end"> Add</button>
										</form>
								<!--input type="text" class="form-control" placeholder="Input"-->
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>


			
			
			
			
			<?php include_once('footer.php');?>
		</div>
	</div>

	

	

</body>

</html>