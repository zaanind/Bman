<?php
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <?php
   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); 
   ?>
   <title>Attendance | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
    <div class="wrapper">
        <?php include_once('sidebar.php'); ?>
        <div class="main">
            <?php include_once('navbar.php'); ?>
            <main class="content">
                <div class="container-fluid p-0">
                    <div class="mb-3">
                        <h1 class="h3 d-inline align-middle">Attendance</h1>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <table id="datatables-reponsive" class="table table-striped" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Employee</th>
                                                <th>Check In</th>
                                                <th>Check Out</th>
                                                <th>Work Hours</th>
                                                <th>Status</th>
                                                <th>Approval</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            global $wpdb;
                                            // Change this to your attendance table name.
                                            $attendance_table = $wpdb->prefix . 'zn_system_attendance';
                                            $attendance_records = $wpdb->get_results("SELECT * FROM $attendance_table ORDER BY check_in DESC");

                                            foreach ($attendance_records as $record) {
                                                // Retrieve employee's display name from WP user table
                                                $user_data = get_userdata($record->employee_id);
                                                $employee_name = $user_data ? $user_data->display_name : $record->employee_id;
                                              
                                                $current_time = strtotime($wpdb->get_var("SELECT NOW()")); // Get MySQL server time
                                                $check_in = strtotime($record->check_in);
                                                $check_out = $record->check_out ? strtotime($record->check_out) : $current_time; // Use MySQL time if not checked out
                                                 
                                                $work_seconds = $check_out - $check_in;
                                                $hours = floor($work_seconds / 3600);
                                                $minutes = floor(($work_seconds % 3600) / 60);  


                                                echo '<tr>';
                                                    echo '<td>' . esc_html($employee_name) . '</td>';
                                                    echo '<td>' . esc_html($record->check_in) . '</td>';
                                                    echo '<td>' . esc_html($record->check_out) . '</td>';
                                                  //  echo '<td>' . esc_html($record->work_hours) . '</td>';
                                                  echo '<td>' . sprintf("%02d hrs %02d mins", $hours, $minutes) . '</td>';
                                                   
                                                  echo '<td>' . esc_html($record->status) . '</td>';
                                                  echo '<td>' . esc_html($record->verification) . '</td>';
                                                    echo '<td>
                                                            <div class="btn-group">
                                                                <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                                    Actions
                                                                </button>';

                                                                if ($record->verification != 'admin') {
                                                                    echo '<ul class="dropdown-menu">
                                                                            <li><a class="dropdown-item" href="' . get_site_url() . '/hr/attendance/approve?id=' . $record->attendance_id . '">Approve</a></li>
                                                                          </ul>';
                                                                } else {
                                                                    echo '<ul class="dropdown-menu">
                                                                            <li><a class="dropdown-item" href="#" style="color:gray; cursor:not-allowed;" tabindex="-1">Approve</a></li>
                                                                          </ul>';
                                                                }
                                                                

                                                            echo '</div> </td>';
                                                echo '</tr>';
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div><!-- end card-body -->
                            </div><!-- end card -->
                        </div><!-- end col-12 -->
                    </div><!-- end row -->
                </div><!-- end container-fluid -->
            </main>
            <?php include_once('footer.php'); ?>
        </div>
    </div>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        $("#datatables-reponsive").DataTable({
            responsive: true,
            order: [[1, "desc"]]
        });
    });
    </script>
</body>
</html>
