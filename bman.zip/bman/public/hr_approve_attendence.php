<?php
session_start();
$homeurl = get_site_url();

// Verify user role (Only admin allowed)
$wpuser_ob = wp_get_current_user();

$allowed_roles = array('administrator','manager');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}


if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}



if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $attendance_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Fetch attendance record (optional, but good practice to check if it exists)
    $table_name = $wpdb->prefix . 'zn_system_attendance'; // Correct table name

    $sql = $wpdb->prepare("SELECT attendance_id FROM $table_name WHERE attendance_id = %d;", $attendance_id);
    $result = $wpdb->get_results($sql);

    if (!empty($result)) {
        // Update the 'verification' column to 'Approved by Admin'
        $sql = $wpdb->prepare("UPDATE $table_name SET verification = 'admin' WHERE attendance_id = %d;", $attendance_id);
        $wpdb->query($sql);

        status_header(200);
        wp_redirect($homeurl . '/hr/attendance/'); // Replace '/attendance' with the correct URL for your attendance page
        exit;
    } else {
        echo "Attendance record not found.";
    }
} else {
    echo 'No ID provided';
}
?>