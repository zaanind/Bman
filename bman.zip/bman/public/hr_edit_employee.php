<?php
session_start();

// 1. Access Control
$homeurl       = get_site_url();
$wpuser_ob     = wp_get_current_user();
$allowed_roles = array('administrator');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Retrieve existing employee record
global $wpdb;
$table_name = $wpdb->prefix . 'zn_system_employee';

// Check if "id" is in query string
$employee_id = 0;
$employee    = null;
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $employee_id = (int) $_GET['id'];
    $employee    = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table_name} WHERE employee_id = %d",
        $employee_id
    ));
}

// If no valid record and not posting yet, handle gracefully
if (!$employee && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = 'Invalid employee ID.';
    wp_redirect($homeurl . '/hr/employee-list');
    exit;
}

// 3. Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ensure we have a valid employee_id in POST
    if (!isset($_POST['employee_id']) || empty($_POST['employee_id'])) {
        $_SESSION['error'] = 'Missing employee ID.';
        wp_redirect($homeurl . '/hr/employee-list');
        exit;
    }

    $employee_id = (int) $_POST['employee_id'];

    // Gather POST data
    $email    = sanitize_text_field($_POST['email']);
    // Typically, WordPress does not allow changing the username (user_login) easily,
    // so if you want to allow that, see notes below. Otherwise, we skip it or just display it.
    $pass     = sanitize_text_field($_POST['pass']);  // If left blank, we won't change password
    $name     = sanitize_text_field($_POST['name']);
    $phone    = sanitize_text_field($_POST['phone']);
    $address  = sanitize_text_field($_POST['address']);
    $role     = sanitize_text_field($_POST['role']);
    $wsalary  = sanitize_text_field($_POST['wsalary']);
    $msalary  = sanitize_text_field($_POST['msalary']);
    $hsalary = sanitize_text_field($_POST['hsalary']);
    $pay_type = $_POST['payment_type'];

    // Build the salary JSON
    $salary_json = json_encode(array(
        'weekly'  => $wsalary,
        'monthly' => $msalary,
        'hourly' => $hsalary
    ));

    // Get the existing row again (for image, etc.)
    $existing_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table_name} WHERE employee_id = %d",
        $employee_id
    ));
    if (!$existing_data) {
        $_SESSION['error'] = 'Employee record not found.';
        wp_redirect($homeurl . '/hr/employee-list');
        exit;
    }

    // 4. Update WordPress user fields (email, role, password)
    // The employee_id should match the WP user ID.
    $wp_user_id = $employee_id;
    $wp_user    = get_userdata($wp_user_id);

    if ($wp_user) {
        // Update email
        $update_data = array(
            'ID'         => $wp_user_id,
            'user_email' => $email, // If you want to update WP user email
        );
        
        // If a new password is provided, update it
        if (!empty($pass)) {
            // Easiest approach is to use wp_set_password
            // But that logs the user out if they're the same user. 
            // Alternatively, we can do $update_data['user_pass'] = $pass;
            // We'll do the standard approach:
            wp_set_password($pass, $wp_user_id);
        }

        // Attempt the user update
        $updated_user_id = wp_update_user($update_data);
        if (is_wp_error($updated_user_id)) {
            $_SESSION['error'] = 'Failed to update WP user: ' . $updated_user_id->get_error_message();
            wp_redirect($homeurl . '/hr/employee-edit?id=' . $employee_id);
            exit;
        }

        // Update role if changed
        // (Remove old role(s) and set the new one)
        $user_ob = new WP_User($wp_user_id);
        // Clear existing roles except 'administrator' if you want to preserve it
        foreach ($user_ob->roles as $r) {
            $user_ob->remove_role($r);
        }
        $user_ob->add_role($role);
    }

    // 5. Handle new image upload if provided
    $json_image_info = $existing_data->image; // Keep existing by default
    if (!empty($_FILES['image']['name'])) {
        // Remove old image if exists
        if (!empty($existing_data->image)) {
            $old_image_data = json_decode($existing_data->image);
            if (!empty($old_image_data->id)) {
                wp_delete_attachment($old_image_data->id, true);
            }
        }

        // Process the new upload
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $file   = $_FILES['image'];
        $upload = wp_handle_upload($file, ['test_form' => false]);

        if (isset($upload['error'])) {
            $_SESSION['error'] = 'Image Upload Failed';
            wp_redirect($homeurl . '/hr/employee-edit?id=' . $employee_id);
            exit;
        }

        // Insert into media library
        $attachment = array(
            'guid'           => $upload['url'],
            'post_mime_type' => $upload['type'],
            'post_title'     => sanitize_file_name($file['name']),
            'post_content'   => '',
            'post_status'    => 'inherit',
        );
        $attach_id   = wp_insert_attachment($attachment, $upload['file']);
        $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
        wp_update_attachment_metadata($attach_id, $attach_data);

        $rep = [
            'success' => true,
            'id'      => $attach_id,
            'url'     => wp_get_attachment_url($attach_id),
        ];
        $json_image_info = json_encode($rep);
    }

    // 6. Update the custom employee table
    $data = array(
        'email'        => $email,
        'name'         => $name,
        'phone_number' => $phone,
        'address'      => $address,
        'role'         => $role,
        'salary'       => $salary_json,
        'image'        => $json_image_info,
        'payment_type' => $pay_type,
        'updated_at'   => current_time('mysql'),
    );

    $where   = array('employee_id' => $employee_id);
    $updated = $wpdb->update($table_name, $data, $where);

    if ($updated === false) {
        $_SESSION['error'] = 'Failed to update employee.';
        wp_redirect($homeurl . '/hr/employee-edit?id=' . $employee_id);
        exit;
    }

    // On success, redirect to the employee list
    wp_redirect($homeurl . '/hr/employee-list');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // Standard includes
    $active_page  = get_query_var('active_page_wp_pos'); 
    $active_sub_m = get_query_var('active_sub_m'); 
    include_once('header.php');
    ?>
    <title>Edit Employee | <?php echo get_bloginfo('name'); ?></title>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            if (isset($_SESSION['error'])) {
                $err = $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Error:</strong> <?php echo esc_html($err); ?>
                    </div>
                </div>
            <?php } ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Edit Employee</h1>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <?php if (!empty($employee)) : ?>
                                    <?php
                                    // Decode the existing salary JSON
                                    $decoded_salary = json_decode($employee->salary, true);
                                    $weekly_salary  = isset($decoded_salary['weekly']) ? $decoded_salary['weekly'] : '';
                                    $monthly_salary = isset($decoded_salary['monthly']) ? $decoded_salary['monthly'] : '';
                                    $hourly_salary = isset($decoded_salary['hourly']) ? $decoded_salary['hourly'] : '';

                                    // Retrieve WP user info for this employee
                                    $wp_user_info = get_userdata($employee->employee_id);
                                    // If you want to show the existing WP user_login:
                                    $wp_user_login = $wp_user_info ? $wp_user_info->user_login : '';
                                    ?>
                                    <form method="POST" 
                                          action="<?php echo esc_url($homeurl . '/hr/employee-edit?id=' . $employee->employee_id); ?>"
                                          enctype="multipart/form-data">
                                        <!-- Hidden field for employee_id -->
                                        <input type="hidden" name="employee_id" 
                                               value="<?php echo esc_attr($employee->employee_id); ?>">

                                        <!-- If you want to show the username (but typically not editable) -->
                                        <div class="mb-3">
                                            <label class="form-label">Username (WP):</label>
                                            <input type="text" class="form-control" 
                                                   value="<?php echo esc_attr($wp_user_login); ?>" 
                                                   disabled>
                                        </div>

                                        <!-- Email -->
                                        <div class="mb-3">
                                            <label class="form-label">Email:</label>
                                            <input type="email" class="form-control" name="email" required
                                                   value="<?php echo esc_attr($employee->email); ?>">
                                        </div>

                                        <!-- Password (leave blank if not changing) -->
                                        <div class="mb-3">
                                            <label class="form-label">New Password (leave blank to keep existing):</label>
                                            <input type="text" class="form-control" name="pass">
                                        </div>

                                        <!-- Name -->
                                        <div class="mb-3">
                                            <label class="form-label">Name:</label>
                                            <input type="text" class="form-control" name="name" required
                                                   value="<?php echo esc_attr($employee->name); ?>">
                                        </div>

                                        <!-- Phone -->
                                        <div class="mb-3">
                                            <label class="form-label">Phone Number:</label>
                                            <input type="text" class="form-control" name="phone" required
                                                   value="<?php echo esc_attr($employee->phone_number); ?>">
                                        </div>

                                        <!-- Address -->
                                        <div class="mb-3">
                                            <label class="form-label">Address:</label>
                                            <input type="text" class="form-control" name="address"
                                                   value="<?php echo esc_attr($employee->address); ?>">
                                        </div>

                                        <!-- Weekly Salary -->
                                        <div class="mb-3">
                                            <label class="form-label">Weekly Salary:</label>
                                            <input type="text" class="form-control" name="wsalary"
                                                   value="<?php echo esc_attr($weekly_salary); ?>">
                                        </div>

                                        <!-- Monthly Salary -->
                                        <div class="mb-3">
                                            <label class="form-label">Monthly Salary:</label>
                                            <input type="text" class="form-control" name="msalary"
                                                   value="<?php echo esc_attr($monthly_salary); ?>">
                                        </div>

                                        <div class="mb-3">
                                            <label  class="form-label">Hourly Rate:</label>
                                            <input type="text" class="form-control"  name="hsalary" value="<?php echo esc_attr($hourly_salary); ?>" >
                                        </div>

                                        <div class="mb-3" style="margin-top:0px;">
                                            <label  class="form-label">Payment Type:</label>
                                            <select class="form-control" name="payment_type" required placeholder='Select'>
											    <option>Select</option>
											    <option <?php selected($employee->payment_type, 'monthly'); ?>>monthly</option>
											    <option <?php selected($employee->payment_type, 'weekly'); ?>>weekly</option>
											    <!--option>daily</option-->
											</select>
                                        </div>

                                        <!-- Role -->
                                        <div class="mb-3">
                                            <label class="form-label">Role:</label>
                                            <select class="form-control" name="role" required>
                                                <option value="">Select</option>
                                                <option value="manager" 
                                                    <?php selected($employee->role, 'manager'); ?>>
                                                    manager
                                                </option>
                                                <option value="employee" 
                                                    <?php selected($employee->role, 'employee'); ?>>
                                                    employee
                                                </option>
                                                <option value="salesman" 
                                                    <?php selected($employee->role, 'salesman'); ?>>
                                                    salesman
                                                </option>
                                            </select>
                                        </div>

                                        <!-- Existing Image -->
                                        <?php
                                        $image_data = json_decode($employee->image);
                                        $image_url  = '';
                                        if (!empty($image_data->url)) {
                                            $image_url = $image_data->url;
                                        }
                                        ?>
                                        <div class="mb-3">
                                            <label class="form-label">Current Image:</label><br>
                                            <?php if (!empty($image_url)) : ?>
                                                <img src="<?php echo esc_url($image_url); ?>" 
                                                     width="120" alt="Employee Image">
                                            <?php endif; ?>
                                        </div>

                                        <!-- New Image -->
                                        <div class="mb-3">
                                            <label class="form-label">New Image (optional):</label>
                                            <input class="form-control" type="file" name="image">
                                        </div>
 
                                        <button class="btn btn-outline-primary float-end" type="submit">
                                            Update
                                        </button>
                                    </form>
                                <?php else : ?>
                                    <p>Invalid or missing employee data.</p>
                                <?php endif; ?>
                            </div> <!-- card-body -->
                        </div> <!-- card -->
                    </div> <!-- col-12 -->
                </div> <!-- row -->
            </div> <!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>
</body>
</html>
