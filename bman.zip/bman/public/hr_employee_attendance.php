<?php
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();

// Only allow employees
$allowed_roles = array('employee','salesman');
$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// We'll fetch the current WP user ID for matching attendance
$employee_id = $wpuser_ob->ID;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos'); 
    $active_sub_m = get_query_var('active_sub_m'); 
    include_once('header.php'); 
    ?>
    <title>My Attendance | <?php echo get_bloginfo('name'); ?></title>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>
        <main class="content">
            <div class="container-fluid p-0">
			<a href="<?php echo get_site_url(); ?>/hr/my-attendance/mark" class="btn btn-primary float-end mt-n1"><i class="fas fa-plus"></i> Mark Attendance</a>
    
                <div class="mb-3">
                    <h1 class="h3 d-inline align-middle">My Attendance</h1>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">       
                            <div class="card-body">
                                <table id="datatables-reponsive" class="table table-striped" style="width:100%">
                                    <thead>
                                        <tr>
                                            
                                            <th>Check In</th>
                                            <th>Check Out</th>
                                            <th>Work Hours</th>
                                            <th>Status</th>
                                            <th>Approval</th>
                                            <!--th>Action</th-->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        global $wpdb;
                                        // Attendance table name
                                        $attendance_table = $wpdb->prefix . 'zn_system_attendance';
                                        
                                        // Fetch only this employee's attendance records
                                        $my_attendance = $wpdb->get_results(
                                            $wpdb->prepare(
                                                "SELECT * 
                                                 FROM $attendance_table 
                                                 WHERE employee_id = %d 
                                                 ORDER BY check_in DESC",
                                                $employee_id
                                            )
                                        );

                                        // Display rows
                                        foreach ($my_attendance as $row) {
                                            $current_time = strtotime($wpdb->get_var("SELECT NOW()")); // Get MySQL server time
                                            $check_in = strtotime($row->check_in);
                                            $check_out = $row->check_out ? strtotime($row->check_out) : $current_time; // Use MySQL time if not checked out
                                            
                                            $work_seconds = $check_out - $check_in;
                                            $hours = floor($work_seconds / 3600);
                                            $minutes = floor(($work_seconds % 3600) / 60);
                                            
                                        
                                            
                                            

                                            echo '<tr>';
                                                //echo '<td>' . esc_html($row->employee_id) . '</td>';
                                                echo '<td>' . esc_html($row->check_in) . '</td>';
                                                echo '<td>' . esc_html($row->check_out) . '</td>';
                                                //echo '<td>' . esc_html($row->work_hours) . '</td>';
                                                echo '<td>' . sprintf("%02d hrs %02d mins", $hours, $minutes) . '</td>';
                                                echo '<td>' . esc_html($row->status) . '</td>';
                                                echo '<td>' . esc_html($row->verification) . '</td>';
                                                // Action column (customize as needed)
                                                echo '<!--td>
                                                        <div class="btn-group">
                                                            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                                Actions
                                                            </button>
                                                            <ul class="dropdown-menu">
                                                                <li><a class="dropdown-item" href="#">View</a></li>
                                                                <!-- Add more actions as needed -->
                                                            </ul>
                                                        </div>
                                                      </td>';
                                            echo '</tr-->';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div><!-- end card-body -->
                        </div><!-- end card -->
                    </div><!-- end col-12 -->
                </div><!-- end row -->
            </div><!-- end container-fluid -->
        </main>
        <?php include_once('footer.php'); ?>
    </div><!-- end main -->
</div><!-- end wrapper -->

<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Initialize DataTables
        $("#datatables-reponsive").DataTable({
            responsive: true,
            order: [[0, "desc"]]
        });
    });
</script>
</body>
</html>
