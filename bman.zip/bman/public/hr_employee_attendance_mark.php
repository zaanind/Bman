<?php
session_start();
$homeurl = get_site_url();
// Allow both administrators and employees to mark attendance.
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator', 'employee','salesman');
$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect(get_site_url() . '/unauthorized');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    global $wpdb;
    $table_name = $wpdb->prefix . 'zn_system_attendance';
    $homeurl = get_site_url();
    $action = isset($_POST['attendance_action']) ? $_POST['attendance_action'] : '';
    $employee_id = $wpuser_ob->ID;  // Must match what's stored in the table!

    if ($action === 'check_in') {
        // 1) Check if a record for today already exists with no check_out
        $existing_record = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * 
                   FROM $table_name
                  WHERE employee_id = %d
                    AND DATE(check_in) = CURRENT_DATE()
                    AND check_out IS NULL
                  LIMIT 1",
                $employee_id
            )
        );

        if ($existing_record) {
            $_SESSION['error'] = 'You have already checked in and not checked out for today.';
            wp_redirect($homeurl . '/hr/my-attendance/mark');
            exit;
        }

        // 2) Insert a new attendance record with MySQL's NOW()
        $inserted = $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO $table_name (employee_id, check_in, status)
                 VALUES (%d, NOW(), 'Present')",
                $employee_id
            )
        );

        if ($inserted === false) {
            $_SESSION['error'] = 'Failed to check in.';
            wp_redirect($homeurl . '/hr/my-attendance/mark');
            exit;
        }

        $_SESSION['message'] = 'Checked in successfully';
        wp_redirect($homeurl . '/hr/my-attendance/mark');
        exit;

    } elseif ($action === 'check_out') {
        // 1) Look for today's check_in (no check_out yet)
        $existing_record = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                   FROM $table_name
                  WHERE employee_id = %d
                    AND DATE(check_in) = CURRENT_DATE()
                    AND check_out IS NULL
                  LIMIT 1",
                $employee_id
            )
        );

        if (!$existing_record) {
            $_SESSION['error'] = 'No check-in record found for today.';
            wp_redirect($homeurl . '/hr/my-attendance/mark');
            exit;
        }

        // 2) Update with check_out = NOW(), and compute hours in MySQL
        // TIMESTAMPDIFF(MINUTE, check_in, NOW()) / 60 => decimal hours
        $update_sql = $wpdb->prepare(
            "UPDATE $table_name
                SET check_out = NOW(),
                    work_hours = TIMESTAMPDIFF(MINUTE, check_in, NOW()) / 60,
					status = 'Off'
              WHERE attendance_id = %d",
            $existing_record->attendance_id
        );

        $updated = $wpdb->query($update_sql);
        if ($updated === false) {
            $_SESSION['error'] = 'Failed to check out.';
            wp_redirect($homeurl . '/hr/my-attendance/mark');
            exit;
        }

        $_SESSION['message'] = 'Checked out successfully';
        wp_redirect($homeurl . '/hr/my-attendance/mark');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php
   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); 
?>
<title>Mark Attendance | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>
        <main class="content">
            <?php
            if (isset($_SESSION['error'])) {
                $err = $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Error:</strong> <?php echo esc_html($err); ?>
                    </div>
                </div>
            <?php } ?>
            <?php
            if (isset($_SESSION['message'])) {
                $msg = $_SESSION['message'];
                unset($_SESSION['message']);
                ?>
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Success:</strong> <?php echo esc_html($msg); ?>
                    </div>
                </div>
            <?php } ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Mark Attendance</h1>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!-- Two buttons: Check In / Check Out -->
                                <form method="POST" action="<?php echo esc_url($homeurl . '/hr/my-attendance/mark'); ?>">
                                    <div class="mb-3">
                                        <button type="submit" name="attendance_action" value="check_in" class="btn btn-outline-success">
                                            Check In
                                        </button>
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" name="attendance_action" value="check_out" class="btn btn-outline-danger">
                                            Check Out
                                        </button>
                                    </div>
                                </form>
                            </div><!-- end card-body -->
                        </div><!-- end card -->
                    </div><!-- end col-12 -->
                </div><!-- end row -->
            </div><!-- end container-fluid -->
        </main>
        <?php include_once('footer.php'); ?>
    </div><!-- end main -->
</div><!-- end wrapper -->
</body>
</html>
