<?php
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator','employee');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// Check if user is admin to allow "Add Employee" button
$roles = (array) $wpuser_ob->roles;
$role = $roles[0];
$add_permission = ($role === 'administrator');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos'); 
    $active_sub_m = get_query_var('active_sub_m'); 
    include_once('header.php');
    ?>
    <title>Employee List | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <?php if($add_permission): ?>
                    <a href="<?php echo get_site_url(); ?>/hr/add-employee" class="btn btn-primary float-end mt-n1">
                        <i class="fas fa-plus"></i> New Employee
                    </a>
                <?php endif; ?>
                <div class="mb-3">
                    <h1 class="h3 d-inline align-middle">Employee List</h1>
                </div>

                <div class="row">
                    <div class="col-12">        
                        <div class="card">  
                            <div class="card-body">
                                <table id="datatables-reponsive" class="table table-striped" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Image</th>
                                            <th>Email</th>
                                            <th>States</th>      <!-- We'll fill this from attendance -->
                                            <th>Phone number</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        global $wpdb;
                                        // 1) Get all employees
                                        $employees = $wpdb->get_results("
                                            SELECT employee_id, image, name, email, phone_number, address 
                                            FROM wp_zn_system_employee
                                        ");

                                        foreach ($employees as $row) {
                                            // Build employee image URL
                                            $image_url = '';
                                            $image_link = json_decode($row->image);
                                            if(isset($image_link->id)){
                                                $image_info = wp_get_attachment_image_src($image_link->id, 'table_90x90');
                                                $image_url = $image_info ? $image_info[0] : $image_link->url;
                                            }

                                            // 2) Fetch the LATEST attendance status for this employee
                                            $latest_attendance = $wpdb->get_row($wpdb->prepare("
                                                SELECT status 
                                                FROM wp_zn_system_attendance
                                                WHERE employee_id = %d
                                                ORDER BY attendance_id DESC
                                                LIMIT 1
                                            ", $row->employee_id));

                                            // If no attendance record, we can show "No Data"
                                            $employee_status = $latest_attendance ? $latest_attendance->status : 'No Data';

                                            echo "<tr>";
                                                echo "<td>" . esc_html($row->name) . "</td>";
                                                echo "<td>";
                                                    if (!empty($image_url)) {
                                                        echo "<img src='" . esc_url($image_url) . "' style='width: 60px;' />";
                                                    } else {
                                                        echo "<img src='" . esc_url(get_stylesheet_directory_uri() . '/images/placeholder.png') . "' style='width: 60px;' />";
                                                    }
                                                echo "</td>";
                                                echo "<td>" . esc_html($row->email) . "</td>";
                                                // 3) Display the status in the "States" column
                                                echo "<td>" . esc_html($employee_status) . "</td>";
                                                echo "<td>" . esc_html($row->phone_number) . "</td>";
                                                // Action buttons
                                                echo "<td>
                                                        <div class='btn-group'>
                                                            <button type='button' class='btn btn-primary dropdown-toggle' data-bs-toggle='dropdown' aria-expanded='false'>
                                                                Actions
                                                            </button>
                                                            <ul class='dropdown-menu'>
                                                               
                                                                <li><a class='dropdown-item' href='" .get_site_url() ."/hr/employee-edit?id=". $row->employee_id."'>Edit</a></li>
                                                                <li><a class='dropdown-item' href='".get_site_url()."/hr/employee-delete?id=" . $row->employee_id . "''>Delete</a></li>
                                                            </ul>
                                                        </div>
                                                      </td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div> <!-- card-body -->
                        </div> <!-- card -->
                    </div> <!-- col-12 -->
                </div> <!-- row -->
            </div> <!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // Initialize DataTables
    jQuery("#datatables-reponsive").DataTable({
        responsive: true
    });
});
</script>
</body>
</html>
