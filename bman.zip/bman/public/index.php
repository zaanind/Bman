<?php 

	if ( !is_user_logged_in() ) {
        
        $homeurl = get_site_url();
       

        wp_redirect($homeurl . '/sys-login');
		exit; 
		
	}

	
?>

<!DOCTYPE html>
<html lang="en">

        
        
<?php


$homeurl = get_site_url();

$wpuser_ob = wp_get_current_user();

$roles = ( array ) $wpuser_ob->roles;
$role = $roles[0];


if($role === 'employee'){
	//include_once 'employee.php'; 
	wp_redirect($homeurl . '/projects');
	
    exit;

}


if($role === 'salesman'){
	//include_once 'employee.php'; 
	wp_redirect($homeurl . '/orders');
	
    exit;

}

if($role === 'administrator'){
	include_once 'admin.php'; 
	
    exit;

}

echo $role;

 ?>