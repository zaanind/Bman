<?php
 session_start();

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator',);


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}



   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	  global $wpdb;
	   $table_name = $wpdb->prefix . 'pos_system_brands';
        
      $homeurl = get_site_url();

      $pname = $_POST['name'];
	  $pdescription = $_POST['description'];

      
	  
	
  
 
    $data = array(
        'brand_name' => $pname,
	    'brand_description' => $pdescription,
      );
	
	
    $inserted = $wpdb->insert($table_name, $data);

	  
        if ($inserted === false) {
		  $_SESSION['error'] = 'Failed';
		  header('location:'.$homeurl.'/inventory/brands/add/');
		  exit;
      

	  }


    
	header('location:'.$homeurl.'/inventory/brands/');
}
		


?>


<!DOCTYPE html>
<html lang="en">
   <head>
   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title>Add Brands | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



			<main class="content">
			<?php
                   if (isset($_SESSION['error'])) {
                         $err = $_SESSION['error'];
                         unset($_SESSION['error']);?>
						 
						 			<div class="alert alert-danger alert-dismissible" role="alert">
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											<div class="alert-message">
												<strong>Error:</strong> Failed to add item
											</div>
										</div>

						<?php }	?>
								
								
					
										
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Add New Brand</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
						
								<div class="card-body">
								       
                                      <form method="POST" action="<?php echo get_site_url(); ?>/inventory/brands/add/" enctype="multipart/form-data" onsubmit="return validateForm()">
                                    
    									<div class="mb-3">
                                            <label  class="form-label">Brand Name:</label>
                                            <input type="text" class="form-control"  name="name" required>
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Description:</label>
                                            <input type="text" class="form-control"  name="description">
                                        </div>
										

										
										<button class="btn btn-outline-primary float-end"> Add</button>
										</form>
								<!--input type="text" class="form-control" placeholder="Input"-->
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>


			
			
			
			
			<?php include_once('footer.php');?>
		</div>
	</div>

	

	

</body>

</html>