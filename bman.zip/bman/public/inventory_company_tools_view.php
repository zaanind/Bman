<?php
session_start();

// 1) Check user roles/permissions
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator'); // Adjust if employees can also view
$has_allowed_role = false;

foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2) Fetch the tool data from DB
global $wpdb;
$table_name = $wpdb->prefix . 'zn_inventory_comp_tools';

// Get the tool ID from URL
$tool_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$tool_id) {
    // Redirect if no ID is provided
    wp_redirect($homeurl . '/inventory/company-tools');
    exit;
}

// Fetch the record
$tool = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table_name} WHERE tool_id = %d", $tool_id)
);

// If no record found, redirect
if (!$tool) {
    wp_redirect($homeurl . '/inventory/company-tools');
    exit;
}

// 3) Decode any JSON data (e.g., image info)
$image_data = !empty($tool->image) ? json_decode($tool->image, true) : [];

// If you stored attachment ID in the 'image' JSON, retrieve the actual URL
$attachment_url = '';
if (!empty($image_data['id'])) {
    $attachment_url = wp_get_attachment_url($image_data['id']);
}

// 4) Include your standard WP-Pos header/variables
$active_page = get_query_var('active_page_wp_pos');
$active_sub_m = get_query_var('active_sub_m');
include_once('header.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Company Tool | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">View Company Tool</h1>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Tool Details</h5>
                            </div>
                            <div class="card-body">


                            <div class="mb-3">
                                            <label class="form-label">Barcode:</label><br>
                                            <?php
                                                $image_url  = "";
                                                
                                                if (isset($tool->barcode)) {
                                                    $image = wp_get_attachment_image_src($tool->barcode , 'full');
                                                    $image_url = $image[0];
                                                }
                                            ?>
                                            <img src="<?php echo esc_url($image_url); ?>" width="225px" alt="Barcode">
                                            
                             </div>

                                <!-- Tool Name -->
                                <div class="mb-3">
                                    <label class="form-label">Name:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($tool->tool_name); ?>" 
                                           readonly>
                                </div>

                                <!-- Tool Description -->
                                <div class="mb-3">
                                    <label class="form-label">Description:</label>
                                    <textarea class="form-control" rows="3" readonly>
                                        <?php echo esc_textarea($tool->tool_description); ?>
                                    </textarea>
                                </div>

                                <!-- Tool Type -->
                                <div class="mb-3">
                                    <label class="form-label">Type:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($tool->tool_type); ?>" 
                                           readonly>
                                </div>

                                <!-- Brand -->
                                <div class="mb-3">
                                    <label class="form-label">Brand:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($tool->brand_name); ?>" 
                                           readonly>
                                </div>

                                <!-- Category -->
                                <div class="mb-3">
                                    <label class="form-label">Category:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($tool->category); ?>" 
                                           readonly>
                                </div>

                                <!-- Location -->
                                <div class="mb-3">
                                    <label class="form-label">Location:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($tool->tool_locations); ?>" 
                                           readonly>
                                </div>

                                <!-- Price -->
                                <div class="mb-3">
                                    <label class="form-label">Price:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($tool->price); ?>" 
                                           readonly>
                                </div>

                                <!-- States -->
                                <div class="mb-3">
                                    <label class="form-label">States:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($tool->states); ?>" 
                                           readonly>
                                </div>

                                <!-- Quantity -->
                                <!--div class="mb-3">
                                    <label class="form-label">Quantity:</label>
                                    <input type="number" class="form-control"
                                           value="<?php echo esc_html($tool->quantity); ?>" 
                                           readonly>
                                </div-->

                                <!-- Image (if exists) -->
                                <?php if ($attachment_url): ?>
                                    <div class="mb-3">
                                        <label class="form-label d-block">Image:</label>
                                        <img src="<?php echo esc_url($attachment_url); ?>" 
                                             alt="Tool Image" 
                                             style="max-width: 300px; height:auto;">
                                    </div>
                                <?php else: ?>
                                    <div class="mb-3">
                                        <label class="form-label">Image:</label>
                                        <p>No image available.</p>
                                    </div>
                                <?php endif; ?>

                                <!-- Created At -->
                                <div class="mb-3">
                                    <label class="form-label">Created At:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($tool->created_at); ?>" 
                                           readonly>
                                </div>

                                <!-- Updated At -->
                                <div class="mb-3">
                                    <label class="form-label">Updated At:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($tool->updated_at); ?>" 
                                           readonly>
                                </div>

                            </div><!-- card-body -->
                        </div><!-- card -->
                    </div><!-- col-12 -->
                </div><!-- row -->
            </div><!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div><!-- main -->
</div><!-- wrapper -->
</body>
</html>