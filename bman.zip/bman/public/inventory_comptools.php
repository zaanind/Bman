<!DOCTYPE html>
<html lang="en">

<head>



   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title>Company Tools | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



	<main class="content">
	<div class="container-fluid p-0">
	<a href="<?php echo get_site_url(); ?>/inventory/company-tools/add" class="btn btn-primary float-end mt-n1"><i class="fas fa-plus"></i> Add New Tool</a>

					<div class="mb-3">
						<h1 class="h3 d-inline align-middle">Company Tools</h1>
					</div>

					<div class="row">
						<div class="col-12">
							
							<div class="card">
								
								<div class="card-body">
								
								
								
<table id="datatables-reponsive" class="table table-striped" style="width:100%">
    <thead>
        <tr>
            <th>Image</th>
            <th>Tool</th>        
            <th>Type</th>        
            <th>Location</th>
            <th>States</th>        
            <th>Action</th>
        </tr>
    </thead>
    
    <?php
        global $wpdb;
        $tools = $wpdb->get_results("SELECT tool_id,image, tool_name, tool_type, tool_locations, states FROM wp_zn_inventory_comp_tools WHERE quantity > 0");                               
    ?>
    <tbody>
    <?php 
        foreach ($tools as $row) {
     	    $image_url = "";
     	    $image_link = json_decode($row->image);
     	    if(isset($image_link->id)){
     	    
     	    $image = wp_get_attachment_image_src($image_link->id, 'table_90x90');
     	    $image_url = $image ? $image[0] : ($image_link->url ?? '');
            }
     	    
            echo '<tr>';
            echo "<td><image src='" . esc_url($image_url) . "' style='width: 60px;'/></td>";
            echo "<td>" . $row->tool_name . "</td>";
            echo "<td>" . $row->tool_type . "</td>";
            echo "<td>" . $row->tool_locations . "</td>";
            echo "<td>" . $row->states . "</td>";

            echo "<td> <div class='btn-group'> <button type='button' class='btn btn-primary dropdown-toggle' data-bs-toggle='dropdown' aria-expanded='false'>Actions</button> 
            <ul class='dropdown-menu'>
                <li><a class='dropdown-item' href='" .get_site_url() ."/inventory/company-tools/view?id=". $row->tool_id."'>View</a></li>
                <li><a class='dropdown-item' href='" .get_site_url() ."/inventory/company-tools/edit?id=". $row->tool_id."'>Edit</a></li>
                <li><a class='dropdown-item' href='". get_site_url() ."/inventory/company-tools/delete?id=" . $row->tool_id . "'>Delete</a></li> 
		  
            </ul></div></td>";

            echo '</tr>';
        }
    ?>
    </tbody>
</table>

								
								
	</div>
	</div>
	</div>
	</div>
    </div>
	
	
	
	</main>
	
			
			<?php include_once('footer.php');?>
		</div>
	</div>

			<script>
		document.addEventListener("DOMContentLoaded", function() {
			// Datatables Responsive
			$("#datatables-reponsive").DataTable({
				responsive: true
		
			});
		});
	</script>
	
</body>

</html>