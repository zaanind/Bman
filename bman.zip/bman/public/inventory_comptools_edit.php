<?php
session_start();

// 1. Access control
$homeurl       = get_site_url();
$wpuser_ob     = wp_get_current_user();
$allowed_roles = array('administrator');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Retrieve the tool record to edit
global $wpdb;
$table_name = $wpdb->prefix . 'zn_inventory_comp_tools';

// Make sure we have a tool_id in the query string
$tool_id   = 0;
$tool_data = null;
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $tool_id   = (int) $_GET['id'];
    $tool_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table_name} WHERE tool_id = %d",
        $tool_id
    ));
}

// If no valid record found, you can show an error or handle it gracefully
if (!$tool_data && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Show an error or redirect
    $_SESSION['error'] = 'Invalid tool ID.';
    wp_redirect($homeurl . '/inventory/company-tools');
    exit;
}

// 3. Handle form submission (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Safety check for tool_id in POST
    if (!isset($_POST['tool_id']) || empty($_POST['tool_id'])) {
        $_SESSION['error'] = 'Missing tool ID.';
        header('Location: ' . $homeurl . '/inventory/company-tools');
        exit;
    }

    // Sanitize/escape the tool ID
    $tool_id = (int) $_POST['tool_id'];

    // Gather form data
    $name        = sanitize_text_field($_POST['name']);
    $description = sanitize_text_field($_POST['description']);
    $type        = sanitize_text_field($_POST['type']);
    $brand       = sanitize_text_field($_POST['brand']);
    $category    = sanitize_text_field($_POST['category']);
    $location    = sanitize_text_field($_POST['location']);
    $price       = floatval($_POST['price']);
    // $quantity = (int) $_POST['quantity']; // Uncomment if you want to handle quantity

    // Retrieve the existing row again (to get current image, etc.)
    $existing_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table_name} WHERE tool_id = %d",
        $tool_id
    ));

    if (!$existing_data) {
        $_SESSION['error'] = 'No record found for this tool ID.';
        header('Location: ' . $homeurl . '/inventory/company-tools');
        exit;
    }

    // Keep existing image by default
    $json_image_info = $existing_data->image;

    // 4. Handle new image upload, if any
    if (!empty($_FILES['image']['name'])) {
        // If there's an old image, remove it
        if (!empty($existing_data->image)) {
            $old_image_data = json_decode($existing_data->image);
            if (!empty($old_image_data->id)) {
                // Remove attachment from the library
                wp_delete_attachment($old_image_data->id, true);
            }
        }

        // Process new upload
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $file   = $_FILES['image'];
        $upload = wp_handle_upload($file, ['test_form' => false]);

        if (isset($upload['error'])) {
            $_SESSION['error'] = 'Image Upload Failed';
            header('Location: ' . $homeurl . '/inventory/company-tools/edit?id=' . $tool_id);
            exit;
        }

        // Insert into media library
        $attachment = array(
            'guid'           => $upload['url'],
            'post_mime_type' => $upload['type'],
            'post_title'     => sanitize_file_name($file['name']),
            'post_content'   => '',
            'post_status'    => 'inherit',
        );
        $attach_id   = wp_insert_attachment($attachment, $upload['file']);
        $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
        wp_update_attachment_metadata($attach_id, $attach_data);

        $rep = [
            'success' => true,
            'id'      => $attach_id,
            // 'url'   => wp_get_attachment_url($attach_id), // can store if you like
        ];
        $json_image_info = json_encode($rep);
    }

    // 5. Build data array for update
    $data = [
        'tool_name'        => $name,
        'tool_type'        => $type,
        'brand_name'       => $brand,
        'tool_description' => $description,
        'category'         => $category,
        'tool_locations'   => $location,
        'price'            => $price,
        // 'quantity'      => $quantity, // Uncomment if needed
        'image'            => $json_image_info,
        // 'states'        => 'OK', // If you need to override or keep existing
        'updated_at'       => current_time('mysql'),
    ];

    // 6. Perform the update
    $updated = $wpdb->update(
        $table_name,
        $data,
        ['tool_id' => $tool_id]
    );

    if ($updated === false) {
        // DB error or some issue
        $_SESSION['error'] = 'Failed to update the tool.';
        header('Location: ' . $homeurl . '/inventory/company-tools/edit?id=' . $tool_id);
        exit;
    }

    // On success, redirect to the listing
    header('Location: ' . $homeurl . '/inventory/company-tools');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page  = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Edit Company Tool | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            if (isset($_SESSION['error'])) {
                $err = $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Error:</strong> <?php echo esc_html($err); ?>
                    </div>
                </div>
            <?php } ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Edit Company Tool</h1>

                <div class="row">
                    <div class="col-12">
                        <div class="card">	
                            <div class="card-body">

                                <?php if (!empty($tool_data)) : ?>
                                    <form method="POST" 
                                          action="<?php echo esc_url($homeurl . '/inventory/company-tools/edit?id=' . $tool_data->tool_id); ?>"
                                          enctype="multipart/form-data">
                                        <!-- Hidden input for the tool ID -->
                                        <input type="hidden" name="tool_id" 
                                               value="<?php echo esc_attr($tool_data->tool_id); ?>">

                                        
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Barcode:</label><br>
                                            <?php
                                                $image_url  = "";
                                                
                                                if (isset($tool_data->barcode)) {
                                                    $image = wp_get_attachment_image_src($tool_data->barcode , 'full');
                                                    $image_url = $image[0];
                                                }
                                            ?>
                                            <img src="<?php echo esc_url($image_url); ?>" width="225px" alt="Barcode">
                                            
                                        </div>
                                        
                                        
                                               <!-- Tool Name -->
                                        <div class="mb-3">
                                            <label class="form-label">Name:</label>
                                            <input type="text" class="form-control" name="name" required
                                                   value="<?php echo esc_attr($tool_data->tool_name); ?>">
                                        </div>

                                        <!-- Description -->
                                        <div class="mb-3">
                                            <label class="form-label">Description:</label>
                                            <input type="text" class="form-control" name="description"
                                                   value="<?php echo esc_attr($tool_data->tool_description); ?>">
                                        </div>

                                        <!-- Image -->
                                        <div class="mb-3">
                                            <label class="form-label">Image:</label><br>
                                            <?php
                                            $image_url  = '';
                                            $image_data = json_decode($tool_data->image);
                                            if (!empty($image_data->id)) {
                                                $image_src = wp_get_attachment_image_src($image_data->id, 'medium');
                                                if ($image_src) {
                                                    $image_url = $image_src[0];
                                                }
                                            }
                                            if ($image_url) :
                                                ?>
                                                <img src="<?php echo esc_url($image_url); ?>" width="200" alt="Tool Image">
                                            <?php endif; ?>
                                            <input class="form-control form-control-lg mt-2" type="file" name="image">
                                        </div>

                                        <!-- Type -->
                                        <div class="mb-3">
                                            <label class="form-label">Type:</label>
                                            <select class="form-control" name="type" required>
                                                <option>Select</option>
                                                <option value="Office" 
                                                    <?php selected($tool_data->tool_type, 'Office'); ?>>
                                                    Office
                                                </option>
                                                <option value="Workplace" 
                                                    <?php selected($tool_data->tool_type, 'Workplace'); ?>>
                                                    Workplace
                                                </option>
                                            </select>
                                        </div>

                                        <!-- Brand -->
                                        <div class="mb-3">
                                            <label class="form-label">Brand:</label>
                                            <select class="form-control" name="brand" required>
                                                <option>Select</option>
                                                <?php 
                                                $brand_list = $wpdb->get_results("SELECT * FROM wp_pos_system_brands");
                                                foreach ($brand_list as $row) {
                                                    ?>
                                                    <option value="<?php echo esc_attr($row->brand_name); ?>"
                                                        <?php selected($tool_data->brand_name, $row->brand_name); ?>>
                                                        <?php echo esc_html($row->brand_name); ?>
                                                    </option>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <!-- Category -->
                                        <div class="mb-3">
                                            <label class="form-label">Category:</label>
                                            <select class="form-control" name="category" required>
                                                <option>Select</option>
                                                <?php 
                                                $cat_list = $wpdb->get_results("SELECT * FROM wp_pos_system_categories");
                                                foreach ($cat_list as $row) {
                                                    // Adjust if your column is 'category' or 'category_name'
                                                    $cat_value = isset($row->category_name) ? $row->category_name : $row->category;
                                                    ?>
                                                    <option value="<?php echo esc_attr($cat_value); ?>"
                                                        <?php selected($tool_data->category, $cat_value); ?>>
                                                        <?php echo esc_html($cat_value); ?>
                                                    </option>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <!-- (Optional) Quantity
                                        <div class="mb-3 col-lg-3">
                                            <label class="form-label">Quantity:</label>
                                            <input type="number" class="form-control" name="quantity"
                                                   value="<?php //echo esc_attr($tool_data->quantity); ?>">
                                        </div>
                                        -->

                                        <!-- Location -->
                                        <div class="mb-3">
                                            <label class="form-label">Location:</label>
                                            <input type="text" class="form-control" name="location"
                                                   value="<?php echo esc_attr($tool_data->tool_locations); ?>">
                                        </div>

                                        <!-- Price -->
                                        <div class="mb-3 col-lg-3">
                                            <label class="form-label">Price:</label>
                                            <input type="number" class="form-control" name="price" step="0.01" required
                                                   value="<?php echo esc_attr($tool_data->price); ?>">
                                        </div>

                                        <button class="btn btn-outline-primary float-end" type="submit">Update</button>
                                    </form>
                                <?php else : ?>
                                    <p>No tool data found or invalid tool ID.</p>
                                <?php endif; ?>

                            </div> <!-- card-body -->
                        </div> <!-- card -->
                    </div> <!-- col-12 -->
                </div> <!-- row -->
            </div> <!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>
</body>
</html>