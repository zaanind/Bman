<?php
session_start();

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator',);


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}




include_once('barcode_lib.php');
// Function to generate a barcode, upload it to the Media Library, and return the attachment ID
function generate_and_upload_barcode($info_id) {
    $upload_dir = wp_upload_dir();
    $barcode_filename = "COMPMAT_" . $info_id . ".png";
    $barcode_path = $upload_dir['path'] . '/' . $barcode_filename;

    // Generate Barcode
    barcode($barcode_path, "COMPMAT_" . $info_id, 100, "horizontal", "code128", false, 3);

    if (!file_exists($barcode_path)) {
        return new WP_Error('barcode_generation_failed', 'Failed to generate barcode.');
    }

    // Upload to Media Library
    $filetype = wp_check_filetype($barcode_filename, null);
    $attachment = array(
        'guid'           => $upload_dir['url'] . '/' . $barcode_filename,
        'post_mime_type' => $filetype['type'],
        'post_title'     => "Barcode for Company Material " . $info_id,
        'post_content'   => '',
        'post_status'    => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $barcode_path);

    if (is_wp_error($attach_id)) {
        return $attach_id;
    }

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $barcode_path);
    wp_update_attachment_metadata($attach_id, $attach_data);

    return $attach_id;
}





   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	  global $wpdb;

        
      $homeurl = get_site_url();

      $name = $_POST['name'];
	  $description = $_POST['description'];
	  $quantity = $_POST['quantity'];
	  $brand = $_POST['brand']; 
	  $category = $_POST['category'];
      $exp_date = $_POST['expire_date'];
	//  $states = $_POST['states'];
	  $price = $_POST['price'];
	  $type = $_POST['type'];
      $location = $_POST['location'];
      
	   if (isset($_FILES['image'])) {

            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            $file = $_FILES['image'];
            $upload = wp_handle_upload($file, ['test_form' => false]);
            if (isset($upload['error'])) { 
               $_SESSION['error'] = 'Image Upload Failed';
               header('location:'.$homeurl.'/inventory/company-materials/add/');
               exit;


              }

                  // Insert into media library
            $attachment = array(
               'guid'           => $upload['url'],
               'post_mime_type' => $upload['type'],
               'post_title'     => sanitize_file_name($file['name']),
               'post_content'   => '',
               'post_status'    => 'inherit',
                );
            $attach_id = wp_insert_attachment($attachment, $upload['file']);
            $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
            wp_update_attachment_metadata($attach_id, $attach_data);
            $rep =  [
                      'success' => true,
                      'id'      => $attach_id,
                     // 'url'     => wp_get_attachment_url($attach_id),
                  ];
            $json_image_info = json_encode($rep); }
      
	  
	
  
 	$table_name = $wpdb->prefix . 'zn_inventory_comp_meterials';
    $data = array(
        'item_name' => $name,
        'brand_name' => $brand,
	    'category' => $category,
	    'price' => $price,
	    'states' => 'OK', 
        'quantity' => $quantity,
		'item_description' => $description,
		'type' => $type,
        'location' => $location,
		'image' => $json_image_info,
        'exp_date' => $exp_date,
      );
	
	
    $inserted = $wpdb->insert($table_name, $data); 

    // Get the newly inserted order ID
    $info_id = $wpdb->insert_id;
    // Generate and upload the barcode
    $barcode_attachment_id = generate_and_upload_barcode($info_id);
    if (!empty($barcode_attachment_id)) {
        // Update the order with the barcode attachment ID
        $wpdb->update($table_name, ['barcode' => $barcode_attachment_id], ['item_id' => $info_id]);
    }

	  
        if ($inserted === false) {
		  $_SESSION['error'] = 'Failed';
		  header('location:'.$homeurl.'/inventory/company-materials/add/');
		  exit;
      

	  }


    
	header('location:'.$homeurl.'/inventory/company-materials');
}
		


?>


<!DOCTYPE html>
<html lang="en">
   <head>
   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title>Add Company Material | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



			<main class="content">
			<?php
                   if (isset($_SESSION['error'])) {
                         $err = $_SESSION['error'];
                         unset($_SESSION['error']);?>
						 
						 			<div class="alert alert-danger alert-dismissible" role="alert">
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											<div class="alert-message">
												<strong>Error:</strong> Failed to add item
											</div>
										</div>

						<?php }	?>
								
								
					
										
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Add New Company Material</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
						
								<div class="card-body">
								       
                                      <form method="POST" action="<?php echo get_site_url(); ?>/inventory/company-materials/add" enctype="multipart/form-data">
                                    
    									<div class="mb-3">
                                            <label  class="form-label">Name:</label>
                                            <input type="text" class="form-control"  name="name" required>
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Description:</label>
                                            <input type="text" class="form-control"  name="description">
                                        </div>

                                        <div class="mb-3">
                                            <label  class="form-label">Expire Date:</label>
                                            <input type="date" class="form-control"  name="expire_date">
                                        </div>

                                        <div class="mb-3">
                                            <label  class="form-label">Image:</label></br>
                                            <input class="form-control form-control-lg" id="formFileLg" type="file" name="image" required>
                                        </div>

										
										
												
										<div class="mb-3 ">
                                            <label  class="form-label">Type:</label>
                                  	
										    <select class="form-control" name="type" required>
											<option>Select</option>
											<option>Liquid</option>
											<option>Solid</option>
											
											 

											</select>
                                        </div>

										
										<div class="mb-3 ">
                                            <label  class="form-label">Brand:</label>
                                            <!--input type="text" class="form-control"  name="brand" required-->
											
										    <select class="form-control" name="brand" required>
											<?php 
											global $wpdb;
											$brand_list =  $wpdb->get_results("SELECT * FROM wp_pos_system_brands");
										    echo "<option>Select</option>";
											foreach ($brand_list as $row) { echo "<option>". $row->brand_name ."</option>";}
											?>
											    
											 

											</select>
                                        </div>
										
										
										<div class="mb-3 ">
                                            <label  class="form-label">Category:</label>
                                            <!--input type="text" class="form-control"  name="category" required-->
											
											 <select class="form-control" name="category" required>
											  	<?php 
											global $wpdb;
											$cat_list =  $wpdb->get_results("SELECT * FROM wp_pos_system_categories");
										    echo "<option>Select</option>";
											foreach ($cat_list as $row) { echo "<option>". $row->category_name ."</option>";}
											?>

											</select>
											
                                        </div>
                                        
                                        
                                        <div class="mb-3">
                                          <label class="form-label">Location:</label>
                                          <input type="text" class="form-control" name="location" value='company'>
                                      </div>
										
										<!--div class="mb-3 ">
                                            <label  class="form-label">States:</label>
                                            <input type="text" class="form-control"  name="states" required>
                                        </div-->
										
										<div class="mb-3 col-lg-3">
                                            <label  class="form-label">Quantity:</label>
                                            <input type="number" class="form-control"  name="quantity" required>
                                        </div>
										
										<div class="mb-3 col-lg-3">
                                            <label  class="form-label">Price:</label>
                                            <input type="number" class="form-control"  name="price" required>
                                        </div>
										
										<button class="btn btn-outline-primary float-end"> Add</button>
										</form>
								<!--input type="text" class="form-control" placeholder="Input"-->
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>


			
			
			
			
			<?php include_once('footer.php');?>
		</div>
	</div>

	

	
</body>

</html>