<?php
session_start();

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

global $wpdb;

// 1. Get the item ID from the query string
$item_id = 0;
$result = array();
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $item_id = (int) $_GET['id'];
    // Retrieve existing material data
    $sql = $wpdb->prepare("SELECT * FROM {$wpdb->prefix}zn_inventory_comp_meterials WHERE item_id = %d", $item_id);
    $result = $wpdb->get_results($sql);
}

// 2. Handle form POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Make sure we have the item_id from the form
    if (!isset($_POST['item_id']) || empty($_POST['item_id'])) {
        $_SESSION['error'] = 'Missing item ID.';
        header('Location: ' . $homeurl . '/inventory/company-materials');
        exit;
    }

    $table_name = $wpdb->prefix . 'zn_inventory_comp_meterials';
    $item_id = (int) $_POST['item_id'];

    // Gather form data
    $name        = sanitize_text_field($_POST['name']);
    $description = sanitize_text_field($_POST['description']);
    $quantity    = intval($_POST['quantity']);
    $brand       = sanitize_text_field($_POST['brand']);
    $category    = sanitize_text_field($_POST['category']);
    $price       = floatval($_POST['price']);
    $type        = sanitize_text_field($_POST['type']);
    $exp_date = $_POST['expire_date'];
    $location = $_POST['location'];
    // If you have a 'states' field, retrieve it as well:
    // $states   = sanitize_text_field($_POST['states']);

    // Retrieve the existing row to get the current image data
    $current_item = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table_name} WHERE item_id = %d", $item_id)
    );

    // Default to current image JSON if no new image is uploaded
    $json_image_info = (!empty($current_item->image)) ? $current_item->image : '';

    // 3. If a new image was uploaded, process & replace
    if (!empty($_FILES['image']['name'])) {
        // Remove old image if exists
        if (!empty($current_item->image)) {
            $old_image_data = json_decode($current_item->image);
            if (!empty($old_image_data->id)) {
                // This will remove the attachment from the library and delete the file
                wp_delete_attachment($old_image_data->id, true);
            }
        }

        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $file   = $_FILES['image'];
        $upload = wp_handle_upload($file, ['test_form' => false]);

        if (isset($upload['error'])) {
            $_SESSION['error'] = 'Image Upload Failed';
            header('Location: ' . $homeurl . '/inventory/company-materials/edit?id=' . $item_id);
            exit;
        }

        // Insert into media library
        $attachment = array(
            'guid'           => $upload['url'],
            'post_mime_type' => $upload['type'],
            'post_title'     => sanitize_file_name($file['name']),
            'post_content'   => '',
            'post_status'    => 'inherit',
        );
        $attach_id   = wp_insert_attachment($attachment, $upload['file']);
        $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
        wp_update_attachment_metadata($attach_id, $attach_data);

        $rep = [
            'success' => true,
            'id'      => $attach_id,
            // 'url'   => wp_get_attachment_url($attach_id), // you can store the URL if needed
        ];
        $json_image_info = json_encode($rep);
    }

    // 4. Build the data array for update
    $data = [
        'item_name'        => $name,
        'brand_name'       => $brand,
        'category'         => $category,
        'price'            => $price,
        // 'states'         => $states, // uncomment if you have a states field to update
        'quantity'         => $quantity,
        'item_description' => $description,
        'type'             => $type,
        'location' => $location,
        'image'            => $json_image_info,
        'exp_date' => $exp_date,
    ];

    // 5. Perform the update
    $updated = $wpdb->update(
        $table_name,
        $data,
        ['item_id' => $item_id] // WHERE condition
    );

    if ($updated === false) {
        // If $updated is false, there was a DB error
        $_SESSION['error'] = 'Failed to update item.';
        header('Location: ' . $homeurl . '/inventory/company-materials/edit?id=' . $item_id);
        exit;
    }

    // On success (or no changes = 0 rows affected), redirect back to listing
    header('Location: ' . $homeurl . '/inventory/company-materials');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos'); 
    $active_sub_m = get_query_var('active_sub_m'); 
    include_once('header.php');
    ?>
    <title>Edit Company Material | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            if (isset($_SESSION['error'])) {
                $err = $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Error:</strong> <?php echo $err; ?>
                    </div>
                </div>
            <?php } ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Edit Company Material</h1>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <?php if (!empty($result)) : ?>
                                    <form method="POST" action="" enctype="multipart/form-data">
                                        <!-- Hidden input for the item ID -->
                                        <input type="hidden" name="item_id"
                                               value="<?php echo esc_attr($result[0]->item_id); ?>">

                                        <div class="mb-3">
                                            <label class="form-label">Barcode:</label><br>
                                            <?php
                                                $image_url  = "";
                                                
                                                if (isset($result[0]->barcode)) {
                                                    $image = wp_get_attachment_image_src($result[0]->barcode , 'full');
                                                    $image_url = $image[0];
                                                }
                                            ?>
                                            <img src="<?php echo esc_url($image_url); ?>" width="225px" alt="Barcode">
                                            
                                         </div>
                                               
                                        <div class="mb-3">
                                            <label class="form-label">Name:</label>
                                            <input type="text" class="form-control" name="name" required
                                                   value="<?php echo esc_attr($result[0]->item_name); ?>">
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">Description:</label>
                                            <input type="text" class="form-control" name="description"
                                                    value="<?php echo esc_attr($result[0]->item_description); ?>">
                                        </div>

                                        <div class="mb-3">
    <label class="form-label">Expire Date:</label>
    <input type="date" class="form-control" name="expire_date" value="<?php
    if (!empty($result[0]->exp_date) && $result[0]->exp_date !== '0000-00-00') {
        // Format the date to YYYY-MM-DD for HTML5 date input
        $formatted_date = date("Y-m-d", strtotime($result[0]->exp_date));
        echo esc_attr($formatted_date);
    }
    ?>">
</div>

                                        <!-- Display existing image -->
                                        <?php
                                        $image_url  = "";
                                        $image_link = json_decode($result[0]->image);
                                        if (isset($image_link->id)) {
                                            $image_src = wp_get_attachment_image_src($image_link->id, 'full');
                                            if ($image_src) {
                                                $image_url = $image_src[0];
                                            }
                                        }
                                        ?>
                                        <div class="mb-3">
                                            <label class="form-label">Image:</label><br>
                                            <?php if (!empty($image_url)) : ?>
                                                <img src="<?php echo esc_url($image_url); ?>" alt="Material Image"
                                                     style="max-width: 200px;">
                                            <?php endif; ?>
                                            <input class="form-control form-control-lg mt-2" type="file" name="image">
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">Type:</label>
                                            <select class="form-control" name="type" required>
                                                <option>Select</option>
                                                <option value="Liquid" <?php selected($result[0]->type, 'Liquid'); ?>>Liquid</option>
                                                <option value="Solid" <?php selected($result[0]->type, 'Solid'); ?>>Solid</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">Brand:</label>
                                            <select class="form-control" name="brand" required>
                                                <option>Select</option>
                                                <?php 
                                                $brand_list = $wpdb->get_results("SELECT * FROM wp_pos_system_brands");
                                                foreach ($brand_list as $row) {
                                                    $selected = ($result[0]->brand_name === $row->brand_name) ? 'selected' : '';
                                                    echo "<option $selected>" . esc_html($row->brand_name) . "</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">Category:</label>
                                            <select class="form-control" name="category" required>
                                                <option>Select</option>
                                                <?php
                                                $cat_list = $wpdb->get_results("SELECT * FROM wp_pos_system_categories");
                                                foreach ($cat_list as $row) {
                                                    $selected = ($result[0]->category === $row->category_name) ? 'selected' : '';
                                                    echo "<option $selected>" . esc_html($row->category_name) . "</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>


                                        <div class="mb-3">
                                          <label class="form-label">Location:</label>
                                          <input type="text" class="form-control" name="location" value="<?php echo esc_attr($result[0]->location); ?>">
                                      </div>

                                        <!-- If you want to allow editing 'states': 
                                        <div class="mb-3">
                                            <label class="form-label">States:</label>
                                            <input type="text" class="form-control" name="states"
                                                   value="<?php // echo esc_attr($result[0]->states); ?>">
                                        </div>
                                        -->

                                        <div class="mb-3 col-lg-3">
                                            <label class="form-label">Quantity:</label>
                                            <input type="number" class="form-control" name="quantity" required
                                                   value="<?php echo esc_attr($result[0]->quantity); ?>">
                                        </div>

                                        <div class="mb-3 col-lg-3">
                                            <label class="form-label">Price:</label>
                                            <input type="number" class="form-control" name="price" required
                                                   value="<?php echo esc_attr($result[0]->price); ?>">
                                        </div>

                                        <button class="btn btn-outline-primary float-end" type="submit">Update</button>
                                    </form>
                                <?php else : ?>
                                    <p>No valid material found or invalid ID.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>
</body>
</html>