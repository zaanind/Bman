<?php
session_start();

// 1) Check user roles
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
// If you want employees to view too, add them here:
$allowed_roles = array('administrator');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2) Fetch the material record from DB
global $wpdb;
$table_name = $wpdb->prefix . 'zn_inventory_comp_meterials'; // Keep the same name used in your insert code

$item_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$item_id) {
    // If no ID, go back to listing page
    wp_redirect($homeurl . '/inventory/company-materials');
    exit;
}

// Get the record
$item = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table_name} WHERE item_id = %d", $item_id)
);

$state_text = $item->states;
$state_class = "";
$today = date('Y-m-d');

if ($item->quantity <= 2) {
    $state_text = ($item->quantity == 0) ? "Stock End" : "Low Quantity";
    $state_class = "text-danger";
}

if ($item->exp_date && $item->exp_date <= $today) {
    $state_text = "Expired";
    $state_class = "text-danger";
}

// If record not found, redirect
if (!$item) {
    wp_redirect($homeurl . '/inventory/company-materials');
    exit;
}

// 3) Decode JSON for image if stored as JSON (with attachment ID, etc.)
$image_data = !empty($item->image) ? json_decode($item->image, true) : [];
$attachment_url = '';
if (!empty($image_data['id'])) {
    $attachment_url = wp_get_attachment_url($image_data['id']);
}

// 4) Include your standard WP-Pos header
$active_page = get_query_var('active_page_wp_pos');
$active_sub_m = get_query_var('active_sub_m');
include_once('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Company Material | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">View Company Material</h1>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Material Details</h5>
                            </div>
                            <div class="card-body">
                                
                            
                            <div class="mb-3">
                                            <label class="form-label">Barcode:</label><br>
                                            <?php
                                                $image_url  = "";
                                                
                                                if (isset($item->barcode)) {
                                                    $image = wp_get_attachment_image_src($item->barcode , 'full');
                                                    $image_url = $image[0];
                                                }
                                            ?>
                                            <img src="<?php echo esc_url($image_url); ?>" width="225px" alt="Barcode">
                                            
                             </div>
                            
                            <!-- Name -->
                                <div class="mb-3">
                                    <label class="form-label">Name:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->item_name); ?>" 
                                           readonly>
                                </div>

                                <!-- Description -->
                                <div class="mb-3">
                                    <label class="form-label">Description:</label>
                                    <textarea class="form-control" rows="3" readonly>
                                        <?php echo esc_textarea($item->item_description); ?>
                                    </textarea>
                                </div>

                                
                                <div class="mb-3">
    <label class="form-label">Expire Date:</label>
    <input type="date" class="form-control" name="expire_date" value="<?php
    if (!empty($item->exp_date) && $item->exp_date !== '0000-00-00') {
        // Format the date to YYYY-MM-DD for HTML5 date input
        $formatted_date = date("Y-m-d", strtotime($item->exp_date));
        echo esc_attr($formatted_date);
    }
    ?>">
</div>

                                <!-- Type -->
                                <div class="mb-3">
                                    <label class="form-label">Type:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->type); ?>" 
                                           readonly>
                                </div>

                                <!-- Color (if you use it) -->
                                <!--div class="mb-3">
                                    <label class="form-label">Color:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->color); ?>" 
                                           readonly>
                                </div-->

                                <!-- Brand -->
                                <div class="mb-3">
                                    <label class="form-label">Brand:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->brand_name); ?>" 
                                           readonly>
                                </div>

                                <!-- Category -->
                                <div class="mb-3">
                                    <label class="form-label">Category:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->category); ?>" 
                                           readonly>
                                </div>

                                <!-- Price -->
                                <div class="mb-3">
                                    <label class="form-label">Price:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->price); ?>" 
                                           readonly>
                                </div>

                                <!-- States -->
                                <div class="mb-3">
                                    <label class="form-label">States:</label>
                                    <input type="text" class="form-control <?php echo $state_class; ?>" value="<?php echo esc_html($state_text); ?>" readonly>
                                </div>

                                <!-- Quantity -->
                                <div class="mb-3">
                                    <label class="form-label">Quantity:</label>
                                    <input type="number" class="form-control"
                                           value="<?php echo esc_html($item->quantity); ?>" 
                                           readonly>
                                </div>

                                <!-- Image -->
                                <?php if ($attachment_url): ?>
                                    <div class="mb-3">
                                        <label class="form-label d-block">Image:</label>
                                        <img src="<?php echo esc_url($attachment_url); ?>" 
                                             alt="Material Image" 
                                             style="max-width: 300px; height:auto;">
                                    </div>
                                <?php else: ?>
                                    <div class="mb-3">
                                        <label class="form-label">Image:</label>
                                        <p>No image available.</p>
                                    </div>
                                <?php endif; ?>

                                <!-- Created At -->
                                <div class="mb-3">
                                    <label class="form-label">Created At:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->created_at); ?>" 
                                           readonly>
                                </div>

                                <!-- Updated At -->
                                <div class="mb-3">
                                    <label class="form-label">Updated At:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->updated_at); ?>" 
                                           readonly>
                                </div>

                            </div> <!-- card-body -->
                        </div> <!-- card -->
                    </div> <!-- col-12 -->
                </div> <!-- row -->
            </div> <!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div> <!-- main -->
</div> <!-- wrapper -->
</body>
</html>