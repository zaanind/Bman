<?php
session_start();

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator',);


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}






if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pos_system_suppliers'; // Use the suppliers table name
    
    // Get the form input data
    $supplier_name = $_POST['supplier_name'];
    $contact_phone = $_POST['contact_phone'];
    $contact_email = $_POST['contact_email'];
    $address = $_POST['address'];

    // Prepare data for insertion
    $data = array(
        'supplier_name' => $supplier_name,
        'contact_phone' => $contact_phone,
        'contact_email' => $contact_email,
        'address' => $address,

    );

    // Insert the data into the database
    $inserted = $wpdb->insert($table_name, $data);

    // Check if the insertion was successful
    if ($inserted === false) {
        // Set an error message and redirect back to the form page
        $_SESSION['error'] = 'Failed to add supplier';
        header('Location: ' . get_site_url() . '/inventory/suppliers/add');
        exit;
    }

    // Redirect to the suppliers list page after successful insertion
    header('Location: ' . get_site_url() . '/inventory/suppliers');
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

   <head>
   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title>Add Supplier | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



			<main class="content">
			<?php
                   if (isset($_SESSION['error'])) {
                         $err = $_SESSION['error'];
                         unset($_SESSION['error']);?>
						 
						 			<div class="alert alert-danger alert-dismissible" role="alert">
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											<div class="alert-message">
												<strong>Error:</strong> Failed to add item
											</div>
										</div>

						<?php }	?>
								
								
					
										
			<div class="container-fluid p-0">

    <h1 class="h3 mb-3">Add New Supplier</h1>

    <div class="row">
        <div class="col-12">
            <div class="card">

                <div class="card-body">
                    <form method="POST" action="<?php echo get_site_url(); ?>/inventory/suppliers/add" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label class="form-label">Supplier Name:</label>
                            <input type="text" class="form-control" name="supplier_name" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Contact Phone:</label>
                            <input type="text" class="form-control" name="contact_phone" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email:</label>
                            <input type="email" class="form-control" name="contact_email" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Address:</label>
                            <input type="text" class="form-control" name="address">
                        </div>

                        <button class="btn btn-outline-primary float-end">Add Supplier</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

			</main>


			
			
			
			
			<?php include_once('footer.php');?>
		</div>
	</div>

	

	

</body>

</html>