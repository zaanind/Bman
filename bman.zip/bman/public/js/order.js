function delete () {
 alert ("hello");   
}