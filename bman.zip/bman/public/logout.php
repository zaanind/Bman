<?php

$homeurl = get_site_url();
wp_logout();
header('location:'.$homeurl.'/sys-login');
exit;


 ?>