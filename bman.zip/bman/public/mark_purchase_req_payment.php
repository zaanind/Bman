<?php
session_start();
include_once('bcore.php');
// 1. Access Control
$homeurl       = get_site_url();
$wpuser_ob     = wp_get_current_user();
$allowed_roles = array('administrator','salesman');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Validate and fetch the order
global $wpdb;
$table_name = 'wp_zn_met_requests';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = 'Invalid order ID.';
    wp_redirect($homeurl . '/prs/');
    exit;
}

$order_id = (int) $_GET['id'];

// Fetch the existing order
$order = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_name} WHERE id = %d",
    $order_id
));
if (!$order) {
    $_SESSION['error'] = ' not found.';
    wp_redirect($homeurl . '/prs/');
    exit;
}




// 3. Handle POST (Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    
 

    

    // Payment info
    $payment_type   = sanitize_text_field($_POST['payment_type']);
    
	


	$amount = $order->price * $order->quantity;
	//echo $amount;



    if($payment_type=='Cash'){  

        $data = array(
            'payee' => 'Company',
			'ref_type' => 'Material Purchase',
			'ref_no' => $id,
			'deposit' => $amount,
			'payment' => $amount,
			'balance' => $amount,
			
			

        );
    
    
      save_cashbook($data);
    
    }
    
    
    if($payment_type=='Cheque'){
		
	//	$cheque_no = sanitize_text_field($_POST['cheque_no']) ?? 'None';

         $data = array(
            'payee' => 'Company',
            'deposit' => $amount,
            'ref_type' => 'Material Purchase',
            'ref_no' => $receipt_no,
            'payment' => $amount, 
			'payment_date' =>  current_time('mysql'),
			'cheque_no' =>  '0',

        );
        
        save_cheque_data($data);
        
        
    }

    
    
    //$updated = $wpdb->update($table_name, $update_data, ['order_id' => $order_id]);
    if ($updated === false) {
        $_SESSION['error'] = 'Failed to update order.';
        wp_redirect($homeurl . '/prs/mark-payment?id=' . $order_id);
        exit;
    }

    wp_redirect($homeurl . '/prs/');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // Standard WP plugin includes
    $active_page  = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Mark Payments</title>
    
    <!-- You can reuse the same CSS as in your Add page -->
    <style>
        .customer_suggestions {
            border: 1px solid #ccc;
            max-height: 150px;
            overflow-y: auto;
            position: absolute;
            background: white;
            width: 100%;
            z-index: 1000;
            display:none;
        }
        .suggestion-item, .suggestion-item_table {
            cursor: pointer;
            padding: 8px;
        }
        .suggestion-item:hover, .suggestion-item_table:hover {
            background: #f0f0f0;
        }
        /* DataTables override if needed */
        .dataTables_wrapper .dataTables_filter, 
        .dataTables_wrapper .dataTables_length, 
        .dataTables_wrapper .dataTables_info, 
        .dataTables_wrapper .dataTables_paginate {
            display: none !important; /* Hiding since you said no paging, searching, etc. */
        }
    </style>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            // Display error messages if any
            if (isset($_SESSION['error'])) {
                $err = $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Error:</strong> <?php echo esc_html($err); ?>
                    </div>
                </div>
            <?php } ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Mark Payment</h1>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <form method="POST" 
                                      action="<?php echo esc_url($homeurl . '/prs/mark-payment?id=' . $order->id); ?>"
                                      enctype="multipart/form-data">
         


                                 
                                                
                                                

                               

                                

                                    <!-- Payment Info -->
                                    <div class="mb-3" style="margin-top:30px;">
                                        <label class="form-label">Payment Type:</label>
                                        <select class="form-control" name="payment_type" required>
                                            <?php
                                            $types = ['Select','Cash','Cheque',];
                                            foreach ($types as $t) {
                                               // $sel = ($order->payment_method === $t) ? 'selected' : '';
                                                echo "<option>$t</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
									
								

                             

                                    <button class="btn btn-outline-primary float-end" type="submit">
                                       Mark Payment
                                    </button>
                                </form>
                            </div><!-- card-body -->
                        </div><!-- card -->
                    </div><!-- col-12 -->
                </div><!-- row -->
            </div><!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

</body>
</html>