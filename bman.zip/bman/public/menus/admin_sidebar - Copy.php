
				<ul class="sidebar-nav">
					<li class="sidebar-header">
					System
					</li>

					<li class="sidebar-item <?php if ($active_page=='dashboard'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>">
                    <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
                    </a>
					</li>

				    <li class="sidebar-item <?php if ($active_page=='inventory'){echo 'active';}?>">
				    <a class="sidebar-link" href="<?php echo get_site_url(); ?>/inventory">
                    <i class="align-middle" data-feather="box"></i> <span class="align-middle">Inventory</span>
                    </a>
				    </li>
					
			        <li class="sidebar-item <?php if ($active_page=='orders'){echo 'active';}?>">
			        <a class="sidebar-link" href="<?php echo get_site_url(); ?>/orders">
                    <i class="align-middle" data-feather="shopping-cart"></i> <span class="align-middle">Invoices</span>
                    </a>
				    </li>
				
			        <li class="sidebar-item <?php if ($active_page=='customers'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/customers">
                    <i class="align-middle" data-feather="user"></i> <span class="align-middle">Customers</span>
                    </a>
					</li>
					
					
			       <li class="sidebar-item <?php if ($active_page=='hr'){echo 'active';}?>">
			       <a class="sidebar-link" href="<?php echo get_site_url(); ?>/hr">
                   <i class="align-middle" data-feather="users"></i> <span class="align-middle">HR</span>
                   </a>
				   </li>
					
			
			
			        <li class="sidebar-item <?php if ($active_page=='projects'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/projects">
                    <i class="align-middle" data-feather="list"></i> <span class="align-middle">Projects</span>
                    </a>
					</li>
					
			        <li class="sidebar-item <?php if ($active_page=='accounting'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/accounting">
                    <i class="align-middle" data-feather="dollar-sign"></i> <span class="align-middle">Accounting</span>
                    </a>
					</li>
					
	



                    <?php if ($active_page=='inventory'){ ?>
					<li class="sidebar-header">
						Menu
					</li>
					
					<li class="sidebar-item  <?php if ($active_sub_m=='products'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/inventory/products">
                    <i class="align-middle" data-feather="box"></i> <span class="align-middle">Products</span>
                    </a>
					</li>
					
				


					<li class="sidebar-item <?php if ($active_sub_m=='brands'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/inventory/brands">
                    <i class="align-middle" data-feather="bold"></i> <span class="align-middle">Brands</span>
                    </a>
					</li>

					<li class="sidebar-item <?php if ($active_sub_m=='categories'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/inventory/categories">
                    <i class="align-middle" data-feather="grid"></i> <span class="align-middle">Categories</span>
                    </a>
					</li>

					

			
					
					
					
					 <li class="sidebar-item <?php if ($active_sub_m=='suppliers'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/inventory/suppliers">
                    <i class="align-middle" data-feather="truck"></i> <span class="align-middle">Suppliers</span>
                    </a>
					</li>
					
					 <li class="sidebar-item <?php if ($active_sub_m=='company-tools'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/inventory/company-tools">
                    <i class="align-middle" data-feather="settings"></i> <span class="align-middle">Company Tools</span>
                    </a>
					</li>
					
					 <li class="sidebar-item <?php if ($active_sub_m=='company-materials'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/inventory/company-materials">
                    <i class="align-middle" data-feather="package"></i> <span class="align-middle">Company Materials</span>
                    </a>
					</li>

                    <?php } ?>
					
					
					
					<?php if ($active_page=='hr'){ ?>
					<li class="sidebar-header">
					Menu
					</li>
					
					
					<li class="sidebar-item  <?php if ($active_sub_m=='employee-list'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/hr/employee-list">
                    <i class="align-middle" data-feather="users"></i> <span class="align-middle">Employee List</span>
                    </a>
					</li>
					
					
					<li class="sidebar-item  <?php if ($active_sub_m=='add-employee'){echo 'active';}?>">
				  	<a class="sidebar-link" href="<?php echo get_site_url(); ?>/hr/add-employee">
                    <i class="align-middle" data-feather="user-plus"></i> <span class="align-middle">Add Employee</span>
                    </a>
					</li>
					
					<li class="sidebar-item  <?php if ($active_sub_m=='attendance'){echo 'active';}?>">
				  	<a class="sidebar-link" href="<?php echo get_site_url(); ?>/hr/attendance">
                    <i class="align-middle" data-feather="calendar"></i> <span class="align-middle">Attendance</span>
                    </a>
					</li>
					
					<!--li class="sidebar-item  <?php if ($active_sub_m=='leaves'){echo 'active';}?>">
				  	<a class="sidebar-link" href="<?php echo get_site_url(); ?>/hr/leaves">
                    <i class="align-middle" data-feather="user-minus"></i> <span class="align-middle">Leaves</span>
                    </a>
					</li-->
					
				



                    <?php } ?>



			
					<?php if ($active_page=='projects'){ ?>
					<li class="sidebar-header">
					Menu
					</li>
					
					
					<li class="sidebar-item  <?php if ($active_sub_m=='add'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/projects/add">
                    <i class="align-middle" data-feather="plus"></i> <span class="align-middle">Add Project</span><!--remove this when developed-->
                    </a>
					</li>
					
					
					<!--li class="sidebar-item  <?php if ($active_sub_m=='add-employee'){echo 'active';}?>">
				  	<a class="sidebar-link" href="<?php echo get_site_url(); ?>/hr/add-employee">
                    <i class="align-middle" data-feather="user-plus"></i> <span class="align-middle">Add Employee</span>
                    </a>
					</li-->
					
			



                    <?php } ?>
					
					
					<?php if ($active_page=='orders'){ ?>
					<li class="sidebar-header">
					Menu
					</li>
					
					
					<!--li class="sidebar-item  <?php if ($active_sub_m=='add'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/orders/add">
                    <i class="align-middle" data-feather="plus"></i> <span class="align-middle">Add Order</span>
                    </a>
					</li-->
					
					<li class="sidebar-item  <?php if ($active_sub_m=='purchase-requests'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/orders/purchase-requests">
                    <i class="align-middle" data-feather="users"></i> <span class="align-middle">Purchase Requests</span>
                    </a>
					</li>
					

					<li class="sidebar-item  <?php if ($active_sub_m=='boqs'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/orders/boqs">
                    <i class="align-middle" data-feather="file"></i> <span class="align-middle">Boqs</span>
                    </a>
					</li>
					
					<li class="sidebar-item  <?php if ($active_sub_m=='quotations'){echo 'active';}?>">
				  	<a class="sidebar-link" href="<?php echo get_site_url(); ?>/orders/quotations">
                    <i class="align-middle" data-feather="inbox"></i> <span class="align-middle">Quotations</span>
                    </a>
					</li>
					

					
				



                    <?php }     ?>

					
					<?php if ($active_page=='accounting'){ ?>
					<li class="sidebar-header">
					Menu 
					</li>
					
					
					<li class="sidebar-item  <?php if ($active_sub_m=='saleries'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/accounting/saleries">
					
                    <i class="align-middle" data-feather="briefcase"></i> <span class="align-middle">Saleries</span><!--remove this when developed-->
                    </a>
					</li>
					
					
				
					<li class="sidebar-item  <?php if ($active_sub_m=='credits'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/accounting/credits">
                    <i class="align-middle" data-feather="credit-card"></i> <span class="align-middle">Credits</span><!--remove this when developed-->
                    </a>
					</li>


					<li class="sidebar-item  <?php if ($active_sub_m=='stock_requests'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/accounting/stock_requests">
                    <i class="align-middle" data-feather="box"></i> <span class="align-middle">Stock Requests</span><!--remove this when developed-->
                    </a>
					</li>
					
					

					<li class="sidebar-item  <?php if ($active_sub_m=='buy_material'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/accounting/buy_material">
                    <i class="align-middle" data-feather="package"></i> <span class="align-middle">Buy Material</span><!--remove this when developed-->
                    </a>
					</li>
                        
                          <li class="sidebar-item  <?php if ($active_sub_m=='sale'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/accounting/sale">
                    <i class="align-middle" data-feather="dollar-sign"></i> <span class="align-middle">Sales</span>
                    </a>
					</li>
                        
					<li class="sidebar-item  <?php if ($active_sub_m=='account-receiveble'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/accounting/account-receiveble">
                    <i class="align-middle" data-feather="arrow-down-right"></i> <span class="align-middle">Account Receiveble</span>
                    </a>
					</li>

                        
                        
                              
					<li class="sidebar-item  <?php if ($active_sub_m=='cashbook'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/accounting/cashbook">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">Cash Book</span>
                    </a>
					</li>
                        
                        
                              
					<li class="sidebar-item  <?php if ($active_sub_m=='chequebook'){echo 'active';}?>">
					<a class="sidebar-link" href="<?php echo get_site_url(); ?>/accounting/chequebook">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">Cheque Book</span>
                    </a>
					</li>
                        
                      

					
			



                    <?php } ?>
				

				</ul>