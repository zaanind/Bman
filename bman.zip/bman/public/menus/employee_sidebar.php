<ul class="sidebar-nav">
        <li class="sidebar-header">
            System
        </li>

        <li class="sidebar-item <?php if ($active_page=='hr'){echo 'active';}?>">
            <a class="sidebar-link" href="<?php echo get_site_url(); ?>/hr">
                <i class="align-middle" data-feather="users"></i> <span class="align-middle">HR</span>
            </a>
        </li>

        <li class="sidebar-item <?php if ($active_page=='projects'){echo 'active';}?>">
            <a class="sidebar-link" href="<?php echo get_site_url(); ?>/projects">
                <i class="align-middle" data-feather="list"></i> <span class="align-middle">Projects</span>
            </a>
        </li>

        <li class="sidebar-item <?php if ($active_page=='prs'){echo 'active';}?>">
            <a class="sidebar-link" href="<?php echo get_site_url(); ?>/prs/add">
                <i class="align-middle" data-feather="package"></i> <span class="align-middle">Request Material</span>
            </a>
        </li>

        <?php if ($active_page=='hr') { ?>
        <li class="sidebar-header">
            Menu
        </li>

        <li class="sidebar-item <?php if ($active_sub_m=='my-attendance'){echo 'active';}?>">
            <a class="sidebar-link" href="<?php echo get_site_url(); ?>/hr/my-attendance">
                <i class="align-middle" data-feather="clock"></i> <span class="align-middle">My Attendance</span>
            </a>
        </li>

        <?php } ?>

    </ul>