<?php
session_start();
include_once('bcore.php');
// 1. Access Control
$homeurl       = get_site_url();
$wpuser_ob     = wp_get_current_user();
$allowed_roles = array('administrator','salesman');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Validate and fetch the order
global $wpdb;
$table_name = $wpdb->prefix . 'pos_system_orders';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = 'Invalid order ID.';
    wp_redirect($homeurl . '/orders/');
    exit;
}

$order_id = (int) $_GET['id'];

// Fetch the existing order
$order = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_name} WHERE order_id = %d",
    $order_id
));
if (!$order) {
    $_SESSION['error'] = 'Order not found.';
    wp_redirect($homeurl . '/orders/');
    exit;
}




// 3. Handle POST (Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
       
    $terms =  $_POST['terms'];
    $notes =  $_POST['notes'];

 

    // Global sums
    $global_subtotal     = floatval($_POST['global_subtotal']);
    $global_total        = floatval($_POST['global_total']);
    $global_discount     = floatval($_POST['global_discount']);
    $global_grand_total  = floatval($_POST['global_grand_total']);
    $global_global_tax   = floatval($_POST['global_global_tax']);
    $global_paid_amount  = floatval($_POST['global_paid_amount']);
    $global_due_amount   = floatval($_POST['global_due_amount']);

    // Payment info
    $payment_type   = sanitize_text_field($_POST['payment_type']);
    $payment_states = sanitize_text_field($_POST['payment_states']);
    $payment_place  = sanitize_text_field($_POST['payment_place']);

  
     $n_payment  = sanitize_text_field($_POST['new_payment']);
    

    // E) Update the order
    $update_data = [
        'order_id'        =>  $order_id,
        'g_subtotal'       => $global_subtotal,
        'g_total_amount'   => $global_total,
        'g_grand_total'    => $global_grand_total,
        'g_tax'            => $global_global_tax,
        'g_paid'           => $global_paid_amount,
        'g_due'            => $global_due_amount,
        'g_discount'       => $global_discount,
        'payment_method'   => $payment_type,
        'payment_states'   => $payment_states,
        'payment_location' => $payment_place,

    ];

 
    $updated = save_order_data($update_data);
    
    $rec_data = [
        'customer_id' => $order->customer_id,
        'order_id' => $order_id,
        'items' => $order->items,
        'g_subtotal'=> $global_subtotal,
        'g_total_amount' => $global_total,
        'g_discount' => $global_discount, 
        'g_grand_total' => $global_grand_total,
        'g_tax' => $global_global_tax,
        'g_paid' => $global_paid_amount,
        'g_due'=> $global_due_amount, 
        'payment_method' => $payment_type,
        'payment_states' => $payment_states,
        'payment_location' => $payment_place,
        'n_payment' => $n_payment,
        'notes' => $notes,
        'terms' => $terms,
    
    
    ];
    
     save_receipt_data($rec_data);
    
    
         $ar_data = array(
         'id' => $order->ar_id,
          'paid' =>  $global_paid_amount,
          'due' =>  $global_due_amount,
          'amount' =>  $global_grand_total,
          );
    
        $ar_res  = save_ar_data($ar_data);

    
    
    //$updated = $wpdb->update($table_name, $update_data, ['order_id' => $order_id]);
    if ($updated === false) {
        $_SESSION['error'] = 'Failed to update order.';
        wp_redirect($homeurl . '/orders/edit?id=' . $order_id);
        exit;
    }

    wp_redirect($homeurl . '/orders/');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // Standard WP plugin includes
    $active_page  = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Mark Payments</title>
    
    <!-- You can reuse the same CSS as in your Add page -->
    <style>
        .customer_suggestions {
            border: 1px solid #ccc;
            max-height: 150px;
            overflow-y: auto;
            position: absolute;
            background: white;
            width: 100%;
            z-index: 1000;
            display:none;
        }
        .suggestion-item, .suggestion-item_table {
            cursor: pointer;
            padding: 8px;
        }
        .suggestion-item:hover, .suggestion-item_table:hover {
            background: #f0f0f0;
        }
        /* DataTables override if needed */
        .dataTables_wrapper .dataTables_filter, 
        .dataTables_wrapper .dataTables_length, 
        .dataTables_wrapper .dataTables_info, 
        .dataTables_wrapper .dataTables_paginate {
            display: none !important; /* Hiding since you said no paging, searching, etc. */
        }
    </style>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            // Display error messages if any
            if (isset($_SESSION['error'])) {
                $err = $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Error:</strong> <?php echo esc_html($err); ?>
                    </div>
                </div>
            <?php } ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Mark Payment</h1>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <form method="POST" 
                                      action="<?php echo esc_url($homeurl . '/order/paynow?id=' . $order->order_id); ?>"
                                      enctype="multipart/form-data">
                
                
              <div class="mb-3">
                     <label class="form-label"> Terms:</label>
             <textarea class="form-control" name='terms'></textarea>
                                    </div>
                         
                         
                               <div class="mb-3">
                     <label class="form-label"> Additional Notes:</label>
             <textarea class="form-control" name='notes'></textarea>
                                    </div>


                                        <div class="col-md-3">
                                            <label class="form-label">New Payment Amout:</label >
                                            <input type="number" class="form-control"  name="new_payment" step="any" max="<?php echo esc_attr($order->g_due); ?>">
                                        </div>
                                                
                                                

                                    <!-- Totals Section -->
                                    <div class="row g-4" style="margin-top:8px;">
                                        <div class="col-md-3">
                                            <label class="form-label">Subtotal:</label>
                                            <input type="number" class="form-control"  name="global_subtotal" required step="any"
                                                   value="<?php echo esc_attr($order->g_subtotal); ?>" readonly>
                                        </div>

                                        <div class="col-md-3">
                                            <label class="form-label">Total:</label>
                                            <input type="number" class="form-control" 
                                                   name="global_total" required step="any"
                                                   value="<?php echo esc_attr($order->g_total_amount); ?>" readonly>
                                        </div>

                                        <div class="col-md-3">
                                            <label class="form-label">Discount:</label>
                                            <input type="number" class="form-control"
                                                   name="global_discount" step="any"
                                                   value="<?php echo esc_attr($order->g_discount); ?>" readonly>
                                        </div>

                                        <div class="col-md-3">
                                            <label class="form-label">Grand Total:</label>
                                            <input type="number" class="form-control" 
                                                   name="global_grand_total" required step="any"
                                                   value="<?php echo esc_attr($order->g_grand_total); ?>" readonly>
                                        </div>

                                        <div class="col-md-4">
                                            <label class="form-label">Tax (%):</label>
                                            <input type="number" class="form-control"
                                                   name="global_global_tax" step="any"
                                                   value="<?php echo esc_attr($order->g_tax); ?>" readonly>
                                        </div>

                                        <div class="col-md-4">
                                            <label class="form-label">Paid Amount:</label>
                                            <input type="number" class="form-control"
                                                   name="global_paid_amount" step="any"
                                                   value="<?php echo esc_attr($order->g_paid); ?>" readonly>
                                        </div>

                                        <div class="col-md-4">
                                            <label class="form-label">Due Amount:</label>
                                            <input type="number" class="form-control"
                                                   name="global_due_amount" required step="any"
                                                   value="<?php echo esc_attr($order->g_due); ?>" readonly>
                                        </div>
                                    </div>

                                    <!-- Payment Info -->
                                    <div class="mb-3" style="margin-top:30px;">
                                        <label class="form-label">Payment Type:</label>
                                        <select class="form-control" name="payment_type" required>
                                            <?php
                                            $types = ['Select','Cash','Check','Credit','Estimate/Quote','Trade'];
                                            foreach ($types as $t) {
                                                $sel = ($order->payment_method === $t) ? 'selected' : '';
                                                echo "<option $sel>$t</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Payment States:</label>
                                        <select class="form-control" name="payment_states" required>
                                            <?php
                                            $statesArr = ['Select','Full Payment','Advance Payment','No Payment'];
                                            foreach ($statesArr as $ps) {
                                                $sel = ($order->payment_states === $ps) ? 'selected' : '';
                                                echo "<option $sel>$ps</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Payment Place:</label>
                                        <select class="form-control" name="payment_place" required>
                                            <?php
                                            $places = ['Select','Local','Out Of State'];
                                            foreach ($places as $pp) {
                                                $sel = ($order->payment_location === $pp) ? 'selected' : '';
                                                echo "<option $sel>$pp</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <button class="btn btn-outline-primary float-end" type="submit">
                                        Update Order
                                    </button>
                                </form>
                            </div><!-- card-body -->
                        </div><!-- card -->
                    </div><!-- col-12 -->
                </div><!-- row -->
            </div><!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<!-- Full jQuery + DataTables logic (mirroring your Add page) -->
<script>

                                                
jQuery(document).ready(function($) {
    let subtotal = parseFloat($('input[name="global_subtotal"]').val());
    let paidAmount = parseFloat($('input[name="global_paid_amount"]').val());

    // Function to recalc totals
    function updateTotals() {
        
		
		let New_payment = parseFloat($('input[name="new_payment"]').val());
		
		
        let globalDiscount = parseFloat($('input[name="global_discount"]').val());
        let tax = parseFloat($('input[name="global_global_tax"]').val());

        // Update paid amount with new payment
       // paidAmount = paidAmount + New_payment;
		//console.log(paidAmount)

        // Recalculate total after discount
        let total = subtotal;
        if (globalDiscount > 0) {
            total = total - (total * (globalDiscount / 100));  // Apply discount
        }

        // Calculate grand total (including tax)
        let taxRate = tax / 100; 
        let addedTax = total * taxRate;
        let grandTotal = total + addedTax;
		let caldue =  paidAmount + New_payment;
        let dueAmount = grandTotal - caldue;

        // Update fields
        $('input[name="global_subtotal"]').val(subtotal);
        $('input[name="global_total"]').val(total.toFixed(2)); // Show as two decimal places
        $('input[name="global_grand_total"]').val(grandTotal.toFixed(2)); // Show as two decimal places
        $('input[name="global_due_amount"]').val(dueAmount.toFixed(2)); // Show as two decimal places
        $('input[name="global_paid_amount"]').val(paidAmount + New_payment); // Show as two decimal places
    }

    // Recalculate overall totals on discount/tax/paid changes
    $('input[name="global_discount"], input[name="global_global_tax"], input[name="global_paid_amount"], input[name="new_payment"]')
        .on('input', function() {
            updateTotals();
        });
});

                                                
                                                
</script>
</body>
</html>