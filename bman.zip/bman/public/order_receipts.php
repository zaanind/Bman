<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    // Include your theme or plugin header
    $active_page = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php'); 

    // Check for `order_id` in the URL
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo "<h1>Order ID Not Found</h1>";
        exit;
    } else {
        $order_id = intval($_GET['id']);
    }
    ?>
    <title>Receipts | <?php echo get_bloginfo('name'); ?></title>
</head>

<body>
    <div class="wrapper">
        <?php include_once('sidebar.php'); ?>
        <div class="main">
            <?php include_once('navbar.php'); ?>
            <main class="content">
                <div class="container-fluid p-0">

                    <div class="mb-3">
                        <h1 class="h3 d-inline align-middle">Receipts for Order ID: <?php echo $order_id; ?></h1>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <?php
                                    global $wpdb;
                                    
                                    // Fetch all receipts for this order
                                    $receipts = $wpdb->get_results("
                                        SELECT * 
                                        FROM wp_zn_system_receipts 
                                        WHERE order_id = {$order_id}
                                    ");

                                    if (!$receipts) {
                                        echo "<h2>No receipts found for Order ID: {$order_id}</h2>";
                                    } else {
                                        echo "<table id='datatables-reponsive' class='table table-striped' style='width:100%'>";
                                        echo "<thead>
                                                <tr>
                                                    <th>R_ID</th>
                                                    <th>C_ID</th>
                                                    <th>Date</th>
                                                   
                                                    <th>Total</th>

                                                    <th>Paid</th>
                                                    <th>Action</th>
   
                                                
                                                </tr>
                                            </thead>
                                            <tbody>";
                                        
                                        foreach ($receipts as $receipt) {
                                            echo "<tr>
                                                <td>{$receipt->r_id}</td>
                                                <td>{$receipt->customer_id}</td>
                                                <td>{$receipt->payment_date}</td>
                                                <td>{$receipt->g_grand_total}</td> 
                                                <td>{$receipt->n_payment}</td>
                                                 <td><div class='btn-group'> <button type='button' class='btn btn-primary dropdown-toggle' data-bs-toggle='dropdown' aria-expanded='false'>Actions</button> 
		   <ul class='dropdown-menu'>
		     <li><a class='dropdown-item' href='" .get_site_url() ."/orders/pdf_receipt?id=". $receipt->r_id."'>PDF Receipt</a></li> </td>

		   </ul></div>
		
                               
                                        
                                            </tr>";
                                        }
                                        
                                        echo "</tbody></table>";
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <?php include_once('footer.php'); ?>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Initialize DataTables
            $("#datatables-reponsive").DataTable({
                responsive: true
            });
        });
    </script>
</body>
</html>