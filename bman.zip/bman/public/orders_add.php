<?php 
session_start();
require_once('bcore.php');
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator', 'salesman');

include_once('barcode_lib.php');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

function make_user($name, $email, $phone_number, $customer_address) {
    global $wpdb;
    $table_name_customer = $wpdb->prefix . 'pos_system_customers';
    $data = array(
        'name' => $name,
        'email' => $email,
        'phone_number' => $phone_number,
        'address' => $customer_address,
    );
    $wpdb->insert($table_name_customer, $data);
}

// Function to generate a barcode, upload it to the Media Library, and return the attachment ID
function generate_and_upload_barcode($order_id) {
    $upload_dir = wp_upload_dir();
    $barcode_filename = "ORDR_" . $order_id . ".png";
    $barcode_path = $upload_dir['path'] . '/' . $barcode_filename;

    // Generate Barcode
    barcode($barcode_path, "ORDR_" . $order_id, 100, "horizontal", "code128", false, 3);

    if (!file_exists($barcode_path)) {
        return new WP_Error('barcode_generation_failed', 'Failed to generate barcode.');
    }

    // Upload to Media Library
    $filetype = wp_check_filetype($barcode_filename, null);
    $attachment = array(
        'guid'           => $upload_dir['url'] . '/' . $barcode_filename,
        'post_mime_type' => $filetype['type'],
        'post_title'     => "Barcode for Order " . $order_id,
        'post_content'   => '',
        'post_status'    => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $barcode_path);

    if (is_wp_error($attach_id)) {
        return $attach_id;
    }

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $barcode_path);
    wp_update_attachment_metadata($attach_id, $attach_data);

    return $attach_id;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pos_system_orders';

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone'];
    $customer_address = $_POST['customer_address'];
    $customer_shipping_address = $_POST['customer_shiping_address'];
    $notes = $_POST['notes'];
    $terms = $_POST['terms'];

    $product_titles = $_POST['item'];
    $items = $_POST['id'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $discount = $_POST['discount'];
    $total = $_POST['total'];

    $items_data = [];

    for ($i = 0; $i < count($items); $i++) {
        $items_data[] = [
            'title' => $product_titles[$i],
            'id' => $items[$i],
            'quantity' => $quantity[$i],
            'price' => $price[$i],
            'discount' => $discount[$i],
            'total' => $total[$i]
        ];
        $resp = $wpdb->get_results("SELECT quantity FROM wp_pos_system_inventory_products WHERE product_id=" . $items[$i] . ";");
        $db_quantity = (int) $resp[0]->quantity;
        $real_quantity = $db_quantity - $quantity[$i];
        $wpdb->query("UPDATE wp_pos_system_inventory_products SET quantity= '" . $real_quantity . "' WHERE product_id=" . $items[$i] . ";");
    }

    $items_data_json = json_encode($items_data);

    $global_subtotal = $_POST['global_subtotal'];
    $global_total = $_POST['global_total'];
    $global_discount = $_POST['global_discount'];
    $global_grand_total = $_POST['global_grand_total'];
    $global_global_tax = $_POST['global_global_tax'];
    $global_paid_amount = $_POST['global_paid_amount'];
    $global_due_amount = $_POST['global_due_amount'];

    $payment_type = $_POST['payment_type'];
    $payment_states = $_POST['payment_states'];
    $payment_place = $_POST['payment_place'];

    $sql = $wpdb->prepare("SELECT customer_id FROM wp_pos_system_customers WHERE email='%s'", $email);
    $result = $wpdb->get_results($sql);

    if (empty($result[0]->customer_id)) {
        make_user($name, $email, $phone_number, $customer_address);
    }

    $result = $wpdb->get_results("SELECT customer_id FROM wp_pos_system_customers WHERE email='" . esc_sql($email) . "'");
    $customer_id = $result[0]->customer_id;
    
    $ar_data = array(
        'type' => 'Invoice',
        'payee' => $email,
        'due' => $global_due_amount,
        'amount' => $global_grand_total,
        'paid' => $global_paid_amount,
    );
    
  //  $ar_res  = save_ar_data($ar_data);

    $data = array(
        'customer_id' => $customer_id,
        'order_status' => 'ongoing',
        'notes' => $notes,
        'items' => $items_data_json,
        'g_subtotal' => $global_subtotal,
        'g_total_amount' => $global_total,
        'g_grand_total' => $global_grand_total,
        'g_tax' => $global_global_tax,
        'g_paid' => $global_paid_amount,
        'g_due' => $global_due_amount,
        'g_discount' => $global_discount,
        'shipping_address' => $customer_shipping_address,
        'billing_address' => $customer_address,
        'payment_method' => $payment_type,
        'payment_states' => $payment_states,
        'payment_location' => $payment_place,
        'terms' =>  $terms, 
       // 'ar_id' => $ar_res,
    );

    $inserted = $wpdb->insert($table_name, $data);

    if ($inserted === false) {
        $_SESSION['error'] = 'Failed';
        header('Location: ' . $homeurl . '/orders/add/');
        exit;
    }

    // Get the newly inserted order ID
    $order_id = $wpdb->insert_id;

    // Generate and upload the barcode
    $barcode_attachment_id = generate_and_upload_barcode($order_id);





    if (!empty($barcode_attachment_id)) {
        // Update the order with the barcode attachment ID
        $wpdb->update($table_name, ['barcode' => $barcode_attachment_id], ['order_id' => $order_id]);
    }

    header('Location: ' . $homeurl . '/orders/');
    exit;
}
?>











<?php

/*
session_start();

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator','salesman');

include_once('barcode_lib.php');


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}







 
 function make_user($name,$email,$phone_number, $customer_address){
	global $wpdb;
	$table_name_customer = $wpdb->prefix . 'pos_system_customers';
    $data = array(
        'name' => $name,
		'email' => $email,
		'phone_number' => $phone_number,
		'address' => $customer_address,
      );
     $wpdb->insert($table_name_customer, $data);
	 
	 
 } 
 
 
 
   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	  global $wpdb;
	   $table_name = $wpdb->prefix . 'pos_system_orders';
        
      $homeurl = get_site_url();

      $name = $_POST['name'];
	  $email =  $_POST['email'];
	  
	  $phone_number = $_POST['phone'];
	
	  $customer_address = $_POST['customer_address'];
	  $customer_shiping_address = $_POST['customer_shiping_address'];
	  $notes = $_POST['notes'];
	 // $orderdate = $_POST['orderdate'];
	  
	  
	  //table raw data
	 // $items = $_POST['item'];
	  //$json_items = json_encode($items); 
      $product_titles = $_POST['item'];
	  $items = $_POST['id'];
	  $quantity = $_POST['quantity'];
	  $price = $_POST['price'];	  
	  $discount = $_POST['discount'];
	  $total = $_POST['total'];


    $items_data = [];

   for ($i = 0; $i < count($items); $i++) {
      $items_data[] = [
          'title' => $product_titles[$i],
          'id' => $items[$i],
          'quantity' => $quantity[$i],
          'price' => $price[$i],
          'discount' => $discount[$i],
          'total' => $total[$i]
      ];
	  $resp =  $wpdb->get_results("SELECT quantity FROM wp_pos_system_inventory_products WHERE product_id=".$items[$i].";");
	  $db_quantity = (int) $resp[0]->quantity;
	  $real_quantity = $db_quantity - $quantity[$i];
	  $wpdb->get_results("UPDATE wp_pos_system_inventory_products SET quantity= '".$real_quantity."' WHERE product_id=".$items[$i].";");
    }

    $items_data_json = json_encode($items_data);
	  

 //global s     
    $global_subtotal = $_POST['global_subtotal'];
    $global_total = $_POST['global_total'];
    $global_discount = $_POST['global_discount'];
    $global_grand_total = $_POST['global_grand_total'];
    $global_global_tax = $_POST['global_global_tax'];
    $global_paid_amount = $_POST['global_paid_amount'];
    $global_due_amount = $_POST['global_due_amount'];
	
//others

    $payment_type = $_POST['payment_type'];
    $payment_states = $_POST['payment_states'];
    $payment_place = $_POST['payment_place'];


    $sql = $wpdb->prepare("SELECT customer_id FROM wp_pos_system_customers WHERE email='".$email."'");

    $result = $wpdb->get_results($sql);
	
	if (empty($result[0]->customer_id)) {  
	make_user($name,$email,$phone_number,$customer_address);
	}
	 
	
	$result = $wpdb->get_results("SELECT customer_id FROM wp_pos_system_customers WHERE email='".$email."'");

	$customer_id = $result[0]->customer_id;
	
	
    $data = array(
        'customer_id' => $customer_id,
	    'order_status' => 'ongoing',
	    'notes' => $notes,
	    'items' => $items_data_json, //ids of items
	    'g_subtotal' => $global_subtotal,
	    'g_total_amount' => $global_total,
	    'g_grand_total' => $global_grand_total,
	    'g_tax' => $global_global_tax,
	    'g_paid' => $global_paid_amount,
	    'g_due' => $global_due_amount,
	    'g_discount' => $global_discount,
	    'shipping_address' => $customer_shiping_address,
	    'billing_address' => $customer_address,
	    'payment_method' => $payment_type,
	    'payment_states' => $payment_states,
	    'payment_location' => $payment_place,
      );


    // For demonstration purposes, get pararameters that are passed in through $_GET or set to the default value
        $filepath = (isset($_GET["filepath"])?$_GET["filepath"]:"");
        $text = (isset($_GET["text"])?$_GET["text"]:"0");
        $size = (isset($_GET["size"])?$_GET["size"]:"20");
        $orientation = (isset($_GET["orientation"])?$_GET["orientation"]:"horizontal");
        $code_type = (isset($_GET["codetype"])?$_GET["codetype"]:"code128");
        $print = (isset($_GET["print"])&&$_GET["print"]=='true'?true:false);
        $sizefactor = (isset($_GET["sizefactor"])?$_GET["sizefactor"]:"1");
        
        // This function call can be copied into your project and can be made from anywhere in your code
        //barcode( $filepath, $text, $size, $orientation, $code_type, $print, $sizefactor );
        
	
	
    $inserted = $wpdb->insert($table_name, $data);

	  
        if ($inserted === false) {
		  $_SESSION['error'] = 'Failed';
		  header('location:'.$homeurl.'/orders/add/');
		  exit;
      

	  }


    
	header('location:'.$homeurl.'/orders/');
}
		
*/

?>

<!DOCTYPE html>
<html lang="en">
<head>
   
   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
   
   


	<title>Add Invoice | <?php echo get_bloginfo( 'name' ); ?></title>

    <style>
        .suggestions  {
            border: 1px solid #ccc;
            max-height: 150px;
            overflow-y: auto;
            position: absolute;
            background: white;
            width: 100%;
            z-index: 1000;
            
        }
        .suggestion-item .suggestion_item_css {
            padding: 8px;
            cursor: pointer;
        }
        .suggestion-item:hover .suggestion_item_css:hover{
            background: #f0f0f0;
        }
    </style>
</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



			<main class="content">
			<?php
                   if (isset($_SESSION['error'])) {
                         $err = $_SESSION['error'];
                         unset($_SESSION['error']);?>
						 
						 			<div class="alert alert-danger alert-dismissible" role="alert">
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											<div class="alert-message">
												<strong>Error:</strong> Failed to add item
											</div>
										</div>

						<?php }	?>
								
								
					
										
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Add New Invoice</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
						
								<div class="card-body">
								       
                                      <form method="POST" action="<?php echo get_site_url(); ?>/orders/add/" enctype="multipart/form-data" onsubmit="return validateForm()">
                                    
									
									
					
									
									
									<div style="display:flex;justify-content: flex-start;">
    									<div class="mb-3 col-lg-6" style="margin-right:20px;">
                                            <label  class="form-label">Customer:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customerName"  name="name" required>
											<div class="customer_suggestions" id="customerName_suggestions"></div>
                                        </div>
										
										<div class="mb-3 col-lg-5">
                                            <label  class="form-label">Contact No:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customerphone"  name="phone" required>
											<div class="customer_suggestions" id="customerphone_suggestions"></div>
                                        </div> </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Email:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customeremail"  name="email" required>
											<div class="customer_suggestions" id="customeremail_suggestions"></div>
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Address:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customer_address"  name="customer_address" required>
		
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Shipping Address:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customer_shiping_address"  name="customer_shiping_address" required>
											
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Notes:</label>
                                            <textarea type="text" class="form-control"  name="notes"></textarea>
                                        </div>
                                                
                                                
                                                       <div class="mb-3">
                                        <label class="form-label">Terms:</label>
                                        <textarea class="form-control" name="terms"></textarea>
                                    </div>
                                            
                                            
										
										
										<div class="mb-3">
										<?php   
										global $wpdb;
										$resp =  $wpdb->get_results("SELECT CURRENT_TIMESTAMP");
										    
										
										?>
                                            <label  class="form-label">Order Date:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" value="<?php echo $resp[0]->CURRENT_TIMESTAMP;  ?>"  name="orderdate" required readonly>
											
                                        </div>
										
										
										 <!-- Product Table -->
        <div class="table-responsive">
            <table id="productTable" class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Item</th> 
						<th>Available</th>
                        <th>Quantity</th>
						 <th>Price</th>
                        <th>Discount (%)</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
		

        <button type="button" class="btn btn-success " style="margin-top:5px;" id="addRow">Add Item Row</button>
										
							<div  id="outer_totals">			
							<div class="row g-4"  style="margin-top:8px;">
    <div class="col-md-3">
        <label class="form-label">Subtotal:</label>
        <input type="number" step="any" autocomplete="off" class="form-control" name="global_subtotal" required>
    </div>

    <div class="col-md-3">
        <label class="form-label">Total:</label>
        <input type="number" step="any" autocomplete="off" class="form-control" name="global_total" required>
    </div>

    <div class="col-md-3">
        <label class="form-label">Discount:</label>
        <input type="number" step="any" autocomplete="off" class="form-control" name="global_discount">
    </div>

    <div class="col-md-3">
        <label class="form-label">Grand Total:</label>
        <input type="number" step="any" autocomplete="off" class="form-control" name="global_grand_total" required>
    </div>

    <div class="col-md-4">
        <label class="form-label">Tax(%):</label>
        <input type="number" step="any" autocomplete="off" class="form-control" name="global_global_tax">
    </div>

    <div class="col-md-4">
        <label class="form-label">Paid Amount:</label>
        <input type="number" step="any" autocomplete="off" class="form-control" name="global_paid_amount" readonly value='0'>
    </div>

    <div class="col-md-4">
        <label class="form-label">Due Amount:</label>
        <input type="number" step="any" autocomplete="off" class="form-control" name="global_due_amount" required>
    </div>
</div></div>

										
									
                                        
									

										
										
										<button  style="margin-top:30px;" class="btn btn-outline-primary float-end"> Submit</button>
										</form>
							
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>


			
			
			
			
			<?php include_once('footer.php');?>
		</div>
	</div>

	
<script>


//name
$(document).ready(function() {
    $("#customerName").keyup(function() {
        let query = $(this).val();
        let fieldId = $(this).attr("id");
        let suggestionBox = "#" + fieldId + "_suggestions";

        if (query.length > 3) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_name: query },
                success: function(data) {
                    console.log("API Response:", data); // Debugging
                    let suggestions = "";

                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item' 
                                            data-name='${customer.name || ""}'
                                            data-phone='${customer.contact_number || ""}'
                                            data-email='${customer.email || ""}'
                                            data-address='${customer.address || ""}'>
                                            ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    // Click event for selecting suggestion
    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
		let selected_address = $(this).data("address");

		
		
		$("#customer_shiping_address").val(selected_address);
		$("#customer_address").val(selected_address);
		

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerName, #customerName_suggestions").length) {
            $("#customerName_suggestions").hide();
        }
    });
});





//phone
$(document).ready(function() {
    $("#customerphone").keyup(function() {
        let query = $(this).val();
        let fieldId = $(this).attr("id");
        let suggestionBox = "#" + fieldId + "_suggestions";

        if (query.length > 5) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_phone: query },
                success: function(data) {
                    console.log("API Response:", data); // Debugging
                    let suggestions = "";

                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item' 
                                            data-name='${customer.name || ""}'
                                            data-phone='${customer.contact_number || ""}'
                                            data-email='${customer.email || ""}'
                                            data-address='${customer.address || ""}'>
                                            ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    // Click event for selecting suggestion
    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
		
		let selected_address = $(this).data("address");

		
		
		$("#customer_shiping_address").val(selected_address);
		$("#customer_address").val(selected_address);

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerphone, #customerphone_suggestions").length) {
            $("#customerphone_suggestions").hide();
        }
    });
});


//email
$(document).ready(function() {
    $("#customeremail").keyup(function() {
        let query = $(this).val();
        let fieldId = $(this).attr("id");
        let suggestionBox = "#" + fieldId + "_suggestions";

        if (query.length > 4) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_email: query },
                success: function(data) {
                    console.log("API Response:", data); // Debugging
                    let suggestions = "";

                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item' 
                                            data-name='${customer.name || ""}'
                                            data-phone='${customer.contact_number || ""}'
                                            data-email='${customer.email || ""}'
                                            data-address='${customer.address || ""}'>
                                            ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    // Click event for selecting suggestion
    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
		let selected_address = $(this).data("address");

		
		
		$("#customer_shiping_address").val(selected_address);
		$("#customer_address").val(selected_address);

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerphone, #customeremail_suggestions").length) {
            $("#customeremail_suggestions").hide();
        }
    });
});


//Table Table  Table  Table  Table  Table  Table  Table  Table  Table

$(document).ready(function() {
    var table = $('#productTable').DataTable({
        "paging": false,
        "searching": false,
        "info": false,
    });
	
	
	function updateTotals() {
        let subtotal = 0;
        
        // Loop through each row and sum up totals
        $('#productTable tbody tr').each(function() {
            let rowTotal = parseFloat($(this).find('.total').val()) || 0;
            subtotal += rowTotal;
        });

        let globalDiscount = parseFloat($('input[name="global_discount"]').val()) || 0;
        let tax = parseFloat($('input[name="global_global_tax"]').val()) || 0;
        let paidAmount = parseFloat($('input[name="global_paid_amount"]').val()) || 0;

        // Calculate total after discount
        let total = subtotal;
        if (globalDiscount > 0) {
            total -= total * (globalDiscount / 100);
        }

        // Calculate grand total (including tax)
		
		let taxRate = tax / 100; // Convert percentage to decimal
		let added_tax = total * taxRate; // Calculate tax amount
		
		
        let grandTotal = total + added_tax;
		//if ($('input[name="global_paid_amount"]').val() !=== grandTotal) {   
		//  let paidAmount = grandTotal
      //    $('input[name="global_paid_amount"]').val(grandTotal);		
      //   }     
	
        let dueAmount = grandTotal - paidAmount;

        // Update input fields
        $('input[name="global_subtotal"]').val(subtotal.toFixed(2));
        $('input[name="global_total"]').val(total.toFixed(2));
        $('input[name="global_grand_total"]').val(grandTotal.toFixed(2));
        $('input[name="global_due_amount"]').val(dueAmount.toFixed(2));
    }


    // Function to add a new row
    $('#addRow').on('click', function() {
        table.row.add([
            '<input type="text" class="form-control productinput" name="item[]"><input type="text" class="id_holder" name="id[]" hidden><div class="product_suggestions" ></div>',
            '<input type="number" class="form-control avalible" min="0" value="0" readonlypk >',
            '<input type="number" class="form-control quantity" name="quantity[]" min="0" value="0" >',
            '<input type="number" class="form-control price" readonlypk name="price[]" min="0">',
            '<input type="number" class="form-control discount" readonlypk name="discount[]" min="0" max="100">',
            '<input type="text" class="form-control total" name="total[]" readonly >',
            '<button type="button" class="btn btn-danger btn-sm removeRow">Remove</button>'
        ]).draw(false);
    });

    // Event delegation for removing a row
    $('#productTable tbody').on('click', '.removeRow', function() {
        table.row($(this).parents('tr')).remove().draw();
    });

    // Function to fetch product suggestions
    $('#productTable tbody').on('keyup', '.productinput', function() {
        let inputField = $(this);
        let query = inputField.val();
        let suggestionBox = inputField.siblings('.product_suggestions');

        if (query.length < 2) {
            suggestionBox.html('').hide();
            return;
        }

        $.ajax({
            url: "<?php echo get_site_url(); ?>/api/customers_api",
            method: "POST",
            data: { search_product_query_name: query },
            success: function(data) {
                suggestionBox.html('');
                if (Array.isArray(data) && data.length > 0) {
                    let suggestions = data.map(product => 
                        `<div class='suggestion-item_table suggestion_item_css' 
                             data-pid='${product.id}'
							 data-name='${product.name}' 
                             data-price='${product.price}' 
                             data-stock='${product.stock}'
							 data-discount='${product.discount}'>
                             ${product.name} - $${product.price} 
                         </div>`
                    ).join('');
                    suggestionBox.html(suggestions).show();
                } else {
                    suggestionBox.html('<div class="no-results">No results found</div>').show();
                }
            }
        });
    });

    // Selecting a product from suggestions
    $('#productTable tbody').on('click', '.suggestion-item_table', function() {
        let selectedProduct = $(this);
        let row = selectedProduct.closest('tr');
		
		
        let stock = selectedProduct.data('stock');
        row.find('.productinput').val(selectedProduct.data('name'));
        row.find('.price').val(selectedProduct.data('price')).attr('readonly', true);  // Make discount readonly
        row.find('.avalible').val(selectedProduct.data('stock')).attr('readonly', true);  // Make discount readonly
		row.find('.quantity').attr('max', selectedProduct.data('stock'));  //.max(selectedProduct.data('stock'));
	
		
		row.find('.total').val(selectedProduct.data('price'));
		row.find('.discount').val(selectedProduct.data('discount')).attr('readonly', true);  // Make discount readonly
		
		row.find('.id_holder').val(selectedProduct.data('pid'));
  
        let price = parseFloat(selectedProduct.data('price')) || 0;
        let discount = parseFloat(selectedProduct.data('discount')) || 0;
        let total = price;
		


        if (discount > 0) {
           total -= total * (discount / 100);
           }


     if (stock > 0) {
    
       row.find('.total').val(total);
	   row.find('.quantity').val('1'); 
     } else {
	  
      row.find('.total').val('0');  // Clear total if stock is 0
      }
      //row.find('.total').val(total.toFixed(2));


		updateTotals();
        row.find('.product_suggestions').hide();
    });

    // Calculate total when price, quantity, or discount changes
    $('#productTable tbody').on('input', '.price, .quantity, .discount', function() {
        let row = $(this).closest('tr');
        let price = parseFloat(row.find('.price').val()) || 0;
        let quantity = parseInt(row.find('.quantity').val()) || 1;
        let discount = parseFloat(row.find('.discount').val()) || 0;

        let total = price * quantity;
        if (discount > 0) {
            total -= total * (discount / 100);
        }

        row.find('.total').val(total.toFixed(2));
		updateTotals();
    });
	
	    // Calculate total when price, quantity, or discount changes
    $('#outer_totals').on('input', 'input[name="global_discount"], input[name="global_global_tax"], input[name="global_paid_amount"]', function() {

		updateTotals();
    });
	
	
	
});







</script>
	

</body>

</html>