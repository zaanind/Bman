<?php


$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator','salesman');


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}




 ?>


 <!DOCTYPE html>
<html lang="en">
<head>



   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title> Boqs | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



	<main class="content">
	<div class="container-fluid p-0">
	<a href="<?php echo get_site_url(); ?>/orders/boqs/add" class="btn btn-primary float-end mt-n1"><i class="fas fa-plus"></i> New Boq</a>

					<div class="mb-3">
						<h1 class="h3 d-inline align-middle">Boqs</h1>
					</div>

					<div class="row">
						<div class="col-12">
							
							<div class="card">
								
								<div class="card-body">
									<table id="datatables-reponsive" class="table table-striped" style="width:100%">
										<thead>
											<tr>
												<th>ID</th>
												<th>Title</th>
												<th>Total</th>
												<th>Customer</th>
												<th>Action</th>
											</tr>
										</thead>
										
	<?php
     global $wpdb;
    $resp = $wpdb->get_results("SELECT * FROM wp_zn_system_boq");                               


	?>
										<tbody>
										
	<?php 
										
     foreach ($resp as $row) {
		 
		   $cust_name = $wpdb->get_var("SELECT name FROM wp_pos_system_customers WHERE customer_id=".$row->customer_id);

           echo '<tr>';
   
           echo "<td>" . $row->boq_id . "</td>";
           echo "<td>" . $row->title . "</td>";
           echo "<td>" . $row->g_total_amount . "</td>";
           echo "<td>" . $cust_name . "</td>";
         



      
   echo "<td> <div class='btn-group'> <button type='button' class='btn btn-primary dropdown-toggle' data-bs-toggle='dropdown' aria-expanded='false'>Actions</button> 
		   <ul class='dropdown-menu'>
		
    <li><a class='dropdown-item' href='" .get_site_url() ."/orders/boqs/pdf?id=". $row->boq_id."'>PDF BOQ</a></li>  
		   <li><a class='dropdown-item' href='" .get_site_url() ."/orders/boqs/edit?id=". $row->boq_id."'>Edit</a></li>
		   <li><a class='dropdown-item' href='" .get_site_url() ."/orders/boqs/boq-to-quotation?id=". $row->boq_id."'>Convert To Quotation</a></li>
		   <li><a class='dropdown-item' href='" .get_site_url() ."/orders/boqs/delete?id=". $row->boq_id."'>Delete</a></li>

		   </ul></div>
		   </td>";

           echo '</tr>';
    }
																	
										
	?>
									
	</tbody></table>
	</div>
	</div>
	</div>
	</div>
    </div>
	
	
	
	</main>
	
			
			<?php include_once('footer.php');?>
		</div>
	</div>

			<script>
		document.addEventListener("DOMContentLoaded", function() {
			// Datatables Responsive
			$("#datatables-reponsive").DataTable({
				responsive: true,
                order: [[0, 'desc']]
		
			});
		});
	</script>
	
</body>

</html>