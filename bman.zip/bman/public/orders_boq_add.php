<?php 
session_start();

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator', 'salesman');

include_once('barcode_lib.php');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

function make_user($name, $email, $phone_number, $customer_address) {
    global $wpdb;
    $table_name_customer = $wpdb->prefix . 'pos_system_customers';
    $data = array(
        'name' => $name,
        'email' => $email,
        'phone_number' => $phone_number,
        'address' => $customer_address,
    );
    $wpdb->insert($table_name_customer, $data);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    global $wpdb;
    $table_name = $wpdb->prefix . 'zn_system_boq';

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone'];
    $customer_address = $_POST['customer_address'];
    $customer_shipping_address = $_POST['customer_shiping_address'];
   
    $project_title = $_POST['title'];

    // New fields for order items:
    $sr_arr         = $_POST['sr'];           // Cost sector number
    $section_arr    = $_POST['section'];
    $subsection_arr    = $_POST['subsection'];      // Cost sector title
    
    $product_titles = $_POST['item'];
    $items          = $_POST['id'];
    $unit_types     = $_POST['unit_type'];
    $units          = $_POST['unit'];
    $quantity       = $_POST['quantity'];
    $price          = $_POST['price'];
    $total          = $_POST['total'];

    $items_data = [];

    for ($i = 0; $i < count($product_titles); $i++) {
        $items_data[] = [
            'sr'         => $sr_arr[$i],
            'section'    => $section_arr[$i],
            'sub_section' => $subsection_arr,
            'item'       => $product_titles[$i],
            'product_id' => $items[$i],
            'unit_type'  => $unit_types[$i],
            'unit'       => $units[$i],
            'quantity'   => $quantity[$i],
            'price'      => $price[$i],
            'total'      => $total[$i]
        ];
        
        // Update inventory if a product id is provided
        if (!empty($items[$i]) && is_numeric($quantity[$i])) {
            $resp = $wpdb->get_results("SELECT quantity FROM wp_pos_system_inventory_products WHERE product_id=" . intval($items[$i]) . ";");
            if (!empty($resp) && isset($resp[0]->quantity)) {
                $db_quantity = (int) $resp[0]->quantity;
                $real_quantity = $db_quantity - (int)$quantity[$i];
                $wpdb->query("UPDATE wp_pos_system_inventory_products SET quantity= '" . intval($real_quantity) . "' WHERE product_id=" . intval($items[$i]) . ";");
            }
        }
    }

    $items_data_json = json_encode($items_data);

    $global_subtotal    = $_POST['global_subtotal'];
    $global_total       = $_POST['global_total'];
    $global_discount    = $_POST['global_discount'];
    $global_grand_total = $_POST['global_grand_total'];
    $global_global_tax  = $_POST['global_global_tax'];
    $global_paid_amount = $_POST['global_paid_amount'];
    $global_due_amount  = $_POST['global_due_amount'];

    $payment_type   = $_POST['payment_type'];
    $payment_states = $_POST['payment_states'];
    $payment_place  = $_POST['payment_place'];

    $sql = $wpdb->prepare("SELECT customer_id FROM wp_pos_system_customers WHERE email='%s'", $email);
    $result = $wpdb->get_results($sql);

    if (empty($result[0]->customer_id)) {
        make_user($name, $email, $phone_number, $customer_address);
    }

    $result = $wpdb->get_results("SELECT customer_id FROM wp_pos_system_customers WHERE email='" . esc_sql($email) . "'");
    $customer_id = $result[0]->customer_id;

    $data = array(
        'customer_id'    => $customer_id,
        //'order_status'  => 'ongoing',
        //'notes'         => $notes,
        'items'          => $items_data_json,
        'g_subtotal'     => $global_subtotal,
        'g_total_amount' => $global_total,
        'g_grand_total'  => $global_grand_total,
        'g_tax'          => $global_global_tax,
        'g_paid'         => $global_paid_amount,
        'g_due'          => $global_due_amount,
        'g_discount'     => $global_discount,
        'title'          => $project_title,
        'shipping_address' => $customer_shipping_address,
        'billing_address'  => $customer_address,
        //'payment_method'   => $payment_type,
        //'payment_states'   => $payment_states,
        //'payment_location' => $payment_place
    );

    $inserted = $wpdb->insert($table_name, $data);

    if ($inserted === false) {
        $_SESSION['error'] = 'Failed';
        header('Location: ' . $homeurl . '/orders/boqs/add/');
        exit;
    }

    // Get the newly inserted order ID
    $order_id = $wpdb->insert_id;

    // Generate and upload the barcode if needed
    //$barcode_attachment_id = generate_and_upload_barcode($order_id);

    if (!empty($barcode_attachment_id)) {
        // Update the order with the barcode attachment ID
        $wpdb->update($table_name, ['barcode' => $barcode_attachment_id], ['order_id' => $order_id]);
    }

    header('Location: ' . $homeurl . '/orders/boqs');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <?php
   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); 
   ?>
	<title>Add BOQ | <?php echo get_bloginfo( 'name' ); ?></title>
	<style>
/* Hide arrows in Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Hide arrows in Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
</style>

    <style>
        .suggestions  {
            border: 1px solid #ccc;
            max-height: 150px;
            overflow-y: auto;
            position: absolute;
            background: white;
            width: 100%;
            z-index: 1000;
        }
        .suggestion-item .suggestion_item_css {
            padding: 8px;
            cursor: pointer;
        }
        .suggestion-item:hover .suggestion_item_css:hover{
            background: #f0f0f0;
        }
    </style>
</head>
<body>
	<div class="wrapper">
	    <?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>
			<main class="content">
			<?php
                   if (isset($_SESSION['error'])) {
                         $err = $_SESSION['error'];
                         unset($_SESSION['error']); ?>
						 <div class="alert alert-danger alert-dismissible" role="alert">
						     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
						     <div class="alert-message">
						         <strong>Error:</strong> Failed to add item
						     </div>
						 </div>
					<?php } ?>
				<div class="container-fluid p-0">
					<h1 class="h3 mb-3">Add New BOQ</h1>
					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body">
                                      <form method="POST" action="<?php echo get_site_url(); ?>/orders/boqs/add/" enctype="multipart/form-data">
									    <div style="display:flex;justify-content: flex-start;">
    									    <div class="mb-3 col-lg-6" style="margin-right:20px;">
                                                <label class="form-label">Customer:</label>
                                                <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customerName" name="name" required>
	                                            <div class="customer_suggestions" id="customerName_suggestions"></div>
                                            </div>
												
										<div class="mb-3 col-lg-5">
                                            <label  class="form-label">Contact No:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customerphone"  name="phone" required>
											<div class="customer_suggestions" id="customerphone_suggestions"></div>
                                        </div> </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Email:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customeremail"  name="email" required>
											<div class="customer_suggestions" id="customeremail_suggestions"></div>
                                        </div>
										
										
										<div class="mb-3">
                                            <label class="form-label">Address:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customer_address" name="customer_address" required>
                                        </div>
										
										<div class="mb-3">
                                            <label class="form-label">Shipping Address:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customer_shiping_address" name="customer_shiping_address" required>
                                        </div>
										
									

                                        <div class="mb-3">
                                        <label class="form-label">Project Title:</label>
                                        <input type="text" class="form-control" name="title" required>
                                    </div>
										
										<div class="mb-3">
										<?php   
										global $wpdb;
										$resp = $wpdb->get_results("SELECT CURRENT_TIMESTAMP");
										?>
                                            <label class="form-label">Order Date:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" value="<?php echo $resp[0]->CURRENT_TIMESTAMP; ?>" name="orderdate" required readonly>
                                        </div>
										
										<!-- Product Table -->
                                        <div class="table-responsive">
                                            <table id="productTable" class="table table-bordered">
                                                <thead class="table-dark">
                                                    <tr>
                                                        <th>SR</th> 
                                                        <th>Sec</th> 
                                                        <th>SS</th> 
                                                        <th>Item</th> 
                                                        <th>Type</th> 
                                                        <th>Unit</th> 
                                                        <th>Qty</th>
                                                        <th>Rate</th>
                                                        <th>Amt</th>
                                                        <th>Act</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
		
                                        <button type="button" class="btn btn-success" style="margin-top:5px;" id="addRow">Add Item Row</button>
										
										<div id="outer_totals">			
										    <div class="row g-4" style="margin-top:8px;">
                                                <div class="col-md-3">
                                                    <label class="form-label">Subtotal:</label>
                                                    <input type="number" step="any" autocomplete="off" class="form-control" name="global_subtotal" required>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Total:</label>
                                                    <input type="number" step="any" autocomplete="off" class="form-control" name="global_total" required>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Discount:</label>
                                                    <input type="number" step="any" autocomplete="off" class="form-control" name="global_discount">
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Grand Total:</label>
                                                    <input type="number" step="any" autocomplete="off" class="form-control" name="global_grand_total" required>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Tax(%):</label>
                                                    <input type="number" step="any" autocomplete="off" class="form-control" name="global_global_tax">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Paid Amount:</label>
                                                    <input type="number" step="any" autocomplete="off" class="form-control" name="global_paid_amount">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Due Amount:</label>
                                                    <input type="number" step="any" autocomplete="off" class="form-control" name="global_due_amount" required>
                                                </div>
                                            </div>
                                        </div>
										
									<div style="display:none;">	<div class="mb-3" style="margin-top:30px;">
                                            <label class="form-label">Payment Type:</label>
                                            <select class="form-control" name="payment_type" required placeholder="Select">
											    <option>Select</option>
											    <option>Cash</option>
											    <option>Check</option>
											    <option>Credit</option>
											    <option>Estimate/Quote</option>
											    <option>Trade</option>
											</select>
										</div>
										
										<div class="mb-3">
                                            <label class="form-label">Payment States:</label>
                                            <select class="form-control" name="payment_states" required>
											    <option>Select</option>
											    <option>Full Payment</option>
											    <option>Advance Payment</option>
											    <option>No Payment</option>
											</select>
										</div>
										
										<div class="mb-3">
                                            <label class="form-label">Payment Place:</label>
											<select class="form-control" name="payment_place" required>
											    <option>Select</option>
											    <option>Local</option>
											    <option>Out Of State</option>
											</select>
                                        </div>
										
						</div>
										
										<button style="margin-top:30px;" class="btn btn-outline-primary float-end"> Submit</button>
									    </form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</main>
			
			<?php include_once('footer.php'); ?>
		</div>
	</div>

<script>
// ---------- CUSTOMER SUGGESTIONS (Name, Phone, Email) ----------
//name
$(document).ready(function() {
    $("#customerName").keyup(function() {
        let query = $(this).val();
        let fieldId = $(this).attr("id");
        let suggestionBox = "#" + fieldId + "_suggestions";

        if (query.length > 3) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_name: query },
                success: function(data) {
                    console.log("API Response:", data); // Debugging
                    let suggestions = "";

                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item' 
                                            data-name='${customer.name || ""}'
                                            data-phone='${customer.contact_number || ""}'
                                            data-email='${customer.email || ""}'
                                            data-address='${customer.address || ""}'>
                                            ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    // Click event for selecting suggestion
    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
		let selected_address = $(this).data("address");

		
		
		$("#customer_shiping_address").val(selected_address);
		$("#customer_address").val(selected_address);
		

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerName, #customerName_suggestions").length) {
            $("#customerName_suggestions").hide();
        }
    });
});





//phone
$(document).ready(function() {
    $("#customerphone").keyup(function() {
        let query = $(this).val();
        let fieldId = $(this).attr("id");
        let suggestionBox = "#" + fieldId + "_suggestions";

        if (query.length > 5) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_phone: query },
                success: function(data) {
                    console.log("API Response:", data); // Debugging
                    let suggestions = "";

                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item' 
                                            data-name='${customer.name || ""}'
                                            data-phone='${customer.contact_number || ""}'
                                            data-email='${customer.email || ""}'
                                            data-address='${customer.address || ""}'>
                                            ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    // Click event for selecting suggestion
    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
		
		let selected_address = $(this).data("address");

		
		
		$("#customer_shiping_address").val(selected_address);
		$("#customer_address").val(selected_address);

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerphone, #customerphone_suggestions").length) {
            $("#customerphone_suggestions").hide();
        }
    });
});


//email
$(document).ready(function() {
    $("#customeremail").keyup(function() {
        let query = $(this).val();
        let fieldId = $(this).attr("id");
        let suggestionBox = "#" + fieldId + "_suggestions";

        if (query.length > 4) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_email: query },
                success: function(data) {
                    console.log("API Response:", data); // Debugging
                    let suggestions = "";

                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item' 
                                            data-name='${customer.name || ""}'
                                            data-phone='${customer.contact_number || ""}'
                                            data-email='${customer.email || ""}'
                                            data-address='${customer.address || ""}'>
                                            ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    // Click event for selecting suggestion
    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
		let selected_address = $(this).data("address");

		
		
		$("#customer_shiping_address").val(selected_address);
		$("#customer_address").val(selected_address);

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerphone, #customeremail_suggestions").length) {
            $("#customeremail_suggestions").hide();
        }
    });
});




















// ---------- DATA TABLE & PRODUCT ROW HANDLING ----------
$(document).ready(function() {
    // Define measurement types and corresponding units
    const measurementTypes = {
  "Linear Measurements": [
    { name: "Meter", symbol: "m", value: "Meter" },
    { name: "Centimeter", symbol: "cm", value: "Centimeter" },
    { name: "Millimeter", symbol: "mm", value: "Millimeter" },
    { name: "Kilometer", symbol: "km", value: "Kilometer" },
    { name: "Foot", symbol: "ft", value: "Foot" },
    { name: "Inch", symbol: "in", value: "Inch" }
  ],
  "Area (Surface Measurements)": [
    { name: "Square Meter", symbol: "m²", value: "square-meter" },
    { name: "Square Foot", symbol: "ft²", value: "square-foot" },
    { name: "Square Centimeter", symbol: "cm²", value: "square-centimeter" },
    { name: "Hectare", symbol: "ha", value: "hectare" }
  ],
  "Volume (Cubic Measurements)": [
    { name: "Cubic Meter", symbol: "m³", value: "cubic-meter" },
    { name: "Cubic Foot", symbol: "ft³", value: "cubic-foot" },
    { name: "Liter", symbol: "L", value: "liter" },
    { name: "Gallon", symbol: "gal", value: "gallon" }
  ],
  "Weight": [
    { name: "Kilogram", symbol: "kg", value: "Kilogram" },
    { name: "Gram", symbol: "g", value: "Gram" },
    { name: "Tonne", symbol: "t", value: "Tonne" },
    { name: "Pound", symbol: "lb", value: "Pound" }
  ],
  "Number of Items": [
    { name: "Number", symbol: "Nos.", value: "Number" },
    { name: "Each", symbol: "ea", value: "Each" },
    { name: "Dozen", symbol: "dz", value: "Dozen" }
  ],
  "Time": [
    { name: "Hour", symbol: "hr", value: "hour" },
    { name: "Day", symbol: "d", value: "day" },
    { name: "Week", symbol: "wk", value: "week" },
    { name: "Month", symbol: "mo", value: "month" }
  ],
  "Liquid Volume": [
    { name: "Liter", symbol: "L", value: "Liter" },
    { name: "Milliliter", symbol: "mL", value: "Milliliter" },
    { name: "Gallon", symbol: "gal", value: "Gallon" }
  ],
  "Electrical Units": [
    { name: "Ampere", symbol: "A", value: "Ampere" },
    { name: "Volt", symbol: "V", value: "Volt" },
    { name: "Watt", symbol: "W", value: "Watt" },
    { name: "Kilowatt-hour", symbol: "kWh", value: "Kilowatt-hour" }
  ],
  "Temperature": [
    { name: "Degree Celsius", symbol: "°C", value: "Degree-Celsius" },
    { name: "Degree Fahrenheit", symbol: "°F", value: "Degree-Fahrenheit" }
  ],
  "Other Specialized Units": [
    { name: "Lump Sum", symbol: "LS", value: "Lump-Sum" },
    { name: "Percentage", symbol: "%", value: "Percentage" },
    { name: "Set", symbol: "set", value: "set" },
    { name: "Roll", symbol: "roll", value: "roll" },
    { name: "Sheet", symbol: "sheet", value: "sheet" }
  ]
};

    var table = $('#productTable').DataTable({
        "paging": false,
        "searching": false,
        "info": false,
    });
	
	function updateTotals() {
        let subtotal = 0;
        $('#productTable tbody tr').each(function() {
            let rowTotal = parseFloat($(this).find('.total').val()) || 0;
            subtotal += rowTotal;
        });
        let globalDiscount = parseFloat($('input[name="global_discount"]').val()) || 0;
        let tax = parseFloat($('input[name="global_global_tax"]').val()) || 0;
        let paidAmount = parseFloat($('input[name="global_paid_amount"]').val()) || 0;
        let total = subtotal;
        if (globalDiscount > 0) {
            total -= total * (globalDiscount / 100);
        }
        let taxRate = tax / 100;
        let added_tax = total * taxRate;
        let grandTotal = total + added_tax;
        let dueAmount = grandTotal - paidAmount;
        $('input[name="global_subtotal"]').val(subtotal.toFixed(2));
        $('input[name="global_total"]').val(total.toFixed(2));
        $('input[name="global_grand_total"]').val(grandTotal.toFixed(2));
        $('input[name="global_due_amount"]').val(dueAmount.toFixed(2));
    }

    $('#addRow').on('click', function() {
        // If there is a previous row, copy its SR and Section values.
        var lastRow = $('#productTable tbody tr:last');
        var lastSR = "";
        var lastSection = "";
        var lastSubSection ="";
        if (lastRow.length) {
            lastSR = lastRow.find('.sr').val() || "";
            lastSection = lastRow.find('.section').val() || "";
            lastSubSection = lastRow.find('.subsection').val() || "";
        }
        
        table.row.add([
            '<input type="number" class="form-control sr" name="sr[]" placeholder="Cost Sector Number" value="'+lastSR+'">',
            '<input type="text" class="form-control section" name="section[]" placeholder="Sector Title" value="'+lastSection+'">',
            '<input type="text" class="form-control subsection" name="subsection[]" placeholder="Sub Sector Title" value="'+lastSubSection+'">',
            '<input type="text" class="form-control productinput" name="item[]"><input type="hidden" class="id_holder" name="id[]"><div class="product_suggestions"></div>',
            // Measurement Type select dropdown
            '<select class="form-control measurementType" name="unit_type[]">' +
                '<option value="">Select Measurement Type</option>' +
                '<option value="Linear Measurements">Linear Measurements</option>' +
                '<option value="Area (Surface Measurements)">Area (Surface Measurements)</option>' +
                '<option value="Volume (Cubic Measurements)">Volume (Cubic Measurements)</option>' +
                '<option value="Weight">Weight</option>' +
                '<option value="Number of Items">Number of Items</option>' +
                '<option value="Time">Time</option>' +
                '<option value="Liquid Volume">Liquid Volume</option>' +
                '<option value="Electrical Units">Electrical Units</option>' +
                '<option value="Temperature">Temperature</option>' +
                '<option value="Other Specialized Units">Other Specialized Units</option>' +
            '</select>',
            // Measurement Unit select dropdown, initially disabled
            '<select class="form-control measurementUnit" name="unit[]" disabled>' +
                '<option value="">Select Unit</option>' +
            '</select>',
            '<input type="number" class="form-control quantity" name="quantity[]" min="0" value="0">',
            '<input type="number" class="form-control price"  name="price[]" min="0">',
            '<input type="text" class="form-control total" name="total[]" readonly>',
            '<button type="button" class="btn btn-danger btn-sm removeRow">Remove</button>'
        ]).draw(false);
    });

    $('#productTable tbody').on('click', '.removeRow', function() {
        table.row($(this).parents('tr')).remove().draw();
    });

    $('#productTable tbody').on('keyup', '.productinput', function() {
        let inputField = $(this);
        let query = inputField.val();
        let suggestionBox = inputField.siblings('.product_suggestions');
        if (query.length < 2) {
            suggestionBox.html('').hide();
            return;
        }
        $.ajax({
            url: "<?php echo get_site_url(); ?>/api/customers_api",
            method: "POST",
            data: { search_product_query_name: query },
            success: function(data) {
                suggestionBox.html('');
                if (Array.isArray(data) && data.length > 0) {
                    let suggestions = data.map(product => 
                        `<div class='suggestion-item_table suggestion_item_css' 
                             data-pid='${product.id}'
                             data-name='${product.name}' 
                             data-price='${product.price}' 
                             data-stock='${product.stock}'>
                             ${product.name} - $${product.price}
                         </div>`
                    ).join('');
                    suggestionBox.html(suggestions).show();
                } else {
                    suggestionBox.html('<div class="no-results">No results found</div>').show();
                }
            }
        });
    });

    $('#productTable tbody').on('click', '.suggestion-item_table', function() {
        let selectedProduct = $(this);
        let row = selectedProduct.closest('tr');
        row.find('.productinput').val(selectedProduct.data('name'));
        row.find('.price').val(selectedProduct.data('price')).attr('readonly', true);
        row.find('.quantity').attr('max', selectedProduct.data('stock'));
        row.find('.id_holder').val(selectedProduct.data('pid'));
        row.find('.quantity').val('1');
        let price = parseFloat(selectedProduct.data('price')) || 0;
        let quantity = 1;
        let total = price * quantity;
        row.find('.total').val(total.toFixed(2));
        updateTotals();
        row.find('.product_suggestions').hide();
    });

    $('#productTable tbody').on('input', '.price, .quantity', function() {
        let row = $(this).closest('tr');
        let price = parseFloat(row.find('.price').val()) || 0;
        let quantity = parseFloat(row.find('.quantity').val()) || 0;
        let total = price * quantity;
        row.find('.total').val(total.toFixed(2));
        updateTotals();
    });
	
    $('#outer_totals').on('input', 'input[name="global_discount"], input[name="global_global_tax"], input[name="global_paid_amount"]', function() {
		updateTotals();
    });

    // When a measurement type is selected, update the corresponding unit dropdown
    $('#productTable').on('change', '.measurementType', function() {
        var selectedType = $(this).val();
        var unitSelect = $(this).closest('tr').find('.measurementUnit');
        unitSelect.empty();
        unitSelect.append('<option value="">Select Unit</option>');
        if (selectedType && measurementTypes[selectedType]) {
            $.each(measurementTypes[selectedType], function(index, unit){
                unitSelect.append('<option value="'+unit.value+'">'+unit.name+' ('+unit.symbol+')</option>');
            });
            unitSelect.prop('disabled', false);
        } else {
            unitSelect.prop('disabled', true);
        }
    });
});
</script>
	
</body>
</html>