<?php 
// delete_quotation.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $boqs_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Check if the quotation exists
    $sql = $wpdb->prepare("SELECT q_id FROM wp_zn_system_boq WHERE boq_id = %d;", $boqs_id);
    $result = $wpdb->get_row($sql);
    

    if ($result) {
        // Delete the quotation
        $sql = $wpdb->prepare("DELETE FROM wp_zn_system_boq WHERE boq_id = %d;", $boqs_id);
        $wpdb->query($sql);

        status_header(200);
        wp_redirect($homeurl . "/orders/boqs");
        exit;
    } else {
        echo " not found.";
    }
} else {
    echo 'No  ID provided';
}
?>