<?php
// Invoice by details
$invby_name = 'Amuthu ART';
$invby_email = 'admin@amuthuart.online';
$invby_phone_number = '+94782223322';
$invby_address = 'Example Address';

// Database setup
global $wpdb;
$table_name = $wpdb->prefix . 'zn_system_boq';

require_once 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;
use Dompdf\Options;

// Check ID parameter
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('No BOQ ID provided');
}

$boq_id = (int) $_GET['id'];

// Fetch BOQ data with proper column names from your table
$boq = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_name} WHERE boq_id = %d",
    $boq_id
));

if (!$boq) {
    die('BOQ not found');
}

// Prepare data from BOQ table
$terms_v = "<p>".($boq->description ?? 'No terms specified')."</p>";
$a_notes = $boq->title ?? 'No additional notes';
$project_info = $boq->project_id ? "Project ID: ".$boq->project_id."<br>" : "";
$location_info = $boq->location ? "Location: ".$boq->location."<br>" : "";

// Decode items JSON with error handling
$old_items = [];
if (!empty($boq->items)) {
    $old_items = json_decode($boq->items, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $old_items = [];
        error_log("BOQ PDF Error: Invalid JSON for BOQ {$boq_id}");
    }
}

// Calculate subtotal from items
$calculated_subtotal = 0;
foreach ($old_items as $item) {
    $calculated_subtotal += (float)($item['total'] ?? 0);
}

// Use the calculated subtotal if the database value seems incorrect
$subtotal = (abs($boq->g_subtotal - $calculated_subtotal) > 0.01) ? $calculated_subtotal : $boq->g_subtotal;

// Calculate tax amount
$tax_amount = $subtotal * ($boq->g_tax / 100);

// Calculate discount amount
$discount_amount = $subtotal * ($boq->g_discount / 100);

// Calculate grand total
$grand_total = $subtotal + $tax_amount - $discount_amount;

// Use the calculated grand total if the database value seems incorrect
$final_total = (abs($boq->g_grand_total - $grand_total) > 0.01) ? $grand_total : $boq->g_grand_total;



// Fetch customer information
$customer = null;
if (!empty($boq->customer_id)) {
    $customer = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pos_system_customers WHERE customer_id = %d",
        $boq->customer_id
    ));
}

// PDF setup
$options = new Options();
$options->set('defaultFont', 'Arial');
$options->set('chroot', __DIR__);
$options->set('isRemoteEnabled', true); // For logo loading

$dompdf = new Dompdf($options);
$dompdf->setPaper('A5', 'portrait');

// HTML Template
$html = '<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>BOQ PDF</title>
  <style>
    .quotation-header {
      text-align: center;
      font-size: 24px;
      color: #8c3d16;
      font-weight: bold;
      text-transform: uppercase;
      margin-top: 20px;
    }
    
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      font-family: Arial, sans-serif;
      color: #333;
      background-color: #fff;
    }
    
    .page {
      width: 100%;
      min-height: 100vh; 
    }
    
    /* Header (top area) */
    .header {
      overflow: hidden;
      padding: 2rem;
    }
    .header-left {
      float: left;
    }
    .header-left .company-name {
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 0.3rem;
    }
    .header-left .quotation-label {
      font-size: 16px;
      color: #666;
    }
    
    .header-right {
      float: right;
      text-align: right;
    }
    .header-right .quotation-number {
      font-size: 16px;
      font-weight: bold;
      margin-bottom: 0.3rem;
    }
    .header-right .quotation-date {
      font-size: 14px;
      color: #666;
    }
    

    
    /* Item Table */
    .table-section {
      padding: 0 2rem 2rem 2rem;
    }
    .items-table {
      width: 100%;
      border-collapse: collapse;
      margin: 1rem 0 0 0;
    }
    .items-table th {
      background-color: #8c4d2e;
      color: #fff;
      padding: 0.75rem;
      text-align: left;
    }
    .items-table td {
      padding: 0.75rem;
      border-bottom: 1px solid #eee;
      vertical-align: middle;
    }
    th.text-right, .text-right {
      text-align: right;
    }
    
    /* Bottom Section (Terms + Totals side by side) */
    .bottom-section {
      overflow: hidden;
      margin: 0 2rem 2rem 2rem;
    }
    
    /* Terms and Conditions on the left */
    .terms-section {
    page-break-inside: avoid; 
      width: 48%;
      float: left;
      padding: 2rem;
      box-sizing: border-box;
    }
    .terms-section h4 {
      margin-bottom: 0.5rem;
      font-size: 14px;
      text-transform: uppercase;
      color: #333;
    }
    .terms-section p {
      font-size: 14px;
      color: #666;
      line-height: 18px;
      margin: 0 0 0.5rem 0;
    }
    
    /* Totals section on the right */
    .totals-section {
    page-break-inside: avoid; 
      width: 48%;
      float: right;
      color: #000; 
      padding: 2rem;
      box-sizing: border-box;
      border-radius: 4px;
    }
    .totals-wrapper {
      max-width: 300px;
      margin-left: auto;
    }
    .total-line {
      overflow: hidden;
      margin-bottom: 0.3rem;
      font-size: 14px;
    }
    .total-line span {
      display: inline-block;
      width: 48%;
    }
    .total-line strong {
      font-weight: 600;
    }
    .discount-value {
      color: #85c664;
      font-weight: bold;
    }
    .grand-total {
      margin-top: 0.8rem;
      padding-top: 0.8rem;
      border-top: 2px solid #333;
      font-weight: bold;
    }
    .amount-words {
      margin-top: 1rem;
      font-weight: bold;
      font-size: 14px;
    }
    .clearfix::after {
      content: "";
      display: table;
      clear: both;
    }
 
    .logoimg {
      position: absolute;
      top:20px;
    }
  </style>
</head>
<body>
  <div class="page">
    <div class="quotation-header">BOQ</div>
    
    <div class="header clearfix">
      <div class="header-left">
        <img src="'.__DIR__.'/logo.png" alt="Logo" width="200px" height="120px" class="logoimg">
      </div>
      <div class="header-right">
        <div class="quotation-number">BOQ #'.$boq->boq_id.'</div>
        <div class="quotation-date">Date: '.date('Y-m-d', strtotime($boq->created_at)).'</div>
      </div>
    </div>
    
    <div class="info-section" style="word-break: break-word; overflow-wrap: break-word;">
     
    
    
    <div class="table-section">
      <table class="items-table">
        <thead>
          <tr>
           <th>SR</th>
            <th>Sector</th>
             <th>Sub Sector</th>
            <th>Item</th>
            <th>Qty</th>
             <th>Unit</th>
            <th>Rate</th>
            <th class="text-right">Price</th>
          </tr>
        </thead>
        <tbody>';

foreach ($old_items as $item) {
    $html .= '<tr>
    <td>'.htmlspecialchars($item['sr'] ?? '').'</td>
    <td>'.htmlspecialchars($item['section'] ?? '').'</td>
     <td>'.htmlspecialchars($item['sub_section'][0] ?? '').'</td>
        <td>'.htmlspecialchars($item['item'] ?? '').'</td>
        <td>'.htmlspecialchars($item['quantity'] ?? '').'</td>
         <td>'.htmlspecialchars($item['unit'] ?? '').'</td>
        <td>'.number_format((float)($item['price'] ?? 0), 2).'</td>
        <td class="text-right">'.number_format((float)($item['total'] ?? 0), 2).'</td>
    </tr>';
}

$html .= '</tbody>
      </table>
    </div>
    
    <!--div class="bottom-section clearfix">
      <div class="terms-section">
        <h4>Terms and Conditions</h4>
        '.$terms_v.'
        <h4>Additional Notes</h4>
        <p>'.$a_notes.'</p>
      </div-->
      
      <div class="totals-section">
        <div class="totals-wrapper">
          <div class="total-line">
            <span>Sub Total</span>
            <span>'.number_format($subtotal, 2).'</span>
          </div>
          <div class="total-line">
            <span>Tax</span>
            <span style="color:red;">+ '.number_format($boq->g_tax, 2).'%</span>
          </div>
          <div class="total-line">
            <span>Discount</span>
            <span class="discount-value">- '.number_format($boq->g_discount, 2).'%</span>
          </div>
          <div class="total-line grand-total">
            <span>Total</span>
            <span>'.number_format($final_total, 2).' LKR</span>
          </div>
          <div class="amount-words">
            Total In Words: '.numToWords($final_total).' rupees only.
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>';

function numToWords($num) {
    $f = new NumberFormatter("en", NumberFormatter::SPELLOUT);
    return ucfirst($f->format($num));
}

// Generate PDF
$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->stream('BOQ_'.$boq_id.'.pdf', ['Attachment' => false]);
?>