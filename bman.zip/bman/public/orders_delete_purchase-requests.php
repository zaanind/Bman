<?php 
// delete_quotation.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $pr_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Check if the quotation exists
    $sql = $wpdb->prepare("SELECT q_id FROM wp_zn_system_prs WHERE pr_id = %d;", $pr_id);
    $result = $wpdb->get_row($sql);
    

    if ($result) {
        // Delete the quotation
        $sql = $wpdb->prepare("DELETE FROM wp_zn_system_prs WHERE pr_id = %d;", $pr_id);
        $wpdb->query($sql);

        status_header(200);
        wp_redirect($homeurl . "/orders/purchase-requests");
        exit;
    } else {
        echo " not found.";
    }
} else {
    echo 'No  ID provided';
}
?>