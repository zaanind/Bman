<?php
session_start();
require_once('bcore.php');
// 1. Access Control
$homeurl       = get_site_url();
$wpuser_ob     = wp_get_current_user();
$allowed_roles = array('administrator','salesman');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Validate and fetch the order
global $wpdb;
$table_name = $wpdb->prefix . 'pos_system_orders';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = 'Invalid order ID.';
    wp_redirect($homeurl . '/orders/');
    exit;
}

$order_id = (int) $_GET['id'];

// Fetch the existing order
$order = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_name} WHERE order_id = %d",
    $order_id
));
if (!$order) {
    $_SESSION['error'] = 'Order not found.';
    wp_redirect($homeurl . '/orders/');
    exit;
}

// Decode existing items JSON
$old_items = json_decode($order->items, true);
if (!is_array($old_items)) {
    $old_items = [];
}

// (Optional) Fetch the customer to pre-fill name/phone/email
$customer = null;
if (!empty($order->customer_id)) {
    $customer = $wpdb->get_row("
        SELECT * 
        FROM {$wpdb->prefix}pos_system_customers 
        WHERE customer_id = {$order->customer_id}
    ");
}

// 3. Handle POST (Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // A) Restore old items to inventory
    foreach ($old_items as $old_item) {
        $pid = (int) $old_item['id'];
        $qty = (int) $old_item['quantity'];
        $resp = $wpdb->get_row("
            SELECT quantity 
            FROM {$wpdb->prefix}pos_system_inventory_products 
            WHERE product_id = $pid
        ");
        if ($resp) {
            $current_qty = (int) $resp->quantity;
            $wpdb->update(
                "{$wpdb->prefix}pos_system_inventory_products",
                [ 'quantity' => $current_qty + $qty ],
                [ 'product_id' => $pid ]
            );
        }
    }

    // B) Gather new form data
    $name                      = sanitize_text_field($_POST['name']);
    $email                     = sanitize_text_field($_POST['email']);
    $phone_number              = sanitize_text_field($_POST['phone']);
    $customer_address          = sanitize_text_field($_POST['customer_address']);
    $customer_shipping_address = sanitize_text_field($_POST['customer_shiping_address']);
    $notes                     = sanitize_text_field($_POST['notes']);
    // If you want to allow editing order_date:
    // $order_date             = sanitize_text_field($_POST['orderdate']);

    // Items arrays
    $product_titles = $_POST['item'];
    $items    = $_POST['id'];
    $quantity = $_POST['quantity'];
    $price    = $_POST['price'];
    $discount = $_POST['discount'];
    $total    = $_POST['total'];
    $terms =  $_POST['terms'];

    // Build new items array
    $new_items = [];
    for ($i = 0; $i < count($items); $i++) {
        $new_items[] = [
            'title' => $product_titles[$i],
            'id'       => (int) $items[$i],
            'quantity' => (int) $quantity[$i],
            'price'    => (float) $price[$i],
            'discount' => (float) $discount[$i],
            'total'    => (float) $total[$i],
        ];
    }
    $items_data_json = json_encode($new_items);

    // Global sums
    $global_subtotal     = floatval($_POST['global_subtotal']);
    $global_total        = floatval($_POST['global_total']);
    $global_discount     = floatval($_POST['global_discount']);
    $global_grand_total  = floatval($_POST['global_grand_total']);
    $global_global_tax   = floatval($_POST['global_global_tax']);
    $global_paid_amount  = floatval($_POST['global_paid_amount']);
    $global_due_amount   = floatval($_POST['global_due_amount']);

    // Payment info
    $payment_type   = sanitize_text_field($_POST['payment_type']);
    $payment_states = sanitize_text_field($_POST['payment_states']);
    $payment_place  = sanitize_text_field($_POST['payment_place']);

    // C) Create/assign customer
    $existing_customer = $wpdb->get_row("
        SELECT customer_id 
        FROM {$wpdb->prefix}pos_system_customers 
        WHERE email = '{$email}'
    ");
    if (!$existing_customer) {
        // Insert a new customer
        $wpdb->insert(
            "{$wpdb->prefix}pos_system_customers",
            [
                'name'         => $name,
                'email'        => $email,
                'phone_number' => $phone_number,
                'address'      => $customer_address,
            ]
        );
        $customer_id = $wpdb->insert_id;
    } else {
        $customer_id = $existing_customer->customer_id;
    }

    // D) Subtract new items from inventory
    foreach ($new_items as $item) {
        $pid = (int) $item['id'];
        $qty = (int) $item['quantity'];
        $resp = $wpdb->get_row("
            SELECT quantity 
            FROM {$wpdb->prefix}pos_system_inventory_products 
            WHERE product_id = $pid
        ");
        if ($resp) {
            $current_qty = (int) $resp->quantity;
            $wpdb->update(
                "{$wpdb->prefix}pos_system_inventory_products",
                [ 'quantity' => $current_qty - $qty ],
                [ 'product_id' => $pid ]
            );
        }
    }
    
    
    $ar_id =  $order->ar_id;
    
    
    $ar_data = array(
        'id' => $ar_id,
        'due' => $global_due_amount,
        'amount' => $global_grand_total,
        'paid' => $global_paid_amount,
    );
    
    $ar_res  = save_ar_data($ar_data);
    
    

    // E) Update the order
    $update_data = [
        'customer_id'      => $customer_id,
        'notes'            => $notes,
        'terms'            => $terms, 
        'items'            => $items_data_json,
        'g_subtotal'       => $global_subtotal,
        'g_total_amount'   => $global_total,
        'g_grand_total'    => $global_grand_total,
        'g_tax'            => $global_global_tax,
        'g_paid'           => $global_paid_amount,
        'g_due'            => $global_due_amount,
        'g_discount'       => $global_discount,
        'shipping_address' => $customer_shipping_address,
        'billing_address'  => $customer_address,
        'payment_method'   => $payment_type,
        'payment_states'   => $payment_states,
        'payment_location' => $payment_place,
        // 'order_date'     => $order_date, // if editing date
        'updated_at'       => current_time('mysql'),
    ];

    // Keep the existing order_status if you want, or allow user to change it:
    // $update_data['order_status'] = 'ongoing'; // or 'completed', etc.

    $updated = $wpdb->update($table_name, $update_data, ['order_id' => $order_id]);
    if ($updated === false) {
        $_SESSION['error'] = 'Failed to update order.';
        wp_redirect($homeurl . '/orders/edit?id=' . $order_id);
        exit;
    }

    wp_redirect($homeurl . '/orders/');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // Standard WP plugin includes
    $active_page  = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Edit Invoice #<?php echo esc_html($order->order_id); ?> | <?php echo get_bloginfo('name'); ?></title>
    
    <!-- You can reuse the same CSS as in your Add page -->
    <style>
        .customer_suggestions {
            border: 1px solid #ccc;
            max-height: 150px;
            overflow-y: auto;
            position: absolute;
            background: white;
            width: 100%;
            z-index: 1000;
            display:none;
        }
        .suggestion-item, .suggestion-item_table {
            cursor: pointer;
            padding: 8px;
        }
        .suggestion-item:hover, .suggestion-item_table:hover {
            background: #f0f0f0;
        }
        /* DataTables override if needed */
        .dataTables_wrapper .dataTables_filter, 
        .dataTables_wrapper .dataTables_length, 
        .dataTables_wrapper .dataTables_info, 
        .dataTables_wrapper .dataTables_paginate {
            display: none !important; /* Hiding since you said no paging, searching, etc. */
        }
    </style>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            // Display error messages if any
            if (isset($_SESSION['error'])) {
                $err = $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Error:</strong> <?php echo esc_html($err); ?>
                    </div>
                </div>
            <?php } ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Edit Invoice #<?php echo esc_html($order->order_id); ?></h1>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <form method="POST" 
                                      action="<?php echo esc_url($homeurl . '/orders/edit?id=' . $order->order_id); ?>"
                                      enctype="multipart/form-data">
                                    <?php
                                    // Pre-fill customer data from $customer if available
                                    $existing_name  = $customer ? $customer->name         : '';
                                    $existing_email = $customer ? $customer->email        : '';
                                    $existing_phone = $customer ? $customer->phone_number : '';
                                    $existing_addr  = $customer ? $customer->address      : '';

                                    // Use the order’s addresses if needed
                                    $ordr_barcode_id_f   = $order->barcode;
                                    $billing_addr   = $order->billing_address;
                                    $shipping_addr  = $order->shipping_address;
                                    ?>



                                     <div class="mb-3">
                                            <label class="form-label">Barcode:</label><br>
                                            <?php
                                                $image_url  = "";
                                                
                                             

    if (isset($ordr_barcode_id_f)) {
                                                    $image = wp_get_attachment_image_src($ordr_barcode_id_f , 'full');
                                                    $image_url = $image[0];
                                                }

                                            ?>
                                            <img src="<?php echo esc_url($image_url); ?>" width="225px" alt="Barcode">
                                            
                                        </div>


                                    <!-- Customer Info -->
                                    <div class="mb-3">
                                        <label class="form-label">Customer Name:</label>
                                        <input type="text" class="form-control" id="customerName"
                                               name="name" autocomplete="off"
                                               value="<?php echo esc_attr($existing_name); ?>" required>
                                        <div class="customer_suggestions" id="customerName_suggestions"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Contact No:</label>
                                        <input type="text" class="form-control" id="customerphone"
                                               name="phone" autocomplete="off"
                                               value="<?php echo esc_attr($existing_phone); ?>" required>
                                        <div class="customer_suggestions" id="customerphone_suggestions"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Email:</label>
                                        <input type="text" class="form-control" id="customeremail"
                                               name="email" autocomplete="off"
                                               value="<?php echo esc_attr($existing_email); ?>" required>
                                        <div class="customer_suggestions" id="customeremail_suggestions"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Billing Address:</label>
                                        <input type="text" class="form-control" id="customer_address"
                                               name="customer_address" 
                                               value="<?php echo esc_attr($billing_addr); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Shipping Address:</label>
                                        <input type="text" class="form-control" id="customer_shiping_address"
                                               name="customer_shiping_address"
                                               value="<?php echo esc_attr($shipping_addr); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Notes:</label>
                                        <textarea class="form-control" name="notes"><?php 
                                            echo $order->notes; 
                                        ?></textarea>
                                    </div>
                                            
                                            
                                            
                                            
                                                   <div class="mb-3">
                                        <label class="form-label">Terms:</label>
                                        <textarea class="form-control" name="terms"><?php 
                                            echo $order->terms; 
                                        ?></textarea>
                                    </div>
                                            
                                            

                                    <!-- If you allow changing order date:
                                    <div class="mb-3">
                                        <label class="form-label">Order Date:</label>
                                        <input type="text" class="form-control" name="orderdate"
                                               value="<?php //echo esc_attr($order->order_date); ?>">
                                    </div>
                                    -->

                                    <!-- Product Table -->
                                    <div class="table-responsive">
                                        <table id="productTable" class="table table-bordered">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>Item</th>
                                                    <th>Available</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                    <th>Discount (%)</th>
                                                    <th>Total</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            // Pre-populate rows from $old_items
                                            foreach ($old_items as $item) {
                                                
                                                $itemId    = (int) $item['id'];
                                                $itemQty   = (int) $item['quantity'];
                                                $itemPrice = (float) $item['price'];
                                                $itemDisc  = (float) $item['discount'];
                                                $itemTotal = (float) $item['total'];

                                                // Fetch product name & current stock
                                                $pRow   = $wpdb->get_row("
                                                    SELECT product_name, quantity
                                                    FROM {$wpdb->prefix}pos_system_inventory_products
                                                    WHERE product_id = $itemId
                                                ");
                                                 // Check if product exists
                                                  if ($pRow) {
                                                      $pName  = $pRow->product_name;
                                                      $pStock = (int) $pRow->quantity;
                                                  } else {
                                                      // If product ID does not exist, set the product name to item title
                                                      $pName  = $item['title'];
                                                      $pStock = 0; // Default stock to 0 if product does not exist
                                                  }
                                               // $pName  = $pRow ? $pRow->product_name : '';
                                                //$pStock = $pRow ? (int) $pRow->quantity : 0;
                                                ?>
                                                <tr>
                                                    <td>
                                                        <input type="text" class="form-control productinput"
                                                               name="item[]" 
                                                               value="<?php echo esc_attr($pName); ?>">
                                                        <input type="hidden" class="id_holder" name="id[]" 
                                                               value="<?php echo esc_attr($itemId); ?>" step="any"> 
                                                        <div class="product_suggestions"></div>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="form-control avalible"
                                                               value="<?php echo esc_attr($pStock); ?>" step="any"
                                                               readonly>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="form-control quantity"
                                                               name="quantity[]" min="0"
                                                               value="<?php echo esc_attr($itemQty); ?>" step="any">
                                                    </td>
                                                    <td>
                                                        <input type="number" class="form-control price"
                                                               name="price[]" min="0" step="0.01"
                                                               value="<?php echo esc_attr($itemPrice); ?>" step="any">
                                                    </td>
                                                    <td>
                                                        <input type="number" class="form-control discount"
                                                               name="discount[]" min="0" max="100"
                                                               value="<?php echo esc_attr($itemDisc); ?>" step="any">
                                                    </td>
                                                    <td>
                                                        <input type="text" class="form-control total"
                                                               name="total[]" readonly
                                                               value="<?php echo esc_attr($itemTotal); ?>" >
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-danger btn-sm removeRow">
                                                            Remove
                                                        </button>
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <button type="button" class="btn btn-success" style="margin-top:5px;" id="addRow">
                                        Add Item Row
                                    </button>

                                    <!-- Totals Section -->
                                    <div class="row g-4" style="margin-top:8px;">
                                        <div class="col-md-3">
                                            <label class="form-label">Subtotal:</label>
                                            <input type="number" class="form-control" 
                                                   name="global_subtotal" required step="any"
                                                   value="<?php echo esc_attr($order->g_subtotal); ?>">
                                        </div>

                                        <div class="col-md-3">
                                            <label class="form-label">Total:</label>
                                            <input type="number" class="form-control" 
                                                   name="global_total" required step="any"
                                                   value="<?php echo esc_attr($order->g_total_amount); ?>">
                                        </div>

                                        <div class="col-md-3">
                                            <label class="form-label">Discount:</label>
                                            <input type="number" class="form-control"
                                                   name="global_discount" step="any"
                                                   value="<?php echo esc_attr($order->g_discount); ?>">
                                        </div>

                                        <div class="col-md-3">
                                            <label class="form-label">Grand Total:</label>
                                            <input type="number" class="form-control" 
                                                   name="global_grand_total" required step="any"
                                                   value="<?php echo esc_attr($order->g_grand_total); ?>">
                                        </div>

                                        <div class="col-md-4">
                                            <label class="form-label">Tax (%):</label>
                                            <input type="number" class="form-control"
                                                   name="global_global_tax" step="any"
                                                   value="<?php echo esc_attr($order->g_tax); ?>">
                                        </div>

                                        <div class="col-md-4">
                                            <label class="form-label">Paid Amount:</label>
                                            <input type="number" class="form-control"
                                                   name="global_paid_amount" step="any"
                                                   value="<?php echo esc_attr($order->g_paid); ?>" readonly>
                                        </div>

                                        <div class="col-md-4">
                                            <label class="form-label">Due Amount:</label>
                                            <input type="number" class="form-control"
                                                   name="global_due_amount" required step="any"
                                                   value="<?php echo esc_attr($order->g_due); ?>">
                                        </div>
                                    </div>
<div style="display:none;">
                                    <!-- Payment Info -->
                                    <div class="mb-3" style="margin-top:30px; ">
                                        <label class="form-label">Payment Type:</label>
                                        <select class="form-control" name="payment_type" required>
                                            <?php
                                            $types = ['Select','Cash','Check','Credit','Estimate/Quote','Trade'];
                                            foreach ($types as $t) {
                                                $sel = ($order->payment_method === $t) ? 'selected' : '';
                                                echo "<option $sel>$t</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Payment States:</label>
                                        <select class="form-control" name="payment_states" required>
                                            <?php
                                            $statesArr = ['Select','Full Payment','Advance Payment','No Payment'];
                                            foreach ($statesArr as $ps) {
                                                $sel = ($order->payment_states === $ps) ? 'selected' : '';
                                                echo "<option $sel>$ps</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Payment Place:</label>
                                        <select class="form-control" name="payment_place" required>
                                            <?php
                                            $places = ['Select','Local','Out Of State'];
                                            foreach ($places as $pp) {
                                                $sel = ($order->payment_location === $pp) ? 'selected' : '';
                                                echo "<option $sel>$pp</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
					</div>

                                    <button style="margin-top:30px;" class="btn btn-outline-primary float-end" type="submit">
                                        Update Order
                                    </button>
                                </form>
                            </div><!-- card-body -->
                        </div><!-- card -->
                    </div><!-- col-12 -->
                </div><!-- row -->
            </div><!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<!-- Full jQuery + DataTables logic (mirroring your Add page) -->
<script>
// Make sure jQuery & DataTables scripts are loaded (in header/footer).
// 1) DataTables init
// 2) #addRow click -> add new row
// 3) productinput keyup -> product suggestions
// 4) suggestion-item_table click -> fill row
// 5) recalc totals on quantity/discount changes
// 6) similarly, handle name/phone/email suggestions

// ========== SUGGESTIONS FOR NAME ========== //
jQuery(document).ready(function($) {
    $("#customerName").keyup(function() {
        let query = $(this).val();
        let suggestionBox = "#customerName_suggestions";
        if (query.length > 3) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_name: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item'
                                data-name='${customer.name || ""}'
                                data-phone='${customer.contact_number || ""}'
                                data-email='${customer.email || ""}'
                                data-address='${customer.address || ""}'>
                                ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                            </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
        let selectedAddress = $(this).data("address");

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);
        $("#customer_address").val(selectedAddress);
        $("#customer_shiping_address").val(selectedAddress);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions if click outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerName, #customerName_suggestions").length) {
            $("#customerName_suggestions").hide();
        }
    });
});

// ========== SUGGESTIONS FOR PHONE ========== //
jQuery(document).ready(function($) {
    $("#customerphone").keyup(function() {
        let query = $(this).val();
        let suggestionBox = "#customerphone_suggestions";
        if (query.length > 5) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_phone: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item'
                                data-name='${customer.name || ""}'
                                data-phone='${customer.contact_number || ""}'
                                data-email='${customer.email || ""}'
                                data-address='${customer.address || ""}'>
                                ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                            </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
        let selectedAddress = $(this).data("address");

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);
        $("#customer_address").val(selectedAddress);
        $("#customer_shiping_address").val(selectedAddress);

        $(".customer_suggestions").hide();
    });

    $(document).click(function(event) {
        if (!$(event.target).closest("#customerphone, #customerphone_suggestions").length) {
            $("#customerphone_suggestions").hide();
        }
    });
});

// ========== SUGGESTIONS FOR EMAIL ========== //
jQuery(document).ready(function($) {
    $("#customeremail").keyup(function() {
        let query = $(this).val();
        let suggestionBox = "#customeremail_suggestions";
        if (query.length > 4) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_email: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item'
                                data-name='${customer.name || ""}'
                                data-phone='${customer.contact_number || ""}'
                                data-email='${customer.email || ""}'
                                data-address='${customer.address || ""}'>
                                ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                            </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
        let selectedAddress = $(this).data("address");

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);
        $("#customer_address").val(selectedAddress);
        $("#customer_shiping_address").val(selectedAddress);

        $(".customer_suggestions").hide();
    });

    $(document).click(function(event) {
        if (!$(event.target).closest("#customeremail, #customeremail_suggestions").length) {
            $("#customeremail_suggestions").hide();
        }
    });
});

// ========== DataTables + Product Row Logic ========== //
jQuery(document).ready(function($) {
    // Initialize DataTables (no paging/search)
    var table = $('#productTable').DataTable({
        paging: false,
        searching: false,
        info: false
    });

    // Function to recalc totals
    function updateTotals() {
        let subtotal = 0;
        $('#productTable tbody tr').each(function() {
            let rowTotal = parseFloat($(this).find('.total').val()) || 0;
            subtotal += rowTotal;
        });

        let globalDiscount = parseFloat($('input[name="global_discount"]').val()) || 0;
        let tax = parseFloat($('input[name="global_global_tax"]').val()) || 0;
        let paidAmount = parseFloat($('input[name="global_paid_amount"]').val()) || 0;

        // Calculate total after discount
        let total = subtotal;
        if (globalDiscount > 0) {
            total -= total * (globalDiscount / 100);
        }

        // Calculate grand total (including tax)
        let taxRate = tax / 100; 
        let addedTax = total * taxRate;
        let grandTotal = total + addedTax;
        let dueAmount = grandTotal - paidAmount;

        // Update fields
        $('input[name="global_subtotal"]').val(subtotal.toFixed(2));
        $('input[name="global_total"]').val(total.toFixed(2));
        $('input[name="global_grand_total"]').val(grandTotal.toFixed(2));
        $('input[name="global_due_amount"]').val(dueAmount.toFixed(2));
    }

    // Add new row
    $('#addRow').on('click', function() {
        table.row.add([
            `<input type="text" class="form-control productinput" name="item[]" autocomplete="off">
             <input type="text" class="id_holder" name="id[]" hidden>
             <div class="product_suggestions"></div>`,
            `<input type="number" class="form-control avalible" min="0" value="0" readonly step="any">`,
            `<input type="number" class="form-control quantity" name="quantity[]" min="0" value="0" step="any">`,
            `<input type="number" class="form-control price" name="price[]" min="0"  step="any">`,
            `<input type="number" class="form-control discount" name="discount[]" min="0" max="100">`,
            `<input type="text" class="form-control total" name="total[]" readonly step="any">`,
            `<button type="button" class="btn btn-danger btn-sm removeRow">Remove</button>`
        ]).draw(false);
    });

    // Remove row
    $('#productTable tbody').on('click', '.removeRow', function() {
        table.row($(this).parents('tr')).remove().draw();
        updateTotals();
    });

    // Product suggestions
    $('#productTable tbody').on('keyup', '.productinput', function() {
        let inputField = $(this);
        let query = inputField.val();
        let suggestionBox = inputField.siblings('.product_suggestions');

        if (query.length < 2) {
            suggestionBox.html('').hide();
            return;
        }

        $.ajax({
            url: "<?php echo get_site_url(); ?>/api/customers_api",
            method: "POST",
            data: { search_product_query_name: query },
            success: function(data) {
                suggestionBox.html('');
                if (Array.isArray(data) && data.length > 0) {
                    let suggestions = data.map(product => 
                        `<div class='suggestion-item_table'
                             data-pid='${product.id}'
                             data-name='${product.name}'
                             data-price='${product.price}'
                             data-stock='${product.stock}'
                             data-discount='${product.discount}'>
                             ${product.name} - $${product.price}
                         </div>`
                    ).join('');
                    suggestionBox.html(suggestions).show();
                } else {
                    suggestionBox.html('<div class="no-results">No results found</div>').show();
                }
            }
        });
    });

    // Select product from suggestions
    $('#productTable tbody').on('click', '.suggestion-item_table', function() {
        let selectedProduct = $(this);
        let row = selectedProduct.closest('tr');

        let stock = selectedProduct.data('stock');
        let price = parseFloat(selectedProduct.data('price')) || 0;
        let discount = parseFloat(selectedProduct.data('discount')) || 0;

        row.find('.productinput').val(selectedProduct.data('name'));
        row.find('.id_holder').val(selectedProduct.data('pid'));
        row.find('.avalible').val(stock).attr('readonly', true);
        row.find('.price').val(price);
        row.find('.discount').val(discount);

        // Set quantity = 1 if in stock
        if (stock > 0) {
            row.find('.quantity').val(1);
        } else {
            row.find('.quantity').val(0);
        }

        // Calculate total
        let total = price;
        if (discount > 0) {
            total -= total * (discount / 100);
        }
        row.find('.total').val(total.toFixed(2));

        row.find('.product_suggestions').hide();
        updateTotals();
    });

    // Recalculate row total on input changes
    $('#productTable tbody').on('input', '.price, .quantity, .discount', function() {
        let row = $(this).closest('tr');
        let price = parseFloat(row.find('.price').val()) || 0;
        let qty = parseInt(row.find('.quantity').val()) || 0;
        let discount = parseFloat(row.find('.discount').val()) || 0;

        let total = price * qty;
        if (discount > 0) {
            total -= total * (discount / 100);
        }
        row.find('.total').val(total.toFixed(2));
        updateTotals();
    });

    // Recalculate overall totals on discount/tax/paid changes
    $('input[name="global_discount"], input[name="global_global_tax"], input[name="global_paid_amount"]')
        .on('input', function() {
            updateTotals();
        });
});
</script>
</body>
</html>