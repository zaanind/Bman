<?php
session_start();


$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator','salesman');


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}







  function make_user($name,$email,$phone, $address){
	global $wpdb;
	$table_name_customer = $wpdb->prefix . 'pos_system_customers';
    $data = array(
        'name' => $name,
		'email' => $email,
		'phone_number' => $phone,
		'address' => $address,
      );
     $wpdb->insert($table_name_customer, $data);
	 
	 
 } 
 
 
 
   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	  global $wpdb;
	   
        
      $homeurl = get_site_url();

      $name = $_POST['name'];
      $phone = $_POST['phone'];
      $address = $_POST['customer_address'];
	  $email = $_POST['email'];
	  $title = $_POST['title'];

	  $description = $_POST['description'];
     
      
	  
	$sql = $wpdb->prepare("SELECT customer_id FROM wp_pos_system_customers WHERE email='".$email."'");

    $result = $wpdb->get_results($sql);
	
	if (empty($result[0]->customer_id)) {  
	make_user($name,$email,$phone,$address);
	}
	 
	
	$result = $wpdb->get_results("SELECT customer_id FROM wp_pos_system_customers WHERE email='".$email."'");

	$customer_id = $result[0]->customer_id;
  
    $table_name = $wpdb->prefix . 'zn_system_prs';
    $data = array(
        'title' => $title,
	    'description' => $description,
	    'status' => 'pending',
	    'customer' => $customer_id, //get id via mysql
      );
	
	
    $inserted = $wpdb->insert($table_name, $data);

	  
        if ($inserted === false) {
		  $_SESSION['error'] = 'Failed';
		  header('location:'.$homeurl.'/orders/purchase-requests/add');
		  exit;
      

	  }


    
	header('location:'.$homeurl.'/orders/purchase-requests/');
}
		


?>



   <!DOCTYPE html>
<html lang="en">
<head>
   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title> Add Purchase Request | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



			<main class="content">
			<?php
                   if (isset($_SESSION['error'])) {
                         $err = $_SESSION['error'];
                         unset($_SESSION['error']);?>
						 
						 			<div class="alert alert-danger alert-dismissible" role="alert">
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											<div class="alert-message">
												<strong>Error:</strong> Failed to add item
											</div>
										</div>

						<?php }	?>
								
								
					
										
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Add Purchase Request </h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
						
								<div class="card-body">
								       
                                      <form method="POST" action="<?php echo get_site_url(); ?>/orders/purchase-requests/add" enctype="multipart/form-data" onsubmit="return validateForm()">
                                    

										
										
									<div style="display:flex;justify-content: flex-start;">
    									<div class="mb-3 col-lg-6" style="margin-right:20px;">
                                            <label  class="form-label">Customer Name:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customerName"  name="name" required>
											<div class="customer_suggestions" id="customerName_suggestions"></div>
                                        </div>
										
										<div class="mb-3 col-lg-5">
                                            <label  class="form-label">Contact No:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customerphone"  name="phone" required>
											<div class="customer_suggestions" id="customerphone_suggestions"></div>
                                        </div> </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Email:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customeremail"  name="email" required>
											<div class="customer_suggestions" id="customeremail_suggestions"></div>
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Address:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control" id="customer_address"  name="customer_address" required>
		
                                        </div>
										

										
										<div class="mb-3 col-lg-6" style="margin-right:20px;">
                                            <label  class="form-label">Project Title:</label>
                                            <input type="text" autocomplete="off" autocorrect="off" class="form-control"  name="title" required>
											<div class="customer_suggestions" id="customerName_suggestions"></div>
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Description:</label>
                                            <textarea autocomplete="off" autocorrect="off" class="form-control"  name="description"></textarea>
		
                                        </div>
										

										
										<button class="btn btn-outline-primary float-end"> Add</button>
										</form>
								<!--input type="text" class="form-control" placeholder="Input"-->
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>


			
			
			
			
			<?php include_once('footer.php');?>
		</div>
	</div>

	

	

</body>

<script>


//name
$(document).ready(function() {
    $("#customerName").keyup(function() {
        let query = $(this).val();
        let fieldId = $(this).attr("id");
        let suggestionBox = "#" + fieldId + "_suggestions";

        if (query.length > 3) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_name: query },
                success: function(data) {
                    console.log("API Response:", data); // Debugging
                    let suggestions = "";

                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item' 
                                            data-name='${customer.name || ""}'
                                            data-phone='${customer.contact_number || ""}'
                                            data-email='${customer.email || ""}'
                                            data-address='${customer.address || ""}'>
                                            ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    // Click event for selecting suggestion
    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
		let selected_address = $(this).data("address");

		
		
		$("#customer_shiping_address").val(selected_address);
		$("#customer_address").val(selected_address);
		

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerName, #customerName_suggestions").length) {
            $("#customerName_suggestions").hide();
        }
    });
});





//phone
$(document).ready(function() {
    $("#customerphone").keyup(function() {
        let query = $(this).val();
        let fieldId = $(this).attr("id");
        let suggestionBox = "#" + fieldId + "_suggestions";

        if (query.length > 5) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_phone: query },
                success: function(data) {
                    console.log("API Response:", data); // Debugging
                    let suggestions = "";

                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item' 
                                            data-name='${customer.name || ""}'
                                            data-phone='${customer.contact_number || ""}'
                                            data-email='${customer.email || ""}'
                                            data-address='${customer.address || ""}'>
                                            ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    // Click event for selecting suggestion
    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
		
		let selected_address = $(this).data("address");

		
		
		$("#customer_shiping_address").val(selected_address);
		$("#customer_address").val(selected_address);

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerphone, #customerphone_suggestions").length) {
            $("#customerphone_suggestions").hide();
        }
    });
});


//email
$(document).ready(function() {
    $("#customeremail").keyup(function() {
        let query = $(this).val();
        let fieldId = $(this).attr("id");
        let suggestionBox = "#" + fieldId + "_suggestions";

        if (query.length > 4) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_email: query },
                success: function(data) {
                    console.log("API Response:", data); // Debugging
                    let suggestions = "";

                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item' 
                                            data-name='${customer.name || ""}'
                                            data-phone='${customer.contact_number || ""}'
                                            data-email='${customer.email || ""}'
                                            data-address='${customer.address || ""}'>
                                            ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    // Click event for selecting suggestion
    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
		let selected_address = $(this).data("address");

		
		
		$("#customer_shiping_address").val(selected_address);
		$("#customer_address").val(selected_address);

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions when clicking outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerphone, #customeremail_suggestions").length) {
            $("#customeremail_suggestions").hide();
        }
    });
});
</script>

</html>