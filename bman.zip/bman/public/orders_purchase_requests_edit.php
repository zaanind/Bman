<?php
session_start();
include_once('bcore.php');
// 1. Access Control
$homeurl       = get_site_url();
$wpuser_ob     = wp_get_current_user();
$allowed_roles = array('administrator','salesman');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2. Validate and fetch the order
global $wpdb;
$table_name = $wpdb->prefix . 'zn_system_prs';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = 'Invalid order ID.';
    wp_redirect($homeurl . '/orders/boqs/');
    exit;
}

$id = (int) $_GET['id'];



// Fetch the existing order
$dbo = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_name} WHERE pr_id = %d",
    $id
));
if (!$order) {
    wp_redirect($homeurl . '/orders/boqs/');
    exit;
}



// (Optional) Fetch the customer to pre-fill name/phone/email
$customer = null;
if (!empty($dbo->customer)) {
    $customer = $wpdb->get_row("
        SELECT * 
        FROM {$wpdb->prefix}pos_system_customers 
        WHERE customer_id = {$dbo->customer}
    ");
}

// 3. Handle POST (Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    

    // B) Gather new form data
    $name                      = sanitize_text_field($_POST['name']);
    $email                     = sanitize_text_field($_POST['email']);
    $phone_number              = sanitize_text_field($_POST['phone']);
    $customer_address          = sanitize_text_field($_POST['customer_address']);

    
    $title = $_POST['title'];
    $description   = $_POST['description'];

 



    // C) Create/assign customer
    $existing_customer = $wpdb->get_row("
        SELECT customer_id 
        FROM {$wpdb->prefix}pos_system_customers 
        WHERE email = '{$email}'
    ");
    if (!$existing_customer) {
        // Insert a new customer
        $wpdb->insert(
            "{$wpdb->prefix}pos_system_customers",
            [
                'name'         => $name,
                'email'        => $email,
                'phone_number' => $phone_number,
                'address'      => $customer_address,
            ]
        );
        $customer_id = $wpdb->insert_id;
    } else {
        $customer_id = $existing_customer->customer_id;
    }
    
    $data = array(
    'pr_id' => $id,
    'customer'     => $customer_id,
    'title'      =>  $title,
    'description'  =>  $description,

    );


      $new_id = save_prs_data($data);

    if ($updated === false) {
        $_SESSION['error'] = 'Failed to update order.';
        wp_redirect($homeurl . '/orders/purchase-requests');
        exit;
    }

    wp_redirect($homeurl . '/orders/purchase-requests');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // Standard WP plugin includes
    $active_page  = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');
    ?>
    <title>Edit PR | <?php echo get_bloginfo('name'); ?></title>
    
    <!-- You can reuse the same CSS as in your Add page -->
    <style>
        .customer_suggestions {
            border: 1px solid #ccc;
            max-height: 150px;
            overflow-y: auto;
            position: absolute;
            background: white;
            width: 100%;
            z-index: 1000;
            display:none;
        }
        .suggestion-item, .suggestion-item_table {
            cursor: pointer;
            padding: 8px;
        }
        .suggestion-item:hover, .suggestion-item_table:hover {
            background: #f0f0f0;
        }
        /* DataTables override if needed */
        .dataTables_wrapper .dataTables_filter, 
        .dataTables_wrapper .dataTables_length, 
        .dataTables_wrapper .dataTables_info, 
        .dataTables_wrapper .dataTables_paginate {
            display: none !important; /* Hiding since you said no paging, searching, etc. */
        }
    </style>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            // Display error messages if any
            if (isset($_SESSION['error'])) {
                $err = $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Error:</strong> <?php echo esc_html($err); ?>
                    </div>
                </div>
            <?php } ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Edit Pr</h1>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <form method="POST" 
                                      action="<?php echo esc_url($homeurl . '/orders/purchase-requests/edit?id=' . $dbo->pr_id); ?>"
                                      enctype="multipart/form-data">
                                    <?php
                                    // Pre-fill customer data from $customer if available
                                    $existing_name  = $customer ? $customer->name         : '';
                                    $existing_email = $customer ? $customer->email        : '';
                                    $existing_phone = $customer ? $customer->phone_number : '';
                                    $existing_addr  = $customer ? $customer->address      : '';

                                    ?>





                                    <!-- Customer Info -->
                                    <div class="mb-3">
                                        <label class="form-label">Customer Name:</label>
                                        <input type="text" class="form-control" id="customerName"
                                               name="name" autocomplete="off"
                                               value="<?php echo esc_attr($existing_name); ?>" required>
                                        <div class="customer_suggestions" id="customerName_suggestions"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Contact No:</label>
                                        <input type="text" class="form-control" id="customerphone" name="phone" autocomplete="off"   value="<?php echo esc_attr($existing_phone); ?>" required>
                                        <div class="customer_suggestions" id="customerphone_suggestions"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Email:</label>
                                        <input type="text" class="form-control" id="customeremail"  name="email" autocomplete="off"  value="<?php echo esc_attr($existing_email); ?>" required>
                                        <div class="customer_suggestions" id="customeremail_suggestions"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Address:</label>
                                        <input type="text" class="form-control" id="customer_address"  name="customer_address"  value="<?php echo esc_attr($existing_addr); ?>" required>
                                    </div>

                                    
	<div class="mb-3 col-lg-6" style="margin-right:20px;">
     <label  class="form-label">Project Title:</label>
     <input type="text" autocomplete="off" autocorrect="off" class="form-control"  name="title" required value="<?php echo $dbo->title; ?>">
									    </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Description:</label>
                                            <textarea autocomplete="off" autocorrect="off" class="form-control"  name="description" ><?php echo $dbo->description; ?></textarea>
		
                                        </div>
										
                              


                                  

                                    <button class="btn btn-outline-primary float-end" type="submit">
                                        Update Order
                                    </button>
                                </form>
                            </div><!-- card-body -->
                        </div><!-- card -->
                    </div><!-- col-12 -->
                </div><!-- row -->
            </div><!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<script>


// ========== SUGGESTIONS FOR NAME ========== //
jQuery(document).ready(function($) {
    $("#customerName").keyup(function() {
        let query = $(this).val();
        let suggestionBox = "#customerName_suggestions";
        if (query.length > 3) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_name: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item'
                                data-name='${customer.name || ""}'
                                data-phone='${customer.contact_number || ""}'
                                data-email='${customer.email || ""}'
                                data-address='${customer.address || ""}'>
                                ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                            </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
        let selectedAddress = $(this).data("address");

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);
        $("#customer_address").val(selectedAddress);
        $("#customer_shiping_address").val(selectedAddress);

        $(".customer_suggestions").hide();
    });

    // Hide suggestions if click outside
    $(document).click(function(event) {
        if (!$(event.target).closest("#customerName, #customerName_suggestions").length) {
            $("#customerName_suggestions").hide();
        }
    });
});

// ========== SUGGESTIONS FOR PHONE ========== //
jQuery(document).ready(function($) {
    $("#customerphone").keyup(function() {
        let query = $(this).val();
        let suggestionBox = "#customerphone_suggestions";
        if (query.length > 5) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_phone: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item'
                                data-name='${customer.name || ""}'
                                data-phone='${customer.contact_number || ""}'
                                data-email='${customer.email || ""}'
                                data-address='${customer.address || ""}'>
                                ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                            </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
        let selectedAddress = $(this).data("address");

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);
        $("#customer_address").val(selectedAddress);
        $("#customer_shiping_address").val(selectedAddress);

        $(".customer_suggestions").hide();
    });

    $(document).click(function(event) {
        if (!$(event.target).closest("#customerphone, #customerphone_suggestions").length) {
            $("#customerphone_suggestions").hide();
        }
    });
});

// ========== SUGGESTIONS FOR EMAIL ========== //
jQuery(document).ready(function($) {
    $("#customeremail").keyup(function() {
        let query = $(this).val();
        let suggestionBox = "#customeremail_suggestions";
        if (query.length > 4) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { search_customer_query_email: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item'
                                data-name='${customer.name || ""}'
                                data-phone='${customer.contact_number || ""}'
                                data-email='${customer.email || ""}'
                                data-address='${customer.address || ""}'>
                                ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                            </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    });

    $(document).on("click", ".suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
        let selectedAddress = $(this).data("address");

        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);
        $("#customer_address").val(selectedAddress);
        $("#customer_shiping_address").val(selectedAddress);

        $(".customer_suggestions").hide();
    });

    $(document).click(function(event) {
        if (!$(event.target).closest("#customeremail, #customeremail_suggestions").length) {
            $("#customeremail_suggestions").hide();
        }
    });
});


</script>
</body>
</html>