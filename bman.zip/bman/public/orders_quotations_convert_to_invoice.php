<?php
/**
 * Convert Quotation to Project with Barcode Updates
 */

if (!defined('ABSPATH')) {
    exit;
}

header('Content-Type: application/json');

$homeurl = get_site_url();
require_once('bcore.php');

// Include barcode library if not already included
if (!function_exists('barcode')) {
    require_once('barcode_lib.php');
}

/**
 * Generate and upload barcode for orders
 */
function generate_and_upload_barcode_orders($order_id) {
    $upload_dir = wp_upload_dir();
    $barcode_filename = "ORDR_" . $order_id . ".png";
    $barcode_path = $upload_dir['path'] . '/' . $barcode_filename;

    // Generate barcode image
    barcode($barcode_path, "ORDR_" . $order_id, 100, "horizontal", "code128", false, 3);

    if (!file_exists($barcode_path)) {
        return new WP_Error('file_error', 'Barcode file was not created');
    }

    // Prepare attachment
    $filetype = wp_check_filetype($barcode_filename, null);
    $attachment = array(
        'guid' => $upload_dir['url'] . '/' . $barcode_filename,
        'post_mime_type' => $filetype['type'],
        'post_title' => "Barcode for Order " . $order_id,
        'post_status' => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $barcode_path);
    if (is_wp_error($attach_id)) {
        return $attach_id;
    }

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $barcode_path);
    wp_update_attachment_metadata($attach_id, $attach_data);

    return $attach_id;
}

/**
 * Generate and upload barcode for projects
 */
function generate_and_upload_barcode_project($project_id) {
    $upload_dir = wp_upload_dir();
    $barcode_filename = "PRJC_" . $project_id . ".png";
    $barcode_path = $upload_dir['path'] . '/' . $barcode_filename;

    // Generate barcode image
    barcode($barcode_path, "PRJC_" . $project_id, 100, "horizontal", "code128", false, 3);

    if (!file_exists($barcode_path)) {
        return new WP_Error('file_error', 'Barcode file was not created');
    }

    // Prepare attachment
    $filetype = wp_check_filetype($barcode_filename, null);
    $attachment = array(
        'guid' => $upload_dir['url'] . '/' . $barcode_filename,
        'post_mime_type' => $filetype['type'],
        'post_title' => "Barcode for Project " . $project_id,
        'post_status' => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $barcode_path);
    if (is_wp_error($attach_id)) {
        return $attach_id;
    }

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $barcode_path);
    wp_update_attachment_metadata($attach_id, $attach_data);

    return $attach_id;
}

// Main processing
if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb; 
    $id = intval($_GET['id']);

    $response = [
        'success' => false,
        'message' => '',
        'data' => []
    ];

    
        // 1. Get quotation data
        $ob = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM wp_zn_system_quotations WHERE q_id = %d",
                $id
            )
        );

        if (!$ob) {
            throw new Exception("Quotation not found");
        }

        // 2. Update quotation status
        $wpdb->update(
            'wp_zn_system_quotations',
            ['status' => 'Invoice Created'],
            ['q_id' => $id],
            ['%s'],
            ['%d']
        );

        // 3. Handle customer information
        $customer_id = $ob->customer;
        
       

        $customer_info = get_customer_info($customer_id);
        
		
		
		// Decode JSON to associative array
        $data = json_decode($ob->items, true);
        
        // Initialize new array
        $converted = [];
        
        foreach ($data as $item) {
            // Prepare new formatted item
            $newItem = [
                'title' => strtolower($item['item']),
                'id' => is_numeric($item['product_id']) && $item['product_id'] !== "" ? (int)$item['product_id'] : 0,
                'quantity' => (int)$item['quantity'],
                'price' => (float)$item['price'],
                'discount' => 0,
                'total' => (float)$item['total'],
            ];
            
            // Push to converted array
            $converted[] = $newItem;
        }
        

        
          $ar_data = array(
         'type' => 'Invoice',
         'payee' => $customer_info['email'],
          'paid' =>  $ob->g_paid,
          'due' =>  $ob->g_due,
          'amount' =>  $ob->g_total_amount,
          );
    
        $ar_res  = save_ar_data($ar_data);



        // 4. Create new order
        $order_data = [
            'customer_id' => $customer_id,
            'order_status' => 'Project Started',
            'payment_states' => 'N/a',
		    'items' =>  json_encode($converted),
		    'g_paid' =>  $ob->g_paid,
			'g_due'  => $ob->g_due,
	        'g_tax'  =>  $ob->g_tax,
			'g_subtotal' => $ob->g_subtotal,
			'g_total_amount' => $ob->g_total_amount,
			'g_discount' => $ob->g_discount,
			'g_grand_total' => $ob->g_grand_total,
			'billing_address' => $ob->shipping_address,
			'shipping_address' => $ob->shipping_address,
            'ar_id' => $ar_res,
            'created_at' => current_time('mysql')
        ];
        
        $new_order_id = save_order_data($order_data);
    
        $q_update_a = array(    
        'q_id' => $id,
        'order_id' => $new_order_id,
        );
    
          save_quotation_data($q_update_a);
      

        // 5. Generate and update ORDER barcode
        $order_barcode_id = generate_and_upload_barcode_orders($new_order_id);
        $wpdb->update(
            'wp_pos_system_orders',
            ['barcode' => $order_barcode_id],
            ['order_id' => $new_order_id],
            ['%d'],
            ['%d']
        );

     

       
     wp_redirect($homeurl . '/orders/orders/');  } else {
    
    wp_redirect($homeurl . '/orders/quotations/');
  
}