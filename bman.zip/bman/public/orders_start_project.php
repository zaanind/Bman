<?php
/**
 * Convert Quotation to Project with Barcode Updates
 */

if (!defined('ABSPATH')) {
    exit;
}

header('Content-Type: application/json');

$homeurl = get_site_url();
require_once('bcore.php');

// Include barcode library if not already included
if (!function_exists('barcode')) {
    require_once('barcode_lib.php');
}

/**
 * Generate and upload barcode for orders
 */
function generate_and_upload_barcode_orders($order_id) {
    $upload_dir = wp_upload_dir();
    $barcode_filename = "ORDR_" . $order_id . ".png";
    $barcode_path = $upload_dir['path'] . '/' . $barcode_filename;

    // Generate barcode image
    barcode($barcode_path, "ORDR_" . $order_id, 100, "horizontal", "code128", false, 3);

    if (!file_exists($barcode_path)) {
        return new WP_Error('file_error', 'Barcode file was not created');
    }

    // Prepare attachment
    $filetype = wp_check_filetype($barcode_filename, null);
    $attachment = array(
        'guid' => $upload_dir['url'] . '/' . $barcode_filename,
        'post_mime_type' => $filetype['type'],
        'post_title' => "Barcode for Order " . $order_id,
        'post_status' => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $barcode_path);
    if (is_wp_error($attach_id)) {
        return $attach_id;
    }

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $barcode_path);
    wp_update_attachment_metadata($attach_id, $attach_data);

    return $attach_id;
}

/**
 * Generate and upload barcode for projects
 */
function generate_and_upload_barcode_project($project_id) {
    $upload_dir = wp_upload_dir();
    $barcode_filename = "PRJC_" . $project_id . ".png";
    $barcode_path = $upload_dir['path'] . '/' . $barcode_filename;

    // Generate barcode image
    barcode($barcode_path, "PRJC_" . $project_id, 100, "horizontal", "code128", false, 3);

    if (!file_exists($barcode_path)) {
        return new WP_Error('file_error', 'Barcode file was not created');
    }

    // Prepare attachment
    $filetype = wp_check_filetype($barcode_filename, null);
    $attachment = array(
        'guid' => $upload_dir['url'] . '/' . $barcode_filename,
        'post_mime_type' => $filetype['type'],
        'post_title' => "Barcode for Project " . $project_id,
        'post_status' => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $barcode_path);
    if (is_wp_error($attach_id)) {
        return $attach_id;
    }

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $barcode_path);
    wp_update_attachment_metadata($attach_id, $attach_data);

    return $attach_id;
}

// Main processing
if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb; 
    $id = intval($_GET['id']);

    $response = [
        'success' => false,
        'message' => '',
        'data' => []
    ];

    
        // 1. Get quotation data
        $ob = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM wp_zn_system_quotations WHERE order_id = %d",
                $id
            )
        );

        if (!$ob) {
            throw new Exception("Quotation not found");
        }

        // 2. Update quotation status
        $wpdb->update(
            'wp_zn_system_quotations',
            ['status' => 'Project Started'],
            ['q_id' => $id],
            ['%s'],
            ['%d']
        );

        // 3. Handle customer information
        $customer_id = $ob->customer;
        
        if (empty($customer_id)) {
            throw new Exception("No customer associated with this quotation");
        }

        $customer_info = get_customer_info($customer_id);
        if (empty($customer_info)) {
            throw new Exception("Could not retrieve customer information");
        }
		
		
		// Decode JSON to associative array
        $data = json_decode($ob->items, true);
        
        // Initialize new array
        $converted = [];
        
        foreach ($data as $item) {
            // Prepare new formatted item
            $newItem = [
                'title' => strtolower($item['item']),
                'id' => is_numeric($item['product_id']) && $item['product_id'] !== "" ? (int)$item['product_id'] : 0,
                'quantity' => (int)$item['quantity'],
                'price' => (float)$item['price'],
                'discount' => 0,
                'total' => (float)$item['total'],
            ];
            
            // Push to converted array
            $converted[] = $newItem;
        }
        

      


        // 6. Create project (without barcode first)
        $project_data = [
            'customer' => sanitize_email($customer_info['email']),
            'project_title' => sanitize_text_field($ob->title),
            'project_description' => sanitize_textarea_field($ob->description),
            'project_status' => 'Project Started',
            'project_location' => sanitize_text_field($customer_info['address']),
            'order_id' => $id,
            'created_at' => current_time('mysql')
        ];

        $new_project_id = save_project_data($project_data);
        if (!$new_project_id) {
            throw new Exception("Failed to create new project");
        }

        // 7. Generate and update PROJECT barcode
        $project_barcode_id = generate_and_upload_barcode_project($new_project_id);
        if (is_wp_error($project_barcode_id)) {
            throw new Exception('Project barcode generation failed: ' . $project_barcode_id->get_error_message());
        }

        // DIRECTLY UPDATE THE BARCODE IN wp_zn_system_projects
        $barcode_updated = $wpdb->update(
            'wp_zn_system_projects',
            ['barcode' => $project_barcode_id],  // column to update
            ['project_id' => $new_project_id],   // where condition
            ['%d'],                              // data format (integer)
            ['%d']                               // where format (integer)
        );

        if ($barcode_updated === false) {
            throw new Exception("Failed to update project barcode in database");
        }

      
     wp_redirect($homeurl . '/projects/');
    //exit;

} else {

    wp_redirect($homeurl . '/projects/');
    //exit;
}