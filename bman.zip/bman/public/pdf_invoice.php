<?php 







//invoice by details
$invby_name = 'Amuthu ART';
$invby_email = 'admin@amuthuart.online';
$invby_phone_number = '+94782223322';
$invby_address = 'Example Address';




//------------------------------------ Don't edit things bellow this line ------------------------------------


global $wpdb;
$table_name = $wpdb->prefix . 'pos_system_orders';


require_once 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;
use Dompdf\Options;



$homeurl       = get_site_url();
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo 'No ID Found';
   // wp_redirect($homeurl . '/unauthorized');
    exit;
}



$order_id = (int) $_GET['id'];
// Fetch the existing order
$order = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_name} WHERE order_id = %d",
    $order_id
));
if (!$order) {
    echo 'Order not found.';
    exit;
}



$terms_v = $order->terms;

$a_notes = $order->notes;


$old_items = json_decode($order->items, true);
if (!is_array($old_items)) {
    $old_items = [];
}

// (Optional) Fetch the customer to pre-fill name/phone/email
$customer = null;
if (!empty($order->customer_id)) {
    $customer = $wpdb->get_row("
        SELECT * 
        FROM {$wpdb->prefix}pos_system_customers 
        WHERE customer_id = {$order->customer_id}
    ");
}





// Enable options for better CSS support
$options = new Options();
$options->set('defaultFont', 'Arial');
$options->set('chroot', __DIR__);

$dompdf = new Dompdf($options);
$dompdf->setPaper('A4', 'portrait'); 


$html = '<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Invoice</title>
  <style>
    .quotation-header {
      text-align: center;
      font-size: 24px;
      color: #8c3d16;
      font-weight: bold;
      text-transform: uppercase;
      margin-top: 20px;
    }
    
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      font-family: Arial, sans-serif;
      color: #333;
      background-color: #fff;
    }
    
    .page {
      width: 100%;
      min-height: 100vh; 
    }
    
    /* Header (top area) */
    .header {
      overflow: hidden;
      padding: 2rem;
    }
    .header-left {
      float: left;
    }
    .header-left .company-name {
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 0.3rem;
    }
    .header-left .quotation-label {
      font-size: 16px;
      color: #666;
    }
    
    .header-right {
      float: right;
      text-align: right;
    }
    .header-right .quotation-number {
      font-size: 16px;
      font-weight: bold;
      margin-bottom: 0.3rem;
    }
    .header-right .quotation-date {
      font-size: 14px;
      color: #666;
    }
    
    /* Quotation By / Bill To */
    .info-section {
      overflow: hidden;
      padding: 1.5rem 2rem;
    }
.info-block {
    width: 43%;
    display: inline-block;
    vertical-align: top;
    background-color: #8c4d2e3b;
    padding: 1rem;
    box-sizing: border-box;
    height: 200px;
    margin-right: 2%;
    border-radius: 10px;
}


    .info-block:last-child {
      margin-right: 0;
    }
    .info-block h3 {
      font-size: 14px;
      margin-bottom: 0.5rem;
      text-transform: uppercase;
      color: #333;
    }
    .info-block p {
      font-size: 14px;
      color: #666;
      line-height: 1.6;
      margin: 0;
    }
    
    /* Item Table */
    .table-section {
      padding: 0 2rem 2rem 2rem;
    }
    .items-table {
      width: 100%;
      border-collapse: collapse;
      margin: 1rem 0 0 0;
    }
    .items-table th {
      background-color: #8c4d2e;
      color: #fff;
      padding: 0.75rem;
      text-align: left;
      
    }
    .items-table td {
      padding: 0.75rem;
      border-bottom: 1px solid #eee;
      vertical-align: middle;
    }
    th.text-right, .text-right {
      text-align: right;
    }
    
    /* Bottom Section (Terms + Totals side by side) */
    .bottom-section {
      overflow: hidden;
      margin: 0 2rem 2rem 2rem;
    }
    
    /* Terms and Conditions on the left */
    .terms-section {
      width: 48%;
      float: left;
      padding: 2rem;
      box-sizing: border-box;
    }
    .terms-section h4 {
      margin-bottom: 0.5rem;
      font-size: 14px;
      text-transform: uppercase;
      color: #333;
    }
    .terms-section p {
      font-size: 14px;
      color: #666;
      line-height: 18px;
      margin: 0 0 0.5rem 0;
    }
    
    /* Totals section on the right */
    .totals-section {
      width: 48%;
      float: right;
      color: #000; 
      padding: 2rem;
      box-sizing: border-box;
      border-radius: 4px;
    }
    .totals-wrapper {
      max-width: 300px;
      margin-left: auto;
    }
    .total-line {
      overflow: hidden;
      margin-bottom: 0.3rem;
      font-size: 14px;
    }
    .total-line span {
      display: inline-block;
      width: 48%;
    }
    .total-line strong {
      font-weight: 600;
    }
    .discount-value {
      color: #85c664; /* green color for discount */
      font-weight: bold;
    }
    .grand-total {
      margin-top: 0.8rem;
      padding-top: 0.8rem;
      border-top: 2px solid #333;
      font-weight: bold;
    }
    .amount-words {
      margin-top: 1rem;
      font-weight: bold;
      font-size: 14px;
    }
    
    /* Clearfix */
    .clearfix::after {
      content: "";
      display: table;
      clear: both;
    }
	
	.item2 {
    position: absolute;
    left: 425px;
    top: 180px;
    width:38%;
}
.logoimg {
  position: absolute;
  top:20px;

}
  </style>
</head>
<body>';

//$imagePath = __DIR__ .'/logo.png';
//$imageData = file_get_contents($imagePath);
//$base64Image = 'data:image/' . pathinfo($imagePath, PATHINFO_EXTENSION) . ';base64,' . base64_encode($imageData);

$html .=  '
  <div class="page">
    <div class="quotation-header">Invoice</div>
    
    <!-- Header -->
    <div class="header clearfix">
      <div class="header-left">
        
        <img src="'.__DIR__.'/logo.png" alt="Image" width="200px" heigt="100px" class="logoimg">

      </div>
      <div class="header-right">
        <div class="quotation-number">Invoice #'.$order->order_id.'</div>
        <div class="quotation-date">Date: '. date('Y-m-d').'</div>
      </div>
    </div>
    
    <!-- Quotation By / Bill To -->
    <div class="info-section"  style="word-break: break-word;
    overflow-wrap: break-word;">
      <div class="info-block">
        <h3>Invoice By</h3>
        <p>
          Company : '.$invby_name.' <br />
          Email : '.$invby_email.'<br />
          Phone Number : '.$invby_phone_number.'<br />
          Address : '.$invby_address.'<br />
        </p>
      </div>
      <div class="info-block item2">
        <h3>Invoice To</h3>
        <p>
          Customer Name : '.$customer->name.' <br />
          Email : '. $customer->email.'<br />
          Phone Number : '. $customer->phone_number.'<br />
          Address : '. $customer->address.'
        </p>
      </div>
    </div>
    <!-- Items Table -->
    <div class="table-section">
      <table class="items-table">
        <thead>
          <tr>
            <th>Item / Description</th>
            <th>Qty</th>
            <th>Rate</th>
            <th class="text-right">Price</th>
          </tr>
        </thead>
        <tbody>';


        foreach ($old_items as $item) {
        $html .= '   
          <tr>
            <td>'.$item['title'].'</td>
            <td>'.$item['quantity'].'</td>
            <td>'.$item['price'].'</td>
            <td class="text-right">'.$item['total'].'</td>
          </tr>
        ';
        }
 

  $html .= '  </tbody>
  </table>
</div> 
    <!-- Bottom Section: Terms (left) + Totals (right) -->
    <div class="bottom-section clearfix">
      <!-- Terms and Conditions on the left -->
      <div class="terms-section">
        <h4>Terms and Conditions</h4>
       '.$terms_v.' <!-- Additional Notes -->
        <div>
          <h4>Additional Notes</h4>
          <p>
            '.$a_notes.'
          </p>
        </div>
      </div>
      
      <!-- Totals Section -->
      <div class="totals-section">
        <div class="totals-wrapper">
          <div class="total-line">
            <span>Sub Total</span>
            <span>'.$order->g_subtotal.'</span>
          </div>

          <div class="total-line">
          <span>Tax</span>
          <span style="color:red;">+ '.$order->g_tax.'%</span>
        </div>

          <div class="total-line">
            <span>Discount </span>
            <span class="discount-value">- '.$order->g_discount.'%</span>
          </div>
          <div class="total-line grand-total">
            <span>Total</span>
            <span> '.$order->g_grand_total.' LKR</span>
          </div>
          <div class="amount-words">
            Total In Words :  '.numToWords($order->g_grand_total).' rupees.
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>

';

function numToWords($num) {
  $f = new NumberFormatter("en", NumberFormatter::SPELLOUT);
  return ucfirst($f->format($num));
}

// Load the HTML and render the PDF
$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->stream('output.pdf', ['Attachment' => false]); // Opens in browser


/*

// Use default font (Times is used by default in FPDF)
$pdf->SetFont('Arial', '', 10);


// Customer Details
$pageWidth = $pdf->getPageWidth();
$marginRight = 15;
$xPosition = $pageWidth - 100 - $marginRight;

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY($xPosition+45,30);
$pdf->Cell(100, 8, 'Invoice :  #' . $order->order_id, 0, 1, 'L');
$pdf->SetXY($xPosition+45,35);
$pdf->Cell(100, 8, 'Date : ' . date('Y-m-d'), 0, 1, 'L');

$pdf->SetY(50);

//invoice by details
$invby_name = 'Amuthu ART';
$invby_email = 'admin@amuthuart.online';
$invby_phone_number = '+94782223322';
$invby_address = 'Example Address';

//$Y_position = ;

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(95, 8, 'Invoice by', 0, 0, 'L'); 




$pdf->SetFont('Arial', 'B', 12);
$pdf->SetX($xPosition);
$pdf->Cell(95, 8, 'Invoice to', 0, 1, 'L');


// Set Font for content
$pdf->SetFont('Arial', '', 10);

// Move to same Y position
$yStart = $pdf->GetY();
$pdf->SetXY(10, $yStart);
$pdf->Cell(95, 5, 'Company Name : '. $invby_name, 0);
$pdf->Ln();
$pdf->SetX(10);
$pdf->Cell(95, 5, 'Email : '. $invby_email, 0);
$pdf->Ln();
$pdf->SetX(10);
$pdf->Cell(95, 5, 'Phone Number : '. $invby_phone_number, 0);
$pdf->Ln();
$pdf->SetX(10);
$pdf->Cell(95, 5, 'Address : '. $invby_address, 0);
$pdf->Ln();
$pdf->SetX(10);
//$pdf->Cell(95, 5, 'Date: ' . date('Y-m-d'), 0);

// Move to right side
$pdf->SetXY($xPosition, $yStart);
$pdf->Cell(95, 5, 'Customer Name : '. $customer->name, 0);
$pdf->Ln();
$pdf->SetX($xPosition);
$pdf->Cell(95, 5, 'Email : '. $customer->email, 0);
$pdf->Ln();
$pdf->SetX($xPosition);
$pdf->Cell(95, 5, 'Phone Number : '. $customer->phone_number, 0);
$pdf->Ln();
$pdf->SetX($xPosition);
$pdf->Cell(95, 5, 'Address : '. $customer->address, 0);




// Add space
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 12);

// Table Header
$pdf->SetFillColor(254, 119, 1);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(90, 10, 'Item', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Quantity', 1,0,'C',true);
$pdf->Cell(50, 10, 'Price', 1,0,'C',true);
$pdf->Ln(); // New line
$pdf->SetTextColor(0, 0, 0);

$pdf->SetFont('Arial', '', 10);

foreach ($old_items as $item) {
// Table Data
$pdf->Cell(90, 10, $item['title'], 1);
$pdf->Cell(50, 10, $item['quantity'], 1);
$pdf->Cell(50, 10, $item['price'].'x'. $item['quantity'].'='.$item['total'], 1);
$pdf->Ln();




}

/*
$pdf->Ln();

$pdf->Cell(140, 5, '', 0);
$pdf->Cell(50, 6, 'Sub Total : '.$order->g_subtotal, 0);
$pdf->Ln();

//discount
$pdf->Cell(140, 5, '', 0);
$pdf->Cell(50, 6, 'Discount : '. $order->g_discount, 0);
$pdf->Ln();

//discount
$pdf->Cell(140, 5, '', 0);
$pdf->Cell(50, 6, 'Tax : '.  $order->g_tax.'%', 0);
$pdf->Ln();

// Total
$pdf->Cell(140, 5, '', 0);
$pdf->Cell(50, 6, 'Total : '.$order->g_grand_total. ' LKR', 0);
$pdf->Ln(); */

/*/ Total
$pdf->Cell(140, 10, 'Sub Total', 1);
$pdf->Cell(50, 10, $order->g_subtotal, 1);
$pdf->Ln();

//discount
$pdf->Cell(140, 10, 'Discount', 1);
$pdf->Cell(50, 10, $order->g_discount, 1);
$pdf->Ln();

//discount
$pdf->Cell(140, 10, 'Tax', 1);
$pdf->Cell(50, 10, $order->g_tax.'%', 1);
$pdf->Ln();

// Total
$pdf->Cell(140, 10, 'Total', 1);
$pdf->Cell(50, 10, $order->g_grand_total. ' LKR', 1);
$pdf->Ln(); 


// Terms and Conditions
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Terms and Conditions', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 5, '1. Please pay within 15 days from the date of invoice. Overdue interest @ 14% will be charged on delayed payments.', 0, 1);
$pdf->Cell(0, 5, '2. Please quote invoice number when remitting funds.', 0, 1);

// Additional Notes (using MultiCell for wrapping)
$pdf->Ln(5);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Additional Notes', 0, 1);
$pdf->SetFont('Arial', '', 10);
$additionalNotes = "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here'.";
$pdf->MultiCell(0, 5, $additionalNotes);


// Output the PDF
$pdf->Output(); 

// Function to convert numbers to words
function numToWords($num) {
    $f = new NumberFormatter("en", NumberFormatter::SPELLOUT);
    return ucfirst($f->format($num));
} */

?>