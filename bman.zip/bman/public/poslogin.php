<?php
  session_start();
  

   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        

   // $data = $request->get_json_params();
      $username = $_POST['user'];
      $password = $_POST['pass'];

      $homeurl = get_site_url();
	  
      $user = wp_authenticate($username, $password);
      if (is_wp_error($user)) {
		  $_SESSION['login_error'] = 'Invalid username or password';
		  header('location:'.$homeurl.'/sys-login');
		  exit;
          //return new WP_Error('invalid_credentials', 'Invalid username or password', array('status' => 401));
      }

    wp_set_auth_cookie($user->ID);
  
   
//redirect
    
	header('location:'.$homeurl.'');
       exit;
}
		

 include_once('header.php');
 
 ?>
      
<!DOCTYPE html>
<html lang="en">

<head>


 

	<title>Sign In | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<main class="d-flex w-100">
		<div class="container d-flex flex-column">
			<div class="row vh-100">
				<div class="col-sm-10 col-md-8 col-lg-6 col-xl-5 mx-auto d-table h-100">
					<div class="d-table-cell align-middle">

						<div class="text-center mt-4">
							<h1 class="h2">Welcome back!</h1>
							<p class="lead">
								Sign in to your account to continue
							</p>
						</div>

						<div class="card">
							<div class="card-body">
								<div class="m-sm-3">
								<?php
                   if (isset($_SESSION['login_error'])) {
                         $err = $_SESSION['login_error'];
                         unset($_SESSION['login_error']);
                         echo "<p class='lead error text-danger'>".$err."</p>";						 }

								?>
								
									<form method="post">
										<div class="mb-3">
											<label class="form-label">Username</label>
											<input class="form-control form-control-lg" type="text" name="user" placeholder="Enter your username" />
										</div>
										<div class="mb-3">
											<label class="form-label">Password</label>
											<input class="form-control form-control-lg" type="password" name="pass" placeholder="Enter your password" />
										</div>
										<div>
											<!--div class="form-check align-items-center">
												<input id="customControlInline" type="checkbox" class="form-check-input" value="remember-me" name="remember-me" checked>
												<label class="form-check-label text-small" for="customControlInline">Remember me</label>
											</div-->
										</div>
										<div class="d-grid gap-2 mt-3">
											<button type="submit" class="btn btn-lg btn-primary">Sign in</button>
										</div>
									</form>
								</div>
							</div>
						</div>
						<!--div class="text-center mb-3">
							Don't have an account? <a href="#">Please contact admin</a>
						</div-->
					</div>
				</div>
			</div>
		</div>
	</main>

	<script src="js/app.js"></script>

</body>

</html>