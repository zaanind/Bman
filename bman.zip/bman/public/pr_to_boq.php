<?php
// pr_to_boq.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();


include_once('bcore.php');


if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb; 
    $id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // 1. Check if the quotation exists and retrieve its details
    $pr = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM wp_zn_system_prs WHERE pr_id = %d;",
            $id
        )
    );

    if ($pr) {
        $wpdb->update('wp_zn_system_prs', ['status' => 'Boq Created'], ['pr_id' => $id]);

        

        $customer_id = $pr->customer;

        if (!empty($customer_id)) {
            $customer_info = get_customer_info($customer_id);
        }


        $boq_data =   array(
                'pr_id' => $id,
                'customer_id'       => $customer_id, 
                'title'      => $pr->title,
                'description'  => $pr->description,
                'items' => '[]',
                'shipping_address'  => $customer_info['address'],
                'billing_address'   => $customer_info['address'],
                'g_total_amount' => '0',
            );


        $new_order_id  = save_boq_data($boq_data);

        $prs_data  = array(
            'pr_id' => $id,
            'status'       => 'Boq Created',
        );

        $inserted = save_prs_data($prs_data);
        


        // After insertion, you can redirect wherever you want
        wp_redirect($homeurl . '/orders/boqs');
        exit;

    } else {
        echo "not found.";
    }
} else {
    echo 'No ID provided.';
}
?>