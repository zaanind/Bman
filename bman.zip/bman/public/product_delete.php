<?php

$homeurl = get_site_url();

if(isset($_GET['id']) && !empty($_GET['id'])) {
	global $wpdb;
	$query = $_GET['id'];
    

	$sql = $wpdb->prepare("SELECT product_id,image FROM wp_pos_system_inventory_products WHERE product_id='".$query."';");
	$result = $wpdb->get_results($sql);

	$image_ob = json_decode($result[0]->image);
	$media_id = $image_ob->id; 
    wp_delete_attachment($media_id, true); // true means force delete (permanent)

   $sql = $wpdb->prepare("DELETE FROM wp_pos_system_inventory_products WHERE product_id='%d';",$query);
   $result = $wpdb->get_results($sql);
   status_header(200);
   wp_redirect($homeurl . '/inventory/products');
   exit;





} else {

  echo 'no info provided';

}
  

?>