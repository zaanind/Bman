<?php
session_start();


$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator',);


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}



if(isset($_GET['id']) && !empty($_GET['id'])) {
	global $wpdb;
	$query = $_GET['id'];
    

	$sql = $wpdb->prepare("SELECT * FROM wp_pos_system_inventory_products WHERE product_id='%d';",$query );
	$result = $wpdb->get_results($sql);

	
	
}


    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	  global $wpdb;
	   $table_name = $wpdb->prefix . 'pos_system_inventory_products';
        
      $homeurl = get_site_url();

      $pname = $_POST['name'];
	  $pdescription = $_POST['description'];
	  $pquantity = $_POST['quantity'];
	  $pbrand = $_POST['brand']; 
	  $pcategory = $_POST['category'];
	//  $pstates = $_POST['states'];
	  $pprice = $_POST['price'];

  if (isset($_FILES['image'])) {

	  	    require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            $file = $_FILES['image'];
            $upload = wp_handle_upload($file, ['test_form' => false]);
            if (isset($upload['error'])) { 
               $_SESSION['error'] = 'Image Upload Failed';
		       header('location:'.$homeurl.'/inventory/products/add');
		       exit;


              }

                  // Insert into media library
            $attachment = array(
               'guid'           => $upload['url'],
               'post_mime_type' => $upload['type'],
               'post_title'     => sanitize_file_name($file['name']),
               'post_content'   => '',
               'post_status'    => 'inherit',
                );
            $attach_id = wp_insert_attachment($attachment, $upload['file']);
            $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
            wp_update_attachment_metadata($attach_id, $attach_data);
            $rep =  [
                      'success' => true,
                      'id'      => $attach_id,
                      'url'     => wp_get_attachment_url($attach_id),
                  ];
            $json_image_info = json_encode($rep);
 }
	  
      
	  
	
  
 
    $data = array(
        'product_name' => $pname,
        'brand_name' => $pbrand,
	    'category' => $pcategory,
	    'price' => $pprice,
	   // 'states' => $pstates, 
        'quantity' => $pquantity,
		'product_description' => $pdescription,
		'image' => $json_image_info,
      );
	
	
    $inserted = $wpdb->insert($table_name, $data);

	  
        if ($inserted === false) {
		  $_SESSION['error'] = 'Failed';
		  header('location:'.$homeurl.'/inventory/products/add/');
		  exit;
      

	  }


    
	header('location:'.$homeurl.'/inventory/products/');
}
	

		


?>

<!DOCTYPE html>
<html lang="en">
<head>
   
   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title>Product Edit | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



			<main class="content">

	        <?php
                   if (isset($_SESSION['error'])) {
                         $err = $_SESSION['error'];
                         unset($_SESSION['error']);?>
						 
						 			<div class="alert alert-danger alert-dismissible" role="alert">
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											<div class="alert-message">
												<strong>Error:</strong> Failed to add item
											</div>
										</div>

						<?php }	?>
								
					
										
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Product Edit</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
						
								<div class="card-body">
								       
                                      <form method="POST" action="<?php echo get_site_url(); ?>/inventory/products/edit" enctype="multipart/form-data" onsubmit="return validateForm()">
                                    
                                    
                                    
    									<div class="mb-3">
                                            <label  class="form-label">Name:</label>
                                            <input type="text" class="form-control"  name="name"  value="<?php echo $result[0]->product_name; ?>">
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Description:</label>
                                            <input type="text" class="form-control"  name="description"  value="<?php echo $result[0]->product_description; ?>">
                                        </div>

                                        <div class="mb-3">
                                            <label  class="form-label">Image:</label></br>
											<?php 
											 $image_url = "";
     	                                     $image_link = json_decode($result[0]->image);
     	                                     if(isset($image_link->id)){
     	                                     
     	                                     $image = wp_get_attachment_image_src($image_link->id, 'full');
     	                                     $image_url = $image ? $image[0] : $image_link->url;} 	
											?>
                                            <img src="<?php echo $image_url ?>" width="225px"></img>
										   <input class="form-control form-control-lg" id="formFileLg" type="file" name="image">
                                        
											
											
                                        </div>
										

										
										<div class="mb-3 ">
                                            <label  class="form-label">Brand:</label>
                                            
										    <select class="form-control" name="brand" required >
											<?php 
											global $wpdb;
											$brand_list =  $wpdb->get_results("SELECT * FROM wp_pos_system_brands");
										    echo "<option>Select</option>";
											
											foreach ($brand_list as $row) { 
											
											
											if($result[0]->brand_name == $row->brand_name){
											 echo "<option selected>". $row->brand_name ."</option>";
												
											} else {
											
											 echo "<option>". $row->brand_name ."</option>"; }
											
											}
											?>
											    
											 

											</select>
                                        </div>
										
										
										<div class="mb-3 ">
                                            <label  class="form-label">Category:</label>
                                        	
											 <select class="form-control" name="category" required >
											  	<?php 
											global $wpdb;
											$cat_list =  $wpdb->get_results("SELECT * FROM wp_pos_system_categories");
										    echo "<option>Select</option>";
											foreach ($cat_list as $row) { 
											
																						
											if($result[0]->category == $row->category){
											 echo "<option selected>". $row->category ."</option>";
												
											} else {
											
											 echo "<option>". $row->category ."</option>"; }
											
											
											}
											?>

											</select>
											
                                        </div>
										
										
										<!--div class="mb-3 ">
                                            <label  class="form-label">States:</label>
                                            <input type="text" class="form-control"  name="states" required>
                                        </div-->
										
										<div class="mb-3 col-lg-3">
                                            <label  class="form-label">Quantity:</label>
                                            <input type="number" class="form-control"  name="quantity" required  value="<?php echo $result[0]->quantity; ?>">
                                        </div>
										
										<div class="mb-3 col-lg-3">
                                            <label  class="form-label">Price:</label>
                                            <input type="number" class="form-control"  name="price" required value="<?php echo $result[0]->price; ?>">
                                        </div>
								<button class="btn btn-outline-primary float-end"> Add</button>
												
										
								</form>		
										
							</div>
							</div>
						</div>
					</div>

				</div>
			</main>


			
			
			
			
			<?php include_once('footer.php');?>
		</div>
	</div>

	

	
</body>

</html>