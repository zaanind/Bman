<?php
session_start();


$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator',);


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}



if(isset($_GET['id']) && !empty($_GET['id'])) {
	global $wpdb;
	$query = $_GET['id'];
    

	$sql = $wpdb->prepare("SELECT * FROM wp_pos_system_inventory_products WHERE product_id='%d';",$query );
	$result = $wpdb->get_results($sql);

	
	
}


 

		


?>

<!DOCTYPE html>
<html lang="en">
<head>
   
   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title>Product View | <?php echo get_bloginfo( 'name' ); ?></title>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



			<main class="content">

								
								
					
										
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Product View</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
						
								<div class="card-body">
								       
                                     
                                    
    									<div class="mb-3">
                                            <label  class="form-label">Name:</label>
                                            <input type="text" class="form-control"  name="name" readonly value="<?php echo $result[0]->product_name; ?>">
                                        </div>
										
										<div class="mb-3">
                                            <label  class="form-label">Description:</label>
                                            <input type="text" class="form-control"  name="description" readonly value="<?php echo $result[0]->product_description; ?>">
                                        </div>

                                        <div class="mb-3">
                                            <label  class="form-label">Image:</label></br>
											<?php 
											 $image_url = "";
     	                                     $image_link = json_decode($result[0]->image);
     	                                     if(isset($image_link->id)){
     	                                     
     	                                     $image = wp_get_attachment_image_src($image_link->id, 'full');
     	                                     $image_url = $image ? $image[0] : $image_link->url;}
											
											
											
											?>
                                            <img src="<?php echo $image_url ?>" width="225px"></img>
                                        </div>
										

										
										<div class="mb-3 ">
                                            <label  class="form-label">Brand:</label>
                                            <!--input type="text" class="form-control"  name="brand" required-->
											
										    <select class="form-control" name="brand" required disabled>
											<?php 
											global $wpdb;
											$brand_list =  $wpdb->get_results("SELECT * FROM wp_pos_system_brands");
										    echo "<option>Select</option>";
											
											foreach ($brand_list as $row) { 
											
											
											if($result[0]->brand_name == $row->brand_name){
											 echo "<option selected>". $row->brand_name ."</option>";
												
											} else {
											
											 echo "<option>". $row->brand_name ."</option>"; }
											
											}
											?>
											    
											 

											</select>
                                        </div>
										
										
										<div class="mb-3 ">
                                            <label  class="form-label">Category:</label>
                                            <!--input type="text" class="form-control"  name="category" required-->
											
											 <select class="form-control" name="category" required disabled>
											  	<?php 
											global $wpdb;
											$cat_list =  $wpdb->get_results("SELECT * FROM wp_pos_system_categories");
										    echo "<option>Select</option>";
											foreach ($cat_list as $row) { 
											
																						
											if($result[0]->category == $row->category){
											 echo "<option selected>". $row->category ."</option>";
												
											} else {
											
											 echo "<option>". $row->category ."</option>"; }
											
											
											}
											?>

											</select>
											
                                        </div>
										
										
										<!--div class="mb-3 ">
                                            <label  class="form-label">States:</label>
                                            <input type="text" class="form-control"  name="states" required>
                                        </div-->
										
										<div class="mb-3 col-lg-3">
                                            <label  class="form-label">Quantity:</label>
                                            <input type="number" class="form-control"  name="quantity" required readonly value="<?php echo $result[0]->quantity; ?>">
                                        </div>
										
										<div class="mb-3 col-lg-3">
                                            <label  class="form-label">Price:</label>
                                            <input type="number" class="form-control"  name="price" required readonly value="<?php echo $result[0]->price; ?>">
                                        </div>
										
							</div>
							</div>
						</div>
					</div>

				</div>
			</main>


			
			
			
			
			<?php include_once('footer.php');?>
		</div>
	</div>

	

	
</body>

</html>