<?php 
session_start();

// Role/permission checks
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator', 'employee'); // Adjust roles as needed
$has_allowed_role = false;

foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    wp_redirect(get_site_url() . '/unauthorized');
    exit;
}

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $project_id = intval($_GET['id']); // Ensure the ID is an integer

    // Define the projects table name
    $table_name = $wpdb->prefix . 'zn_system_projects';

    // Fetch project details
    $project = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE project_id = %d", $project_id));
    
    if ($project) {
        // Delete gallery attachments if they exist
        if (!empty($project->project_gallery)) {
            $gallery = json_decode($project->project_gallery, true);
            if (is_array($gallery)) {
                foreach ($gallery as $img) {
                    if (!empty($img['attachment_id'])) {
                        wp_delete_attachment($img['attachment_id'], true);
                    }
                }
            }
        }
        
        // Delete cost attachments if they exist
        if (!empty($project->project_cost)) {
            $costs = json_decode($project->project_cost, true);
            if (is_array($costs)) {
                foreach ($costs as $cost) {
                    if (!empty($cost['attachment_id'])) {
                        wp_delete_attachment($cost['attachment_id'], true);
                    }
                    if (!empty($cost['purchase_attachment_id'])) {
                        wp_delete_attachment($cost['purchase_attachment_id'], true);
                    }
                }
            }
        }
        
        // Finally, delete the project row from the database
        $wpdb->delete($table_name, array('project_id' => $project_id), array('%d'));

        status_header(200);
        wp_redirect($homeurl . '/projects');
        exit;
    } else {
        echo "Project not found.";
    }
} else {
    echo 'No ID provided';
}
?>
