<!DOCTYPE html> 
<html lang="en">

<head>
   <?php
   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php');

   $wpuser_ob = wp_get_current_user();
   $roles = (array) $wpuser_ob->roles;
   $role = $roles[0];
   $permission = ($role === 'administrator');

   // Get current WordPress user ID, which is the employee ID
   $current_employee_id = get_current_user_id();
   ?>
   <title>Projects | <?php echo get_bloginfo('name'); ?></title>
</head>

<body>
   <div class="wrapper">
      <?php include_once('sidebar.php'); ?>
      <div class="main">
         <?php include_once('navbar.php'); ?>

         <main class="content">
            <div class="container-fluid p-0">
               <?php if ($permission) { ?>
                  <a href="<?php echo get_site_url(); ?>/projects/add" class="btn btn-primary float-end mt-n1">
                     <i class="fas fa-plus"></i> New Project
                  </a>
               <?php } ?>

               <div class="mb-3">
                  <h1 class="h3 d-inline align-middle">Projects</h1>
               </div>

               <div class="row">
                  <div class="col-12">
                     <div class="card">
                        <div class="card-body">
                           <table id="datatables-reponsive" class="table table-striped" style="width:100%">
                              <thead>
                                 <tr>
                                    <th>ID</th>
                                    <th>Title</th>      
                                    <th>Customer</th>      
                                    <th>Status</th>      
                                    <th>Action</th>
                                 </tr>
                              </thead>

                              <tbody>
                              <?php
                              global $wpdb;
                              $query = "SELECT project_id, project_title, project_status, customer, project_employees FROM wp_zn_system_projects";
                              $projects = $wpdb->get_results($query);

                              foreach ($projects as $row) {
                                  $project_employees = json_decode($row->project_employees, true);

                                  // Ensure project_employees is an array and check if the current employee is assigned
                                  if ($permission || (is_array($project_employees) && in_array($current_employee_id, $project_employees))) {
                                      echo '<tr>';
                                      echo "<td>{$row->project_id}</td>";
                                      echo "<td>{$row->project_title}</td>";
                                      echo "<td>{$row->customer}</td>";
                                      echo "<td>{$row->project_status}</td>";

                                      echo "<td><div class='btn-group'>
                                          <button type='button' class='btn btn-primary dropdown-toggle' data-bs-toggle='dropdown' aria-expanded='false'>Actions</button>
                                          <ul class='dropdown-menu'>";

                                      echo "<li><a class='dropdown-item' href='" . get_site_url() . "/projects/gallery?id={$row->project_id}'>Gallery</a></li>";
                                      echo "<li><a class='dropdown-item' href='" . get_site_url() . "/projects/cost?id={$row->project_id}'>Cost</a></li>";
                                      echo "<li><a class='dropdown-item' href='" . get_site_url() . "/projects/resources?id={$row->project_id}'>Resources</a></li>";
                                      echo "<li><a class='dropdown-item' href='" . get_site_url() . "/projects/stocks?id={$row->project_id}'>Stocks</a></li>";
                                      echo "<li><a class='dropdown-item' href='" . get_site_url() . "/projects/view?id={$row->project_id}'>View</a></li>";

                                      if ($permission) {
                                          echo "<li><a class='dropdown-item' href='" . get_site_url() . "/projects/edit?id={$row->project_id}'>Edit</a></li>";
                                          echo "<li><a class='dropdown-item' href='" . get_site_url() . "/projects/delete?id={$row->project_id}'>Delete</a></li>";
                                      }

                                      echo "</ul></div></td>";
                                      echo '</tr>';
                                  }
                              }
                              ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </main>

         <?php include_once('footer.php'); ?>
      </div>
   </div>

   <script>
      document.addEventListener("DOMContentLoaded", function() {
         $("#datatables-reponsive").DataTable({ responsive: true });
      });
   </script>
</body>

</html>
