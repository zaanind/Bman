<?php
session_start();

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator',);

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

include_once('barcode_lib.php');
// Function to generate a barcode, upload it to the Media Library, and return the attachment ID
function generate_and_upload_barcode($info_id) {
    $upload_dir = wp_upload_dir();
    $barcode_filename = "PRJC_" . $info_id . ".png";
    $barcode_path = $upload_dir['path'] . '/' . $barcode_filename;

    // Generate Barcode
    barcode($barcode_path, "PRJC_" . $info_id, 100, "horizontal", "code128", false, 3);

    if (!file_exists($barcode_path)) {
        return new WP_Error('barcode_generation_failed', 'Failed to generate barcode.');
    }

    // Upload to Media Library
    $filetype = wp_check_filetype($barcode_filename, null);
    $attachment = array(
        'guid'           => $upload_dir['url'] . '/' . $barcode_filename,
        'post_mime_type' => $filetype['type'],
        'post_title'     => "Barcode for Projects " . $info_id,
        'post_content'   => '',
        'post_status'    => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $barcode_path);

    if (is_wp_error($attach_id)) {
        return $attach_id;
    }

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $barcode_path);
    wp_update_attachment_metadata($attach_id, $attach_data);

    return $attach_id;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    global $wpdb;
    $table_name = $wpdb->prefix . 'zn_system_projects';

    $homeurl = get_site_url();

    $title = $_POST['title'];
    $description = $_POST['description'];
    $customer = $_POST['customer'];
    $location = $_POST['location'];
    $employee = $_POST['employee'];

    $data = array(
        'project_title' => $title,
        'project_description' => $description,
        'project_status' => 'pending',
        'project_location' => $location,
        'customer' => $customer,
        'project_employees' => $employee,
    );

    $inserted = $wpdb->insert($table_name, $data);

    // Get the newly inserted order ID
    $info_id = $wpdb->insert_id;
    // Generate and upload the barcode
    $barcode_attachment_id = generate_and_upload_barcode($info_id);
    if (!empty($barcode_attachment_id)) {
        // Update the order with the barcode attachment ID
        $wpdb->update($table_name, ['barcode' => $barcode_attachment_id], ['project_id' => $info_id]);
    }

    if ($inserted === false) {
        $_SESSION['error'] = 'Failed';
        header('location:' . $homeurl . '/projects/add');
        exit;
    }

    header('location:' . $homeurl . '/projects');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    include_once('header.php');
    $active_page = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php'); ?>
    <title>Add Project | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>
        <main class="content">
            <?php
            if (isset($_SESSION['error'])) {
                $err = $_SESSION['error'];
                unset($_SESSION['error']); ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <div class="alert-message">
                        <strong>Error:</strong> Failed to add item
                    </div>
                </div>
            <?php } ?>
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Add New Project</h1>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <form method="POST" action="<?php echo get_site_url(); ?>/projects/add/" enctype="multipart/form-data" onsubmit="return validateForm()">
                                    <div class="mb-3">
                                        <label class="form-label">Title:</label>
                                        <input type="text" class="form-control" name="title" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Description:</label>
                                        <input type="text" class="form-control" name="description">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Customer Name:</label>
                                        <input type="text" class="form-control" id="customerName" name="customername" autocomplete="off">
                                        <div id="customerName_suggestions" class="customer_suggestions"></div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Customer Phone Number:</label>
                                        <input type="text" class="form-control" id="customerphone" name="customerphone" autocomplete="off">
                                        <div id="customerphone_suggestions" class="customer_suggestions"></div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Customer Email:</label>
                                        <input type="text" class="form-control" id="customeremail" name="customer" autocomplete="off">
                                        <div id="customeremail_suggestions" class="customer_suggestions"></div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Location:</label>
                                        <input type="text" class="form-control" name="location">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Employee:</label>
                                        <input type="hidden" name="employee" id="employee_ids">
                                        <input type="text" class="form-control" id="employeeSearch" autocomplete="off">
                                        <div id="employee_suggestions" class="customer_suggestions" style="display:none;"></div>
                                        <div id="selectedEmployees" style="margin-bottom:20px;"></div>
                                    </div>
                                    <button class="btn btn-outline-primary float-end">Add</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <?php include_once('footer.php'); ?>
    </div>
</div>

<script>
$(document).ready(function() {
    function fetchCustomerData(fieldId, queryKey) {
        let query = $(fieldId).val();
        let suggestionBox = fieldId + "_suggestions";

        if (query.length > 3) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { [queryKey]: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item'
                                            data-name='${customer.name || ""}'
                                            data-phone='${customer.contact_number || ""}'
                                            data-email='${customer.email || ""}'
                                            data-address='${customer.address || ""}'>
                                            ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                                       </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    }

    // Event listeners for Customer fields:
    $("#customerName").keyup(function() {
        fetchCustomerData("#customerName", "search_customer_query_name");
    });
    $("#customerphone").keyup(function() {
        fetchCustomerData("#customerphone", "search_customer_query_phone");
    });
    $("#customeremail").keyup(function() {
        fetchCustomerData("#customeremail", "search_customer_query_email");
    });

    // Customer suggestion click handler (only applies to customer suggestions containers)
    $(document).on("click", "#customerName_suggestions .suggestion-item, #customerphone_suggestions .suggestion-item, #customeremail_suggestions .suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);
        $(".customer_suggestions").hide();
    });

    // Hide customer suggestions when clicking outside customer fields
    $(document).click(function(event) {
        if (!$(event.target).closest(".customer_suggestions, #customerName, #customerphone, #customeremail").length) {
            $(".customer_suggestions").hide();
        }
    });
});
</script>

<script>
$(document).ready(function() {
    // Array to hold the selected employees (each with id and name)
    let selectedEmployees = [];

    // Function to update the hidden field and display the selected employees
    function updateSelectedEmployees() {
        $('#employee_ids').val(JSON.stringify(selectedEmployees.map(emp => emp.id)));
        let displayHtml = '';
        selectedEmployees.forEach(emp => {
            displayHtml += `<div class="selected-employee" data-id="${emp.id}" style="padding:5px; border:1px solid #ddd; margin:5px; display:inline-block;">
                                ${emp.name} 
                                <button type="button" class="remove-employee" data-id="${emp.id}" style="color:red; border:none; background:none;">&times;</button>
                            </div>`;
        });
        $('#selectedEmployees').html(displayHtml);
    }

    // Employee search keyup event: search when input length is > 3
    $('#employeeSearch').on('keyup', function() {
        let query = $(this).val();
        if (query.length > 3) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api", // API endpoint for employee search
                method: "POST",
                data: { search_employee_query_name: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(employee => {
                            suggestions += `<div class="suggestion-item" 
                                                data-id="${employee.id}" 
                                                data-name="${employee.name}" 
                                                style="padding:5px; cursor:pointer; border-bottom:1px solid #eee;">
                                                ${employee.name} - ${employee.email} | ${employee.mobile}
                                            </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item' style='padding:5px;'>No results found</div>";
                    }
                    $('#employee_suggestions').html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.error("Error:", error);
                }
            });
        } else {
            $('#employee_suggestions').hide();
        }
    });

    // Employee suggestion click handler (only for employee suggestions)
    $(document).on('click', '#employee_suggestions .suggestion-item', function() {
        let id = $(this).data('id');
        let name = $(this).data('name');

        // Check if the employee is already selected
        if (!selectedEmployees.some(emp => emp.id === id)) {
            selectedEmployees.push({ id: id, name: name });
        }

        updateSelectedEmployees();
        $('#employeeSearch').val('');
        $('#employee_suggestions').hide();
    });

    // Allow removal of selected employee from the list
    $(document).on('click', '.remove-employee', function() {
        let id = $(this).data('id');
        selectedEmployees = selectedEmployees.filter(emp => emp.id !== id);
        updateSelectedEmployees();
    });

    // Hide employee suggestions when clicking outside the employee search area
    $(document).click(function(event) {
        if (!$(event.target).closest("#employeeSearch, #employee_suggestions").length) {
            $('#employee_suggestions').hide();
        }
    });
});
</script>

</body>
</html>
