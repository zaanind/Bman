<?php 
session_start();

// Role/permission checks
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator', 'employee');
$has_allowed_role = false;

foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    wp_redirect(get_site_url() . '/unauthorized');
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'zn_system_projects';

// Get project ID
$project_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$project_id) {
    wp_redirect(get_site_url() . '/projects');
    exit;
}

// Fetch the project
$project = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE project_id = %d", $project_id));
if (!$project) {
    wp_redirect(get_site_url() . '/projects');
    exit;
}

// Decode existing cost JSON
$project_cost_data = !empty($project->project_cost) ? json_decode($project->project_cost, true) : [];
if (!is_array($project_cost_data)) {
    $project_cost_data = [];
}

// If form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cost_description = sanitize_text_field($_POST['cost_description']);
    $cost_amount      = floatval($_POST['cost_amount']);
    $spent_notes      = sanitize_text_field($_POST['spent_notes']);

    // Handle optional bill file upload using WordPress Media Library
    $bill_attachment_id = "";
    if (isset($_FILES['bill_file']) && $_FILES['bill_file']['error'] === UPLOAD_ERR_OK) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $upload_overrides = array('test_form' => false);
        $movefile = wp_handle_upload($_FILES['bill_file'], $upload_overrides);
        if ($movefile && !isset($movefile['error'])) {
            $filename = $movefile['file'];
            $attachment = array(
                'guid'           => $movefile['url'],
                'post_mime_type' => $movefile['type'],
                'post_title'     => sanitize_file_name(basename($filename)),
                'post_content'   => '',
                'post_status'    => 'inherit'
            );
            $bill_attachment_id = wp_insert_attachment($attachment, $filename);
            $attachment_data = wp_generate_attachment_metadata($bill_attachment_id, $filename);
            wp_update_attachment_metadata($bill_attachment_id, $attachment_data);
        }
    }

    // Handle optional purchase file upload using WordPress Media Library
    $purchase_attachment_id = "";
    if (isset($_FILES['purchase_file']) && $_FILES['purchase_file']['error'] === UPLOAD_ERR_OK) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $upload_overrides = array('test_form' => false);
        $movefile = wp_handle_upload($_FILES['purchase_file'], $upload_overrides);
        if ($movefile && !isset($movefile['error'])) {
            $filename = $movefile['file'];
            $attachment = array(
                'guid'           => $movefile['url'],
                'post_mime_type' => $movefile['type'],
                'post_title'     => sanitize_file_name(basename($filename)),
                'post_content'   => '',
                'post_status'    => 'inherit'
            );
            $purchase_attachment_id = wp_insert_attachment($attachment, $filename);
            $attachment_data = wp_generate_attachment_metadata($purchase_attachment_id, $filename);
            wp_update_attachment_metadata($purchase_attachment_id, $attachment_data);
        }
    }

    // Build a cost entry (store both attachment IDs)
    $entry = [
        'description'            => $cost_description,
        'amount'                 => $cost_amount,
        'notes'                  => $spent_notes,
        'attachment_id'          => $bill_attachment_id,
        'purchase_attachment_id' => $purchase_attachment_id,
        'date'                   => date('Y-m-d H:i:s')
    ];

    // Push new cost entry to array
    $project_cost_data[] = $entry;

    // Deduct cost from project_credit.
    $current_credit = floatval($wpdb->get_var($wpdb->prepare("SELECT project_credit FROM $table_name WHERE project_id = %d", $project_id)));
    $new_credit = $current_credit - $cost_amount;

    // Update the project with new cost data and updated credit
    $wpdb->update(
        $table_name,
        array(
            'project_cost'   => json_encode($project_cost_data),
            'project_credit' => $new_credit
        ),
        array('project_id' => $project_id)
    );

    wp_redirect(get_site_url() . '/projects/cost?id=' . $project_id);
    exit;
}

// If a delete is requested
if (isset($_GET['del'])) {
    $del_index = intval($_GET['del']);
    if (isset($project_cost_data[$del_index])) {
        $cost_to_delete = $project_cost_data[$del_index];
        $refund_amount = floatval($cost_to_delete['amount']);

        // Delete the bill attachment if it exists
        if (!empty($cost_to_delete['attachment_id'])) {
            wp_delete_attachment($cost_to_delete['attachment_id'], true);
        }
        // Delete the purchase attachment if it exists
        if (!empty($cost_to_delete['purchase_attachment_id'])) {
            wp_delete_attachment($cost_to_delete['purchase_attachment_id'], true);
        }

        unset($project_cost_data[$del_index]);
        $project_cost_data = array_values($project_cost_data);

        // Refund the cost by adding it back to project_credit.
        $current_credit = floatval($wpdb->get_var($wpdb->prepare("SELECT project_credit FROM $table_name WHERE project_id = %d", $project_id)));
        $new_credit = $current_credit + $refund_amount;
        $wpdb->update(
            $table_name,
            array(
                'project_cost'   => json_encode($project_cost_data),
                'project_credit' => $new_credit
            ),
            array('project_id' => $project_id)
        );
    }
    wp_redirect(get_site_url() . '/projects/cost?id=' . $project_id);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = 'projects';
    include_once('header.php');
    ?>
    <title>Project Cost</title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Project Cost (ID: <?php echo $project_id; ?>)</h1>

                <div class="card">
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label">Cost Description</label>
                                <input type="text" class="form-control" name="cost_description" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Amount</label>
                                <input type="number" step="0.01" class="form-control" name="cost_amount" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Notes</label>
                                <input type="text" class="form-control" name="spent_notes">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Upload Bill/Receipt (optional)</label>
                                <input type="file" class="form-control" name="bill_file">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Upload Purchased Items Image (optional)</label>
                                <input type="file" class="form-control" name="purchase_file">
                            </div>
                            <button type="submit" class="btn btn-primary">Add Cost</button>
                        </form>
                    </div>
                </div>

                <!-- Display existing cost entries -->
                <div class="mt-4">
                    <h5> Costs</h5>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Amount</th>
                                <th>Notes</th>
                                <th>Bill File</th>
                                <th>Item Image</th>
                                <th>Date</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $total_cost = 0;
                        if (!empty($project_cost_data)) {
                            foreach ($project_cost_data as $index => $cost) {
                                $total_cost += floatval($cost['amount']);
                                echo "<tr>";
                                echo "<td>" . esc_html($cost['description']) . "</td>";
                                echo "<td>$" . number_format($cost['amount'], 2) . "</td>";
                                echo "<td>" . esc_html($cost['notes']) . "</td>";
                                
                                // Display bill file link if exists
                                if (!empty($cost['attachment_id'])) {
                                    $attachment_url = wp_get_attachment_url($cost['attachment_id']);
                                    echo "<td><a href='" . esc_url($attachment_url) . "' target='_blank'>View File</a></td>";
                                } else {
                                    echo "<td>-</td>";
                                }
                                
                                // Display purchase image link if exists
                                if (!empty($cost['purchase_attachment_id'])) {
                                    $purchase_url = wp_get_attachment_url($cost['purchase_attachment_id']);
                                    echo "<td><a href='" . esc_url($purchase_url) . "' target='_blank'>View Image</a></td>";
                                } else {
                                    echo "<td>-</td>";
                                }
                                
                                echo "<td>" . esc_html($cost['date']) . "</td>";
                                echo "<td><a class='btn btn-danger btn-sm' href='" . get_site_url() . "/projects/cost?id=" . $project_id . "&del=" . $index . "' 
                                        onclick=\"return confirm('Delete this cost entry?');\">Delete</a></td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>No cost entries yet.</td></tr>";
                        }
                        ?>
                        </tbody>
                    </table>
                    <h5>Total Cost: $<?php echo number_format($total_cost, 2); ?></h5>
                </div>
            </div>
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>
</body>
</html>
