<?php
session_start();

// 1) Permission checks
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator');
$has_allowed_role = false;

foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2) Get the Project ID from the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // No project ID -> redirect to list
    wp_redirect($homeurl . '/projects');
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'zn_system_projects';
$project_id = intval($_GET['id']);

// Fetch the existing project
$project = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM $table_name WHERE project_id = %d", $project_id)
);

$customer_db_res = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM wp_pos_system_customers WHERE email = %d", $project->customer)
);

if (!$project) {
    // Invalid project -> redirect
    wp_redirect($homeurl . '/projects');
    exit;
}

// Decode existing employee selection (assumed stored as a JSON array)
$selectedEmployees = array();
if (!empty($project->project_employees)) {
    $selectedEmployees = json_decode($project->project_employees, true);
    
    if (!is_array($selectedEmployees)) {
        $selectedEmployees = array();
    }
}

// 3) Handle the POST update form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the updated data
    $title       = sanitize_text_field($_POST['title']);
    $description = sanitize_text_field($_POST['description']);
    $customer    = sanitize_text_field($_POST['customer']);
    $location    = sanitize_text_field($_POST['location']);
    $employee    = sanitize_text_field($_POST['employee']);

    // (Optional) If you want to allow editing status:
    $status   = sanitize_text_field($_POST['project_status']); 

    $data = array(
        'project_title'       => $title,
        'project_description' => $description,
        'customer'            => $customer,
        'project_location'    => $location,
        'project_employees'   => $employee,
        'project_status'      => $status,
    );

    // The WHERE clause
    $where = array('project_id' => $project_id);

    // Attempt update
    $updated = $wpdb->update($table_name, $data, $where);

    if ($updated === false) {
        $_SESSION['error'] = 'Failed to update the project.';
        wp_redirect($homeurl . '/projects/edit?id=' . $project_id);
        exit;
    }

    wp_redirect($homeurl . '/projects');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // For proper sidebar highlighting
    $active_page = get_query_var('active_page_wp_pos'); 
    $active_sub_m = get_query_var('active_sub_m'); 
    include_once('header.php'); 
    ?>
    <title>Edit Project | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <?php
            // Show any update error
            if (isset($_SESSION['error'])) {
                echo '<div class="alert alert-danger alert-dismissible" role="alert">';
                echo '  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                echo '  <div class="alert-message"><strong>Error:</strong> ' . esc_html($_SESSION['error']) . '</div>';
                echo '</div>';
                unset($_SESSION['error']);
            }
            ?>

            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Edit Project (ID: <?php echo $project_id; ?>)</h1>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <form method="POST" action="<?php echo get_site_url(); ?>/projects/edit?id=<?php echo $project_id; ?>" enctype="multipart/form-data" onsubmit="return validateForm()">
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Barcode:</label><br>
                                        <?php
                                            $image_url  = "";
                                            if (isset($project->barcode)) {
                                                $image = wp_get_attachment_image_src($project->barcode , 'full');
                                                $image_url = $image[0];
                                            }
                                        ?>
                                        <img src="<?php echo esc_url($image_url); ?>" width="225px" alt="Barcode">
                                    </div>    

                                    <!-- Title -->
                                    <div class="mb-3">
                                        <label class="form-label">Title:</label>
                                        <input type="text" class="form-control" name="title" required value="<?php echo esc_attr($project->project_title); ?>">
                                    </div>

                                    <!-- Description -->
                                    <div class="mb-3">
                                        <label class="form-label">Description:</label>
                                        <textarea class="form-control" name="description" rows="3"><?php echo esc_textarea($project->project_description); ?></textarea>
                                    </div>

                                    <!-- Customer Fields -->
                                    <div class="mb-3">
                                        <label class="form-label">Customer Name:</label>
                                        <input type="text" class="form-control" id="customerName" name="customerName" autocomplete="off" value="<?php echo $customer_db_res->name; ?>">
                                        <div id="customerName_suggestions" class="customer_suggestions"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Customer Phone Number:</label>
                                        <input type="text" class="form-control" id="customerphone" name="customerphone" autocomplete="off" value="<?php echo $customer_db_res->phone_number; ?>">
                                        <div id="customerphone_suggestions" class="customer_suggestions"></div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Customer Email:</label>
                                        <!-- This is the actual DB field: project->customer -->
                                        <input type="text" class="form-control" id="customeremail" name="customer" autocomplete="off" value="<?php echo esc_attr($project->customer); ?>">
                                        <div id="customeremail_suggestions" class="customer_suggestions"></div>
                                    </div>

                                    <!-- Location -->
                                    <div class="mb-3">
                                        <label class="form-label">Location:</label>
                                        <input type="text" class="form-control" name="location" value="<?php echo esc_attr($project->project_location); ?>">
                                    </div>

                                    <!-- Employee with multi-select search -->
                                    <div class="mb-3">
                                        <label class="form-label">Employee:</label>
                                        <!-- Hidden input to store employee ids (JSON array) -->
                                        <input type="hidden" name="employee" id="employee_ids" value='<?php echo esc_attr($project->project_employees); ?>'>
                                        <!-- Employee search input -->
                                        <input type="text" class="form-control" id="employeeSearch" autocomplete="off">
                                        <!-- Suggestions container -->
                                        <div id="employee_suggestions" class="customer_suggestions" style="display:none;"></div>
                                        <!-- Selected employees container -->
                                       
                                        <div id="selectedEmployees" style="margin-bottom:20px;">
                                        
                                        <?php
$selectedEmployees_list = [];

if (!empty($selectedEmployees)) {
    // Prepare placeholders for IN clause
    $placeholders = implode(',', array_fill(0, count($selectedEmployees), '%d'));

    // Fetch all selected employees in a single query
    $query = $wpdb->prepare(
        "SELECT employee_id, name FROM wp_zn_system_employee WHERE employee_id IN ($placeholders)",
        ...$selectedEmployees
    );

    $employees = $wpdb->get_results($query);

    // Index employees by ID for quick lookup
    $employeeData = [];
    foreach ($employees as $emp) {
        $employeeData[$emp->employee_id] = $emp->name;
    }

    foreach ($selectedEmployees as $emp) {
        if (isset($employeeData[$emp])) {
            $selectedEmployees_list[] = ['id' => $emp, 'name' => $employeeData[$emp]];

            echo '<div class="selected-employee" data-id="' . esc_attr($emp) . '" style="padding:5px; border:1px solid #ddd; margin:5px; display:inline-block;">';
            echo esc_html($employeeData[$emp]);
            echo ' <button type="button" class="remove-employee" data-id="' . esc_attr($emp) . '" style="color:red; border:none; background:none;">&times;</button>';
            echo '</div>';
        }
    }
}
?>

                                        </div>
                                    </div>

                                    <!-- (Optional) Project Status -->
                                    <div class="mb-3">
                                        <label class="form-label">Project Status:</label>
                                        <select name="project_status" class="form-control">
                                            <option value="pending" <?php selected($project->project_status, 'pending'); ?>>Pending</option>
                                            <option value="Project Started" <?php selected($project->project_status, 'Project Started'); ?>>Project Started</option>
                                            <option value="ongoing" <?php selected($project->project_status, 'ongoing'); ?>>Ongoing</option>
                                            <option value="onhold" <?php selected($project->project_status, 'onhold'); ?>>Onhold</option>
                                            <option value="completed" <?php selected($project->project_status, 'completed'); ?>>Completed</option>
                                        </select>
                                    </div>
                                    
                                    <button class="btn btn-outline-primary float-end">Update</button>
                                </form>
                            </div><!-- card-body -->
                        </div><!-- card -->
                    </div><!-- col-12 -->
                </div><!-- row -->
            </div><!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<!-- Customer Suggestion Script -->
<script>
jQuery(document).ready(function($) {
    function fetchCustomerData(fieldId, queryKey) {
        let query = $(fieldId).val();
        let suggestionBox = fieldId + "_suggestions";

        if (query.length > 3) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api",
                method: "POST",
                data: { [queryKey]: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(customer => {
                            suggestions += `<div class='suggestion-item' 
                                data-name='${customer.name || ""}'
                                data-phone='${customer.contact_number || ""}'
                                data-email='${customer.email || ""}'
                                data-address='${customer.address || ""}'>
                                ${customer.name || "Unknown"} - ${customer.email || "N/A"} - ${customer.contact_number || "N/A"} - ${customer.address || "N/A"}
                            </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item'>No results found</div>";
                    }
                    $(suggestionBox).html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.log("Error:", error);
                }
            });
        } else {
            $(suggestionBox).hide();
        }
    }

    // Keyup listeners for customer fields
    $("#customerName").keyup(function() {
        fetchCustomerData("#customerName", "search_customer_query_name");
    });
    $("#customerphone").keyup(function() {
        fetchCustomerData("#customerphone", "search_customer_query_phone");
    });
    $("#customeremail").keyup(function() {
        fetchCustomerData("#customeremail", "search_customer_query_email");
    });

    // Click event for selecting a customer suggestion
    $(document).on("click", "#customerName_suggestions .suggestion-item, #customerphone_suggestions .suggestion-item, #customeremail_suggestions .suggestion-item", function() {
        let selectedName = $(this).data("name");
        let selectedPhone = $(this).data("phone");
        let selectedEmail = $(this).data("email");
        $("#customerName").val(selectedName);
        $("#customerphone").val(selectedPhone);
        $("#customeremail").val(selectedEmail);
        $(".customer_suggestions").hide();
    });

    // Hide customer suggestions on outside click
    $(document).click(function(event) {
        if (!$(event.target).closest(".customer_suggestions, #customerName, #customerphone, #customeremail").length) {
            $(".customer_suggestions").hide();
        }
    });
});
</script>

<!-- Employee Search Script -->
<script>
jQuery(document).ready(function($) {
    // Array to hold the selected employees (each with id and name)
    let selectedEmployees = <?php echo json_encode($selectedEmployees_list); ?>;

    // Function to update the hidden field and display the selected employees
    function updateSelectedEmployees() {
        $('#employee_ids').val(JSON.stringify(selectedEmployees.map(emp => emp.id)));
        let displayHtml = '';
        selectedEmployees.forEach(emp => {
            displayHtml += `<div class="selected-employee" data-id="${emp.id}" style="padding:5px; border:1px solid #ddd; margin:5px; display:inline-block;">
                                ${emp.name} 
                                <button type="button" class="remove-employee" data-id="${emp.id}" style="color:red; border:none; background:none;">&times;</button>
                            </div>`;
        });
        $('#selectedEmployees').html(displayHtml);
    }

    updateSelectedEmployees(); // Initialize with preselected employees

    // Employee search keyup event: search when input length is > 3
    $('#employeeSearch').on('keyup', function() {
        let query = $(this).val();
        if (query.length > 3) {
            $.ajax({
                url: "<?php echo get_site_url(); ?>/api/customers_api", // API endpoint for employee search
                method: "POST",
                data: { search_employee_query_name: query },
                success: function(data) {
                    let suggestions = "";
                    if (Array.isArray(data) && data.length > 0) {
                        data.forEach(employee => {
                            suggestions += `<div class="suggestion-item" 
                                                data-id="${employee.id}" 
                                                data-name="${employee.name}" 
                                                style="padding:5px; cursor:pointer; border-bottom:1px solid #eee;">
                                                ${employee.name} - ${employee.email} | ${employee.mobile}
                                            </div>`;
                        });
                    } else {
                        suggestions = "<div class='suggestion-item' style='padding:5px;'>No results found</div>";
                    }
                    $('#employee_suggestions').html(suggestions).show();
                },
                error: function(xhr, status, error) {
                    console.error("Error:", error);
                }
            });
        } else {
            $('#employee_suggestions').hide();
        }
    });

    // Employee suggestion click handler
    $(document).on('click', '#employee_suggestions .suggestion-item', function() {
        let id = $(this).data('id');
        let name = $(this).data('name');

        // Check if the employee is already selected
        if (!selectedEmployees.some(emp => emp.id === id)) {
            selectedEmployees.push({ id: id, name: name });
        }

        updateSelectedEmployees();
        $('#employeeSearch').val('');
        $('#employee_suggestions').hide();
    });

    // Remove employee from selected list
    $(document).on('click', '.remove-employee', function() {
        let id = $(this).data('id');
        selectedEmployees = selectedEmployees.filter(emp => emp.id !== id);
        updateSelectedEmployees();
    });

    // Hide employee suggestions when clicking outside the search area
    $(document).click(function(event) {
        if (!$(event.target).closest("#employeeSearch, #employee_suggestions").length) {
            $('#employee_suggestions').hide();
        }
    });
});
</script>

</body>
</html>