<?php
/**
 * Template for managing a project gallery with the WordPress Media Library.
 */

session_start();

// Role/permission checks
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator', 'employee'); // Adjust as needed
$has_allowed_role = false;

foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    wp_redirect(get_site_url() . '/unauthorized');
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'zn_system_projects';

// Get the project ID from the URL
$project_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$project_id) {
    // No project ID, redirect or show error
    wp_redirect(get_site_url() . '/projects');
    exit;
}

// Fetch existing project row
$project = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE project_id = %d", $project_id));
if (!$project) {
    // Invalid project
    wp_redirect(get_site_url() . '/projects');
    exit;
}

// Decode existing gallery JSON
$gallery = !empty($project->project_gallery) ? json_decode($project->project_gallery, true) : array();
if (!is_array($gallery)) {
    $gallery = array();
}

// Include WordPress media functions
require_once(ABSPATH . 'wp-admin/includes/image.php');
require_once(ABSPATH . 'wp-admin/includes/file.php');
require_once(ABSPATH . 'wp-admin/includes/media.php');

// Handle image deletion via Media Library
if (isset($_GET['del'])) {
    $del_index = intval($_GET['del']);
    if (isset($gallery[$del_index])) {
        // If an attachment ID is stored, delete it from the Media Library
        if (!empty($gallery[$del_index]['attachment_id'])) {
            wp_delete_attachment($gallery[$del_index]['attachment_id'], true);
        }
        unset($gallery[$del_index]);
        $gallery = array_values($gallery); // reindex

        // Update the DB with new gallery JSON
        $wpdb->update(
            $table_name,
            array('project_gallery' => json_encode($gallery)),
            array('project_id' => $project_id)
        );
    }
    wp_redirect(get_site_url() . '/projects/gallery?id=' . $project_id);
    exit;
}

// Handle image upload via Media Library
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['gallery_files'])) {
    $files = $_FILES['gallery_files'];

    // Loop through each file uploaded
    for ($i = 0; $i < count($files['name']); $i++) {
        if ($files['error'][$i] === UPLOAD_ERR_OK) {
            // Create a temporary file array for the single file upload
            $_FILES['gallery_file'] = array(
                'name'     => $files['name'][$i],
                'type'     => $files['type'][$i],
                'tmp_name' => $files['tmp_name'][$i],
                'error'    => $files['error'][$i],
                'size'     => $files['size'][$i]
            );

            // Use WordPress's media_handle_upload() to upload the file to the Media Library.
            // The second parameter is the parent post ID. Since this project is stored in a custom table,
            // you can pass 0 or a related post ID if available.
            $attachment_id = media_handle_upload('gallery_file', 0);
            if (!is_wp_error($attachment_id)) {
                $file_url = wp_get_attachment_url($attachment_id);
                $gallery[] = array(
                    'attachment_id' => $attachment_id,
                    'file_url'      => $file_url,
                    'uploaded_at'   => current_time('mysql')
                );
            }
        }
    }

    // Update the DB with the new gallery JSON
    $wpdb->update(
        $table_name,
        array('project_gallery' => json_encode($gallery)),
        array('project_id' => $project_id)
    );

    // Refresh the page to show updated gallery
    wp_redirect(get_site_url() . '/projects/gallery?id=' . $project_id);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // Standard includes for header, styles, etc.
    $active_page = 'projects';
    $active_sub_m = '';
    include_once('header.php');
    ?>
    <title>Project Gallery</title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Project Gallery (ID: <?php echo $project_id; ?>)</h1>
                
                <!-- Upload Form -->
                <div class="card">
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="gallery_files" class="form-label">Upload Images</label>
                                <input type="file" name="gallery_files[]" multiple class="form-control" />
                            </div>
                            <button type="submit" class="btn btn-primary">Upload</button>
                        </form>
                    </div>
                </div>

                <!-- Display Gallery -->
                <div class="row mt-4">
                    <?php if (!empty($gallery)) : ?>
                        <?php foreach ($gallery as $index => $img) : ?>
                            <div class="col-md-3">
                                <div class="card mb-4">
                                    <img src="<?php echo esc_url($img['file_url']); ?>" class="card-img-top" alt="Gallery Image">
                                    <div class="card-body">
                                        <p class="card-text">
                                            Uploaded on: <?php echo esc_html($img['uploaded_at']); ?>
                                        </p>
                                        <a href="<?php echo get_site_url() . '/projects/gallery?id=' . $project_id . '&del=' . $index; ?>" 
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Are you sure you want to delete this item?');">
                                           Delete
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <p>No images uploaded yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>
</body>
</html>
