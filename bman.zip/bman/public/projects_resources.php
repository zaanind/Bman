<?php  
session_start();

// Check user roles/permissions
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator', 'employee');
$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    wp_redirect(get_site_url() . '/unauthorized');
    exit;
}

global $wpdb;

// Tables
$tools_table     = $wpdb->prefix . 'zn_inventory_comp_tools';
$materials_table = $wpdb->prefix . 'zn_inventory_comp_meterials';
$projects_table  = $wpdb->prefix . 'zn_system_projects';
$orders_table    = $wpdb->prefix . 'pos_system_orders'; // Ensure this is correct

// Get project ID
$project_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$project_id) {
    wp_redirect(get_site_url() . '/projects');
    exit;
}

// Fetch the project
$project = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$projects_table} WHERE project_id = %d", $project_id)
);
if (!$project) {
    wp_redirect(get_site_url() . '/projects');
    exit;
}

// Column where assigned resources are stored (JSON)
$resource_data_col = 'project_company_tools';
$resource_data = !empty($project->$resource_data_col)
    ? json_decode($project->$resource_data_col, true)
    : [];
if (!is_array($resource_data)) {
    $resource_data = [];
}

// Handle POST submission to save assigned items
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_resources'])) {
    // Expect arrays from the form
    $item_ids     = isset($_POST['item_id']) ? $_POST['item_id'] : [];
    $item_names   = isset($_POST['item_name']) ? $_POST['item_name'] : [];
    $item_types   = isset($_POST['item_type']) ? $_POST['item_type'] : [];
    $quantities   = isset($_POST['quantity']) ? $_POST['quantity'] : [];
    $paid_or_free = isset($_POST['paid_or_free']) ? $_POST['paid_or_free'] : [];
    $prices       = isset($_POST['price']) ? $_POST['price'] : [];

    $new_data = [];
    for ($i = 0; $i < count($item_ids); $i++) {
        // For tools marked as free, set price to 0
        $price = ($item_types[$i] === 'tool' && sanitize_text_field($paid_or_free[$i]) === 'free')
                 ? 0
                 : floatval($prices[$i]);
        
        $new_data[] = [
            'item_id'      => sanitize_text_field($item_ids[$i]),
            'item_name'    => sanitize_text_field($item_names[$i]),
            'item_type'    => sanitize_text_field($item_types[$i]), // "tool" or "meterial"
            'quantity'     => intval($quantities[$i]),
            'paid_or_free' => sanitize_text_field($paid_or_free[$i]),
            'price'        => $price,
            'date'         => current_time('mysql')
        ];
    }

    // Update the project record with the new resource data
    $wpdb->update(
        $projects_table,
        [ $resource_data_col => json_encode($new_data) ],
        [ 'project_id' => $project_id ]
    );

    /* ----- Update Orders Table ----- */
    // Retrieve existing order
    $order = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$orders_table} WHERE order_id = %d", $project->order_id)
    );
    $global_paid = ($order && isset($order->g_paid)) ? floatval($order->g_paid) : 0;

    // Use discount from order if set
    // Here, discount is treated as a percentage (e.g. 10 means 10%).
    $global_discount = 0;
    if ($order && isset($order->g_discount) && floatval($order->g_discount) > 0) {
        $global_discount = floatval($order->g_discount);
    } /*elseif (isset($project->g_discount)) {
        $global_discount = floatval($project->g_discount);
    } */

    // Decode existing order items (if any)
    $existing_items = [];
    if ($order && !empty($order->items)) {
        $existing_items = json_decode($order->items, true);
        if (!is_array($existing_items)) {
            $existing_items = [];
        }
    }

  //  echo print_r($existing_items);
  //  echo 'filtering<br><br>';

    // Remove items with [type] => meterialortool
    $filtered_items = [];
    foreach ($existing_items as $item) {
    if (!isset($item['type']) || $item['type'] !== 'meterialortool') {
        $filtered_items[] = $item;
    } }
   // echo print_r($filtered_items); //now we have only items added from order page. 
                                   // we need to add the meterials and tools things and recalculate full bill

    


    // Build new order items from the current project data.
    // Add a marker "type" => "meterialortool" to differentiate these items.
    $new_project_items = array();
    foreach ($new_data as $item) {
        $quantity = (int)$item['quantity']; // Default quantity from the input

        if ($item['item_type'] != 'material') {
            $quantity = 1; 
        }


        $new_project_items[] = [
            'title'     => $item['item_name'],
            'id'        => (int)$item['item_id'],
            'item_type' => $item['item_type'], // store tool or meterial
            'quantity'  => $quantity,
            'price'     => (float)$item['price']/$item['quantity'],
            'discount'  => 0,
            'total'     => (float)($item['quantity'] * $item['price']/$item['quantity']),
            'type'      => 'meterialortool'
        ];
    } 

    // Merge the new project items with the other order items
    $merged_items = array_merge( $filtered_items, $new_project_items);

    // Recalculate billing totals based on all merged items
    $global_subtotal = 0;
    foreach ($merged_items as $order_item) {
        $global_subtotal += $order_item['total'];
    }

    // Calculate discount amount (discount is a percentage)
    $discount_amount = $global_subtotal * ($global_discount / 100);
    $taxable_amount = max(0, $global_subtotal - $discount_amount);

    // Calculate tax only if g_tax is set in the order (as a decimal, e.g., 0.1 for 10%)
    $global_tax = 0;
    if ($order && isset($order->g_tax) && floatval($order->g_tax) > 0) {
        $tax_rate = floatval($order->g_tax);
        $global_tax = $taxable_amount * $tax_rate/100;
    }
    
    // Grand total is taxable amount plus tax
    $global_total = $taxable_amount + $global_tax;
    $global_due   = max(0, $global_total - $global_paid);

    // Update order billing with the merged items and recalculated totals
    if ($order) {
        $wpdb->update(
            $orders_table,
            [
                'items'           => json_encode($merged_items),
                'g_subtotal'      => $global_subtotal,
                'g_total_amount'  => $global_total,
                'g_grand_total'   => $global_total,
             //   'g_tax'           => $global_tax,
                'g_paid'          => $global_paid,
                'g_due'           => $global_due,
                'g_discount'      => $global_discount  // discount remains as percentage
            ],
            [ 'order_id' => $project->order_id ]
        );
    }

   
 /*
    echo  print_r([
        'items'           => json_encode($merged_items),
        'g_subtotal'      => $global_subtotal,
        'g_total_amount'  => $global_total,
        'g_grand_total'   => $global_total,
     //   'g_tax'           => $global_tax,
        'g_paid'          => $global_paid,
        'g_due'           => $global_due,
        'g_discount'      => $global_discount  // discount remains as percentage
    ]); */
    

    /* ----- End Orders Table Update ----- */

    /* ----- Start Inventory Update ----- */
    
    // First, get the previous resource data to compare changes
    $previous_resource_data = !empty($project->$resource_data_col) 
        ? json_decode($project->$resource_data_col, true) 
        : [];
    if (!is_array($previous_resource_data)) {
        $previous_resource_data = [];
    }

    // Create lookup arrays for previous quantities
    $previous_quantities = [];
    foreach ($previous_resource_data as $prev_item) {
        $key = $prev_item['item_type'] . '_' . $prev_item['item_id'];
        $previous_quantities[$key] = intval($prev_item['quantity']);
    }

    // Create lookup arrays for new quantities
    $new_quantities = [];
    foreach ($new_data as $new_item) {
        $key = $new_item['item_type'] . '_' . $new_item['item_id'];
        $new_quantities[$key] = intval($new_item['quantity']);
    }

    // Process each item in both arrays to determine quantity changes
    $quantity_updates = [];

    // Handle removed or modified items from previous data
    foreach ($previous_quantities as $key => $prev_qty) {
        list($type, $id) = explode('_', $key);
        $new_qty = isset($new_quantities[$key]) ? $new_quantities[$key] : 0;
        $qty_difference = $prev_qty - $new_qty; // Positive means we need to add back to inventory

        if ($qty_difference != 0) {
            $quantity_updates[] = [
                'type' => $type,
                'id' => $id,
                'adjust' => $qty_difference // Positive adds back to inventory, negative reduces
            ];
        }
    }

    // Handle new items
    foreach ($new_quantities as $key => $new_qty) {
        if (!isset($previous_quantities[$key])) {
            list($type, $id) = explode('_', $key);
            $quantity_updates[] = [
                'type' => $type,
                'id' => $id,
                'adjust' => -$new_qty // Negative because we're reducing inventory
            ];
        }
    }



    // Apply the updates to the database
    foreach ($quantity_updates as $update) {
        if ($update['type'] === 'tool') {
          //  continue;
            $wpdb->query($wpdb->prepare(
                "UPDATE wp_zn_system_stocks 
                SET quantity = quantity + %d 
                WHERE item_id = %d",
                $update['adjust'],
                $update['id']
            )); 
        } elseif ($update['type'] === 'material') {
            $wpdb->query($wpdb->prepare(
                "UPDATE wp_zn_system_stocks
                SET quantity = quantity + %d 
                WHERE item_id = %d",
                $update['adjust'],
                $update['id']
            ));
        }
    }

    /*echo print_r($quantity_updates);
    exit; */

    /* ----- End Inventory Update ----- */

    // Existing redirect
    wp_redirect(get_site_url() . '/projects/resources?id=' . $project_id);
    exit;
}

// Retrieve Tools
//$tools = $wpdb->get_results("SELECT * FROM {$tools_table} WHERE quantity > 0 ORDER BY tool_id DESC");
$tools = $wpdb->get_results("SELECT * FROM wp_zn_system_stocks WHERE quantity > 0 AND type='tool' ORDER BY item_id DESC");


// Retrieve Materials
//$materials = $wpdb->get_results("SELECT * FROM {$materials_table} ORDER BY item_id DESC");
$materials = $wpdb->get_results("SELECT * FROM wp_zn_system_stocks WHERE quantity > 0 AND type='material' ORDER BY item_id DESC");



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = 'projects';
    include_once('header.php');
    ?>
    <title>Project Resources</title>
    <style>
        /* Basic styling for the grid of items */
        .item-grid { display: flex; flex-wrap: wrap; gap: 20px; }
        .item-box {
            width: 120px;
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
            cursor: pointer;
        }
        .item-box img {
            width: 90px;
            height: 90px;
            object-fit: cover;
            display: block;
            margin: 0 auto 5px;
        }
        .item-type-label {
            font-size: 12px;
            color: #999;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">
                    Project Resources (ID: <?php echo $project_id; ?>)
                </h1>

                <!-- 1) TOOLS LIST -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Tools</h5>
                        <small>(Click an item to add below)</small>
                    </div>
                    <div class="card-body">
                        <div class="item-grid">
                            <?php foreach ($tools as $tool): ?>
                                <?php
                                // Extract 90x90 image
                                $image_url = '';
                                $image_link = json_decode($tool->image);
                                if (isset($image_link->id)) {
                                    $image_info = wp_get_attachment_image_src($image_link->id, 'table_90x90');
                                    $image_url  = $image_info ? $image_info[0] : ($image_link->url ?? '');
                                }
                                ?>
                                <div class="item-box tool-item"
                                     data-id="<?php echo esc_attr($tool->tool_id); ?>"
                                     data-name="<?php echo esc_attr($tool->item_name); ?>"
                                     data-price="<?php echo esc_attr($tool->price); ?>"
                                     data-type="tool">
                                    <img src="<?php echo esc_url($image_url); ?>" alt="Tool">
                                    <div><strong><?php echo esc_html($tool->item_name); ?></strong></div>
                                    <div class="item-type-label">Tool</div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- 2) MATERIALS LIST -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Materials</h5>
                        <small>(Click an item to add below)</small>
                    </div>
                    <div class="card-body">
                        <div class="item-grid">
                            <?php foreach ($materials as $mat): ?>
                                <?php
                                // Extract 90x90 image
                                $image_url = '';
                                $image_link = json_decode($mat->image);
                                if (isset($image_link->id)) {
                                    $image_info = wp_get_attachment_image_src($image_link->id, 'table_90x90');
                                    $image_url  = $image_info ? $image_info[0] : ($image_link->url ?? '');
                                }
                                ?>
                                <div class="item-box material-item"
                                     data-id="<?php echo esc_attr($mat->item_id); ?>"
                                     data-name="<?php echo esc_attr($mat->item_name); ?>"
                                     data-price="<?php echo esc_attr($mat->price); ?>"
                                     data-type="material"
                                     data-avalible="<?php echo esc_attr($mat->quantity); ?>">
                                    <img src="<?php echo esc_url($image_url); ?>" alt="Material">
                                    <div><strong><?php echo esc_html($mat->item_name); ?></strong></div>
                                    <div class="item-type-label">Material</div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- 3) ASSIGNED ITEMS TABLE + SAVE FORM -->
                <form method="POST">
                    <input type="hidden" name="save_resources" value="1" />

                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Assigned Items</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="assignedItemsTable" class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Item Name</th>
                                            <th>Type</th>
                                            <th>Paid or Free?</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Remove</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($resource_data)): ?>
                                            <?php foreach ($resource_data as $res): ?>
                                                <?php
                                                $unit_price = (intval($res['quantity']) > 0) ? floatval($res['price']) / intval($res['quantity']) : 0;
                                                ?>
                                                <tr>
                                                    <td>
                                                        <input type="hidden" name="item_id[]" value="<?php echo esc_attr($res['item_id']); ?>">
                                                        <input type="hidden" name="item_name[]" value="<?php echo esc_attr($res['item_name']); ?>">
                                                        <input type="hidden" name="item_type[]" value="<?php echo esc_attr($res['item_type']); ?>">
                                                        <?php echo esc_html($res['item_name']); ?>
                                                    </td>
                                                    <td><?php echo esc_html(ucfirst($res['item_type'])); ?></td>
                                                    <td>
                                                        <?php if ($res['item_type'] === 'tool'): ?>
                                                            <select name="paid_or_free[]" class="form-select tool-paid-or-free">
                                                                <option value="free" <?php selected($res['paid_or_free'], 'free'); ?>>Free</option>
                                                                <option value="paid" <?php selected($res['paid_or_free'], 'paid'); ?>>Paid (Rental)</option>
                                                            </select>
                                                        <?php else: ?>
                                                            <input type="hidden" name="paid_or_free[]" value="paid" />
                                                            Paid
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                           

                                                        <?php if ($res['item_type'] === 'tool'): ?>
                                                            <input type="number" name="price[]"
                                                                   value="<?php echo isset($res['price']) ? floatval($res['price']) : ''; ?>"
                                                                   step="any"
                                                                   class="form-control pricing-input"
                                                                   style="<?php echo ($res['paid_or_free'] === 'paid' ? '' : 'display:none;'); ?>">
                                                            <input type="hidden" class="unit-price" value="<?php echo $unit_price; ?>">
                                                        <?php else: ?>
                                                            <input type="number" name="price[]"
                                                                   value="<?php echo isset($res['price']) ? floatval($res['price']) : ''; ?>"
                                                                   step="any"
                                                                   class="form-control pricing-input">
                                                            <input type="hidden" class="unit-price" value="<?php echo $unit_price; ?>">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <input type="number" name="quantity[]"
                                                               value="<?php echo intval($res['quantity']); ?>"
                                                               min="0" class="form-control"                         
                                                             <?php  if ($res['item_type'] === 'material') {
                                                                
                                                                if(!$mat->quantity==0){
                                                                echo 'max="'.$mat->quantity.'"';
                                                            }else {
                                                                echo 'max="'.$res['quantity'].'"';
                                                            }

                                                            }
                                                        ?>>
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-danger btn-sm removeRow">Remove</button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr><td colspan="6">No items assigned yet.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Save Items</button>
                        </div>
                    </div>
                </form>
            </div>
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<!-- jQuery (ensure jQuery is enqueued in WordPress) -->
<script>
jQuery(document).ready(function($){
    // When a user clicks a tool or material box, add a new row to the table
    $('.item-box').on('click', function(){
        let itemId   = $(this).data('id');
        let itemName = $(this).data('name');
        let itemType = $(this).data('type'); // 'tool' or 'meterial'
        let itemPrice = parseFloat($(this).data('price')) || 0;
        let isTool   = (itemType === 'tool');

        let maxQuantity = 1;
        if (itemType === 'material') {
            maxQuantity = parseInt($(this).data('avalible')) || 0; // Use "available"
            if (maxQuantity < 0) { // Ensure maxQuantity is never negative
                maxQuantity = 0;
            }

        }

        // Check if the item already exists in the table
        let exists = false;
        $('#assignedItemsTable tbody tr').each(function(){
            let existingId = $(this).find('input[name="item_id[]"]').val();
            let existingType = $(this).find('input[name="item_type[]"]').val();
            if (existingId == itemId && existingType == itemType) {
                exists = true;
            }
        });
        if (exists) {
            alert('Item already added.');
            return;
        }

        // Build paid/free selection and pricing input
        let paidOrFreeHtml = '';
        if (isTool) {
            paidOrFreeHtml = `
                <select name="paid_or_free[]" class="form-select tool-paid-or-free">
                    <option value="free" selected>Free</option>
                    <option value="paid">Paid (Rental)</option>
                </select>
            `;
        } else {
            paidOrFreeHtml = `Paid <input type="hidden" name="paid_or_free[]" value="paid">`;
        }

        // Build new row HTML with a hidden unit-price input
        let newRow = `
            <tr>
                <td>
                    <input type="hidden" name="item_id[]" value="${itemId}">
                    <input type="hidden" name="item_name[]" value="${itemName}">
                    <input type="hidden" name="item_type[]" value="${itemType}">
                    ${itemName}
                </td>
                <td>${itemType.charAt(0).toUpperCase() + itemType.slice(1)}</td>
                <td>${paidOrFreeHtml}</td>
                <td>
                    ${ isTool 
                        ? `<input type="number" name="price[]" value="${itemPrice}" step="0.01" class="form-control pricing-input" style="display:none;">
                           <input type="hidden" class="unit-price" value="${itemPrice}">`
                        : `<input type="number" name="price[]" value="${itemPrice}" step="0.01" class="form-control pricing-input">
                           <input type="hidden" class="unit-price" value="${itemPrice}">`
                    }
                </td>
                <td><input type="number" name="quantity[]" value="1" min="0"  max="${maxQuantity}"  class="form-control"></td>
                <td>
                    <button type="button" class="btn btn-danger btn-sm removeRow">Remove</button>
                </td>
            </tr>
        `;
        let tableBody = $('#assignedItemsTable tbody');
        if (tableBody.find('td').length === 1) {
            tableBody.html('');
        }
        tableBody.append(newRow);
    });

    // Toggle pricing input visibility when changing a tool's paid/free select
    $(document).on('change', '.tool-paid-or-free', function() {
        let $row = $(this).closest('tr');
        if ($(this).val() === 'paid') {
            $row.find('.pricing-input').show();
        } else {
            $row.find('.pricing-input').hide().val('');
        }
    });

    // Update the price when quantity changes using the hidden unit-price
    $(document).on('input change', 'input[name="quantity[]"]', function() {
        let qty = parseInt($(this).val());
        let maxQty = parseInt($(this).attr('max'));

        if (isNaN(qty) || qty < 0) {
            qty = 0;
            $(this).val(qty);
        }

        if (qty > maxQty) {
          qty = maxQty;
          $(this).val(qty); 
        }
        


        let $row = $(this).closest('tr');
        let unitPrice = parseFloat($row.find('.unit-price').val());
        if (isNaN(unitPrice)) {
            unitPrice = 0;
        }
        let totalPrice = (unitPrice * qty).toFixed(2);
        $row.find('.pricing-input').val(totalPrice);
    });

    // Remove row handler
    $(document).on('click', '.removeRow', function(){
        $(this).closest('tr').remove();
        let tableBody = $('#assignedItemsTable tbody');
        if (tableBody.children('tr').length === 0) {
            tableBody.html('<tr><td colspan="6">No items assigned yet.</td></tr>');
        }
    });
});
</script>
</body>
</html>
