<?php
session_start();

$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator','employee');


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}




$tools_table     = $wpdb->prefix . 'zn_inventory_comp_tools';
$materials_table = $wpdb->prefix . 'zn_inventory_comp_meterials';







   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	  global $wpdb;

        
      $homeurl = get_site_url();
      $i_id = $_POST['item_id'];
      $name = $_POST['item_name'];
	  $type = $_POST['item_type'];
	  $quantity = $_POST['quantity'];
      //$exp_date = $_POST['expire_date'];
	  $price = $_POST['unit_price'];
      $pid =   $_POST['project_id'];
	 // $type = $_POST['type'];
      //$location = $_POST['location'];

      if ($type=='tool'){

        // Retrieve Tools
        $tools = $wpdb->get_results("SELECT * FROM {$tools_table} WHERE tool_id={$i_id}");

        $image_json = $tools[0]->image;
        $category = $tools[0]->category;
        $brand_name = $tools[0]->brand_name;
        $description = $tools[0]->tool_description;
        $exp_d = $tools[0]->exp_date;
        $c_location = $tools[0]->location;
        $existing_history = $tools[0]->location_history;
        
}

if ($type=='material'){

    // Retrieve Tools
    $mets = $wpdb->get_results("SELECT * FROM {$materials_table} WHERE item_id={$i_id}");
    $image_json = $mets[0]->image;
    $category = $mets[0]->category;
    $brand_name = $mets[0]->brand_name;
    $description = $mets[0]->item_description;
    $exp_d = $mets[0]->exp_date;
    $existing_history = $mets[0]->location_history;
    $c_location = $mets[0]->location;

}
      
	   
      
	  
	
    $project_location = $wpdb->get_var( 
        $wpdb->prepare("SELECT project_location FROM wp_zn_system_projects WHERE project_id = %d", $pid) 
    );

    // Check if 'location_history' exists in the fetched stock object
    $history_array = isset($existing_history ) ? json_decode($existing_history , true) : [];
     
     // Ensure it's an array (fallback if JSON decoding fails)
     if (!is_array($history_array)) {
         $history_array = [];
     }




    /*/ Append new location if it’s not already the last recorded one
     if (empty($history_array) || end($history_array) !== $project_location) {
        //$history_array[] =  $c_location ;
        $history_array[] = $project_location;
     } */
    
     // Append new location if it’s not already the last recorded one
     if (empty($history_array) || end($history_array) !== $project_location) {
         $history_array[] = $project_location;
     
         // Limit array to max 5 elements
         if (count($history_array) > 5) {
             $history_array = array_slice($history_array, -5); 
         }
     }



    // Convert back to JSON
    $loc_history_json = json_encode($history_array);


 	$table_name = $wpdb->prefix . 'zn_system_stocks';
    $data = array(
        'item_id'=> $i_id ,
        'item_name' => $name,
	    'price' => $price,
	    'states' => 'OK', 
        'quantity' => $quantity,
		'type' => $type,
        'image' => $image_json,
        'category' => $category,
        'project_id' =>   $pid,
        'is_request_passed' => '0',
        'location' => $project_location,
        'brand_name' =>  $brand_name ,
        'product_description' => $description ,
        'exp_date' => $exp_d,
        'location_history' => $loc_history_json ,
      );
	
	
    $inserted = $wpdb->insert($table_name, $data); 

    

    // Get the newly inserted order ID
    $info_id = $wpdb->insert_id;

	  
        if ($inserted === false) {
           // get_header();
          //  get_footer();
       // exit;
		  $_SESSION['error'] = 'Failed';
		  header('location:'.$homeurl.'/projects/stocks/add?id='.$pid);
		  exit;
      

	  }


    
	header('location:'.$homeurl.'/projects/stocks?id='.$pid);


}
		
// Retrieve Tools
$tools = $wpdb->get_results("SELECT * FROM {$tools_table} WHERE quantity > 0 ORDER BY tool_id DESC");

// Retrieve Materials
$materials = $wpdb->get_results("SELECT * FROM {$materials_table} ORDER BY item_id DESC");


if ( !isset($_GET['id']) && empty($_GET['id']) ) {

    echo "<h1>ID Not Found</h1>";
    exit;
} else {


    $pid = intval($_GET['id']);
}


?>


<!DOCTYPE html>
<html lang="en">
   <head>
   <?php

   $active_page = get_query_var('active_page_wp_pos'); 
   $active_sub_m = get_query_var('active_sub_m'); 
   include_once('header.php'); ?>
	<title>Request stock | <?php echo get_bloginfo( 'name' ); ?></title>
    <style>
        /* Basic styling for the grid of items */
        .item-grid { display: flex; flex-wrap: wrap; gap: 20px; }
        .item-box {
            width: 120px;
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
            cursor: pointer;
        }
        .item-box img {
            width: 90px;
            height: 90px;
            object-fit: cover;
            display: block;
            margin: 0 auto 5px;
        }
        .item-type-label {
            font-size: 12px;
            color: #999;
        }
    </style>


</head>

<body>
	<div class="wrapper">
	<?php include_once('sidebar.php'); ?>
		<div class="main">
            <?php include_once('navbar.php'); ?>



			<main class="content">
			<?php
                   if (isset($_SESSION['error'])) {
                         $err = $_SESSION['error'];
                         unset($_SESSION['error']);?>
						 
						 			<div class="alert alert-danger alert-dismissible" role="alert">
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											<div class="alert-message">
												<strong>Error:</strong> Failed to add item
											</div>
										</div>

						<?php }	?>
								
								
					
										
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Request Stock</h1>

					<div class="row">
						<div class="col-12">

      <!-- 1) TOOLS LIST -->
      <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Tools</h5>
                        <small>(Click an item to add below)</small>
                    </div>
                    <div class="card-body">
                        <div class="item-grid">
                            <?php foreach ($tools as $tool): ?>
                                <?php
                                // Extract 90x90 image
                                $image_url = '';
                                $image_link = json_decode($tool->image);
                                if (isset($image_link->id)) {
                                    $image_info = wp_get_attachment_image_src($image_link->id, 'table_90x90');
                                    $image_url  = $image_info ? $image_info[0] : ($image_link->url ?? '');
                                }
                                ?>
                                <div class="item-box tool-item"
                                     data-id="<?php echo esc_attr($tool->tool_id); ?>"
                                     data-name="<?php echo esc_attr($tool->tool_name); ?>"
                                     data-price="<?php echo esc_attr($tool->price); ?>"
                                     data-type="tool">
                                    <img src="<?php echo esc_url($image_url); ?>" alt="Tool">
                                    <div><strong><?php echo esc_html($tool->tool_name); ?></strong></div>
                                    <div class="item-type-label">Tool</div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- 2) MATERIALS LIST -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Materials</h5>
                        <small>(Click an item to add below)</small>
                    </div>
                    <div class="card-body">
                        <div class="item-grid">
                            <?php foreach ($materials as $mat): ?>
                                <?php
                                // Extract 90x90 image
                                $image_url = '';
                                $image_link = json_decode($mat->image);
                                if (isset($image_link->id)) {
                                    $image_info = wp_get_attachment_image_src($image_link->id, 'table_90x90');
                                    $image_url  = $image_info ? $image_info[0] : ($image_link->url ?? '');
                                }
                                ?>
                                <div class="item-box material-item"
                                     data-id="<?php echo esc_attr($mat->item_id); ?>"
                                     data-name="<?php echo esc_attr($mat->item_name); ?>"
                                     data-price="<?php echo esc_attr($mat->price); ?>"
                                     data-type="material"
                                     data-avalible="<?php echo esc_attr($mat->quantity); ?>">
                                    <img src="<?php echo esc_url($image_url); ?>" alt="Material">
                                    <div><strong><?php echo esc_html($mat->item_name); ?></strong></div>
                                    <div class="item-type-label">Material</div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>


       

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered ">
    <div class="modal-content">
      <form id="requestForm" method="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Request Item</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <!-- Hidden fields to send item data -->
          <input type="hidden" name="item_id" id="modalItemId">
          <input type="hidden" name="item_name" id="modalItemName">
          <input type="hidden" name="item_type" id="modalItemType">
          <input type="hidden" name="unit_price" id="modalUnitPrice">
          <input type="hidden" name="project_id" value="<?php echo $pid; ?>">
          
          <!-- Quantity input -->
          <div class="mb-3">
            <label for="modalQuantity" class="form-label">Quantity</label>
            <input type="number" class="form-control" name="quantity" id="modalQuantity" value="1" min="1">
          </div>
          
          <!-- Calculated price (read-only) -->
          <div class="mb-3">
            <label for="modalTotalPrice" class="form-label">Total Price</label>
            <input type="text" class="form-control" name="price" id="modalTotalPrice" readonly>
          </div>
          
          <!-- You can add more inputs (e.g., description, brand, etc.) as needed -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Request</button>
        </div>
      </form>
    </div>
  </div>
</div>



					    </div>
					</div>

				</div>
			</main>


			
			
			
			
			<?php include_once('footer.php');?>
		</div>
	</div>

	
    <script>



jQuery(document).ready(function($){
    // When an item is clicked, show the modal and populate the form
    $('.item-box').on('click', function(){
        // Get data attributes from the clicked item
        var itemId   = $(this).data('id');
        var itemName = $(this).data('name');
        var itemType = $(this).data('type');
        var unitPrice = parseFloat($(this).data('price')) || 0;
        var available = $(this).data('avalible') || 1; // for materials

        // Populate the hidden fields in the modal form
        $('#modalItemId').val(itemId);
        $('#modalItemName').val(itemName);
        $('#modalItemType').val(itemType);
        $('#modalUnitPrice').val(unitPrice);
        $('#modalQuantity').val(1);
        
        // If this is a material, set the maximum quantity available
        if(itemType === 'material'){
            $('#modalQuantity').attr('max', available);
        } else {
            $('#modalQuantity').removeAttr('max');
        }
        
        // Set the initial total price (1 x unit price)
        var totalPrice = unitPrice * 1;
        $('#modalTotalPrice').val(totalPrice.toFixed(2));
        
        // Open the modal popup using Bootstrap's modal method
        $('#staticBackdrop').modal('show');
    });
    
    // Update the total price when the quantity changes
    $('#modalQuantity').on('input change', function(){
        var qty = parseInt($(this).val());
        if(isNaN(qty) || qty < 1){
            qty = 1;
            $(this).val(qty);
        }
        var unitPrice = parseFloat($('#modalUnitPrice').val()) || 0;
        var totalPrice = qty * unitPrice;
        $('#modalTotalPrice').val(totalPrice.toFixed(2));
    });
    
 
});

</script>
	
</body>

</html>