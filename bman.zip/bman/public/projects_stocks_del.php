<?php
/*
$homeurl = get_site_url();
// Get the current user object
$current_user = wp_get_current_user();



if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $stock_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Fetch stock details before deletion
    $sql = $wpdb->prepare("SELECT item_id, type, quantity,is_request_passed FROM {$wpdb->prefix}zn_system_stocks WHERE stock_id = %d;", $stock_id);
    $stock = $wpdb->get_row($sql);


    if ( ! in_array('employee', (array) $current_user->roles ) ) {

    if (!empty($stock)) {
        $item_id = $stock->item_id;
        $quantity = $stock->quantity;
        $type = $stock->type;
        $is_request_passed = (int) $stock->is_request_passed;


        // Delete the stock entry
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}zn_system_stocks WHERE stock_id = %d;", $stock_id));


     if ($is_request_passed == 1 || $is_request_passed == 2) {
        // Restore quantity back to tools/materials table
        if ($type == 'tool') {
            $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}zn_inventory_comp_tools SET quantity = quantity + %d WHERE tool_id = %d;", $quantity, $item_id));
        } elseif ($type == 'meterial') {
            $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}zn_inventory_comp_meterials SET quantity = quantity + %d WHERE item_id = %d;", $quantity, $item_id));
        }  

    }    } else {


        $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}zn_system_stocks SET is_request_passed = 2 WHERE stock_id = %d;", $stock_id));



    }



        // Redirect after deletion
      //  status_header(200);
       // wp_redirect($homeurl . '/projects/stocks');
       echo "<script>history.back()</script>";
        exit;
    } else {
        echo "Stock not found.";
    }
} else {
    echo "No ID provided.";
} */

$homeurl = get_site_url();
// Get the current user object
$current_user = wp_get_current_user();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $stock_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Fetch stock details before deletion
    $sql = $wpdb->prepare("SELECT * FROM {$wpdb->prefix}zn_system_stocks WHERE stock_id = %d;", $stock_id);
    $stock = $wpdb->get_row($sql);

    if (!empty($stock)) {
        $item_id = $stock->item_id;
        $quantity = $stock->quantity;
        $type = $stock->type;
        $is_request_passed = (int) $stock->is_request_passed;
      
        $location_history = json_decode($stock->location_history, true) ?? []; // Decode JSON or set to empty array
       

        if (in_array('employee', (array) $current_user->roles)) {
            // If employee, just update is_request_passed to 2
            
            $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}zn_system_stocks SET is_request_passed = 2 WHERE stock_id = %d;", $stock_id));
            if ($is_request_passed == 0) {
                $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}zn_system_stocks WHERE stock_id = %d;", $stock_id));
            }
 
        } else {

            $location_history[] = 'Company';
            $new_location_history_json = json_encode($location_history);

            
            // If not an employee, delete stock
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}zn_system_stocks WHERE stock_id = %d;", $stock_id));

            if ($is_request_passed == 1 || $is_request_passed == 2) {
                // Restore quantity back to tools/materials table
                if ($type == 'tool') {
                    $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}zn_inventory_comp_tools SET quantity = quantity + %s WHERE tool_id = %d;", $quantity, $item_id));
                    $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}zn_inventory_comp_tools SET  location_history =  %s WHERE tool_id = %d;", $new_location_history_json, $item_id));
                } elseif ($type == 'material') {
                    $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}zn_inventory_comp_meterials SET quantity = quantity + %s WHERE item_id = %d;", $quantity, $item_id));
                    $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}zn_inventory_comp_meterials SET location_history =  %s WHERE item_id = %d;", $new_location_history_json, $item_id));
                }
            }
        }
    }

    // Redirect after processing
    echo "<script>history.back()</script>";
    exit;
} else {
    echo "Stock not found or invalid request.";
}


?>
