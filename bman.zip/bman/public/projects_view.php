<?php
session_start();

// Check user roles/permissions
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator','employee'); // Adjust roles as needed
$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    wp_redirect(get_site_url() . '/unauthorized');
    exit;
} 

global $wpdb;
$projects_table = $wpdb->prefix . 'zn_system_projects';

// 1) Get Project
$project_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$project_id) {
    wp_redirect(get_site_url() . '/projects');
    exit;
}

// Fetch the project record
$project = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$projects_table} WHERE project_id = %d", $project_id)
);
if (!$project) {
    // Invalid project -> redirect
    wp_redirect(get_site_url() . '/projects');
    exit;
}

// 2) Decode JSON columns
// Gallery
$gallery_data = !empty($project->project_gallery) 
    ? json_decode($project->project_gallery, true) 
    : [];

// Tools/Materials (resources)
$resources_data = !empty($project->project_company_tools) 
    ? json_decode($project->project_company_tools, true) 
    : [];

// Costs
$cost_data = !empty($project->project_cost) 
    ? json_decode($project->project_cost, true) 
    : [];

if (!is_array($gallery_data))   $gallery_data   = [];
if (!is_array($resources_data)) $resources_data = [];
if (!is_array($cost_data))      $cost_data      = [];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    // For proper sidebar highlighting
    $active_page = 'projects';
    $active_sub_m = '';
    include_once('header.php');
    ?>
    <title>View Project | <?php echo get_bloginfo('name'); ?></title>
    <style>
        .gallery-grid {
            display: flex; 
            flex-wrap: wrap; 
            gap: 20px;
        }
        .gallery-item {
            width: 200px; 
            text-align: center;
        }
        .gallery-item img {
            max-width: 100%; 
            height: auto; 
            display: block; 
            margin-bottom: 8px;
        }
    </style>
</head>

<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">

                <!-- 1) Basic Project Info -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Project Info</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                             <label class="form-label">Barcode:</label><br>
                             <?php
                                 $image_url  = "";
                                 
                                 if (isset($project->barcode)) {
                                     $image = wp_get_attachment_image_src($project->barcode , 'full');
                                     $image_url = $image[0];
                                 }
                             ?>
                             <img src="<?php echo esc_url($image_url); ?>" width="225px" alt="Barcode">
                                            
                             </div>


                        <div class="mb-3">
                            <label class="form-label">Title:</label>
                            <input type="text" class="form-control" 
                                   value="<?php echo esc_html($project->project_title); ?>" 
                                   readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description:</label>
                            <textarea class="form-control" rows="3" readonly><?php 
                                echo esc_textarea($project->project_description);
                            ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status:</label>
                            <input type="text" class="form-control" 
                                   value="<?php echo esc_html($project->project_status); ?>" 
                                   readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Location:</label>
                            <input type="text" class="form-control" 
                                   value="<?php echo esc_html($project->project_location ?? 'None'); ?>" 
                                   readonly>
                        </div>


                        





                        <div class="mb-3">
    <label class="form-label">Employees:</label>
    <?php 
    // Decode JSON into an array
    $employee_ids = !empty($project->project_employees) ? json_decode($project->project_employees, true) : [];

    // Ensure it's an array
    if (!is_array($employee_ids)) {
        $employee_ids = [];
    }

    $employee_names = [];

    if (!empty($employee_ids)) {
        // Fetch employee names in a single query
        $placeholders = implode(',', array_fill(0, count($employee_ids), '%d'));
        $query = $wpdb->prepare(
            "SELECT name FROM {$wpdb->prefix}zn_system_employee WHERE employee_id IN ($placeholders)",
            ...array_map('intval', $employee_ids)
        );

        $employees = $wpdb->get_results($query);
        
        // Store names for display
        foreach ($employees as $employee) {
            $employee_names[] = $employee->name;
        }
    }

    // Display names separated by commas
    $employee_names_str = implode(', ', $employee_names);
    ?>
    <input type="text" class="form-control" value="<?php echo esc_html($employee_names_str); ?>" readonly>
</div>










                        <div class="mb-3">
                            <label class="form-label">Customer:</label>
                            <input type="text" class="form-control" 
                                   value="<?php echo esc_html($project->customer); ?>" 
                                   readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Project Credit:</label>
                            <input type="text" class="form-control" 
                                   value="<?php echo esc_html($project->project_credit ?? 0); ?>" 
                                   readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Created At:</label>
                            <input type="text" class="form-control" 
                                   value="<?php echo esc_html($project->created_at); ?>" 
                                   readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Updated At:</label>
                            <input type="text" class="form-control" 
                                   value="<?php echo esc_html($project->updated_at); ?>" 
                                   readonly>
                        </div>
                    </div>
                </div>

                <!-- 2) Project Gallery (read-only) -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Project Gallery</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($gallery_data)): ?>
                            <div class="gallery-grid">
                                <?php foreach ($gallery_data as $img): ?>
                                    <?php 
                                    // If you stored attachment IDs:
                                    if (!empty($img['attachment_id'])) {
                                        $attachment_url = wp_get_attachment_url($img['attachment_id']);
                                    } else {
                                        // Fallback if you stored direct URLs
                                        $attachment_url = isset($img['file_url']) ? $img['file_url'] : '';
                                    }
                                    ?>
                                    <?php if ($attachment_url): ?>
                                        <div class="gallery-item">
                                            <img src="<?php echo esc_url($attachment_url); ?>" alt="Project Image">
                                            <small>Uploaded: 
                                                <?php echo isset($img['uploaded_at']) 
                                                    ? esc_html($img['uploaded_at']) 
                                                    : ''; ?>
                                            </small>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p>No gallery images found.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- 3) Project Costs & Credit -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Project Costs</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($cost_data)): ?>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Description</th>
                                            <th>Amount</th>
                                            <th>Notes</th>
                                            <th>Bill File</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $total_cost = 0;
                                        foreach ($cost_data as $cost) {
                                            $description = isset($cost['description']) ? $cost['description'] : '';
                                            $amount      = isset($cost['amount']) ? floatval($cost['amount']) : 0;
                                            $notes       = isset($cost['notes']) ? $cost['notes'] : '';
                                            $file_url    = isset($cost['file_url']) ? $cost['file_url'] : '';
                                            $date        = isset($cost['date']) ? $cost['date'] : '';
                                            $total_cost += $amount;
                                            echo "<tr>";
                                            echo "<td>".esc_html($description)."</td>";
                                            echo "<td>$".number_format($amount, 2)."</td>";
                                            echo "<td>".esc_html($notes)."</td>";
                                            if (!empty($file_url)) {
                                                echo "<td><a href='".esc_url($file_url)."' target='_blank'>View File</a></td>";
                                            } else {
                                                echo "<td>-</td>";
                                            }
                                            echo "<td>".esc_html($date)."</td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <p><strong>Total Cost:</strong> $<?php echo number_format($total_cost,2); ?></p>
                            <p><strong>Project Credit:</strong> <?php echo esc_html($project->project_credit); ?></p>
                        <?php else: ?>
                            <p>No cost entries found.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- 4) Project Tools & Materials (Resources) -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Tools & Materials</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($resources_data)): ?>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Item Name</th>
                                            <th>Type</th>
                                            <th>Quantity</th>
                                            <th>Paid or Free</th>
                                            <th>Price</th>
                                            <th>Assigned Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($resources_data as $res): ?>
                                            <tr>
                                                <td><?php echo esc_html($res['item_name'] ?? ''); ?></td>
                                                <td><?php echo esc_html($res['item_type'] ?? ''); ?></td>
                                                <td><?php echo intval($res['quantity'] ?? 0); ?></td>
                                                <td><?php echo esc_html($res['paid_or_free'] ?? ''); ?></td>
                                                <td>
                                                    <?php 
                                                    $price = isset($res['price']) ? floatval($res['price']) : 0;
                                                    echo '$' . number_format($price, 2);
                                                    ?>
                                                </td>
                                                <td><?php echo esc_html($res['date'] ?? ''); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p>No tools or materials assigned yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

            </div> <!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>
</body>
</html>
