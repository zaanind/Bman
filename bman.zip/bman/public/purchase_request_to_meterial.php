<?php
// purchase_request_to_meterial.php - generated script

include_once('bcore.php');


include_once('barcode_lib.php');
// Function to generate a barcode, upload it to the Media Library, and return the attachment ID
function generate_and_upload_barcode($info_id) {
    $upload_dir = wp_upload_dir();
    $barcode_filename = "COMPMAT_" . $info_id . ".png";
    $barcode_path = $upload_dir['path'] . '/' . $barcode_filename;

    // Generate Barcode
    barcode($barcode_path, "COMPMAT_" . $info_id, 100, "horizontal", "code128", false, 3);

    if (!file_exists($barcode_path)) {
        return new WP_Error('barcode_generation_failed', 'Failed to generate barcode.');
    }

    // Upload to Media Library
    $filetype = wp_check_filetype($barcode_filename, null);
    $attachment = array(
        'guid'           => $upload_dir['url'] . '/' . $barcode_filename,
        'post_mime_type' => $filetype['type'],
        'post_title'     => "Barcode for Company Material " . $info_id,
        'post_content'   => '',
        'post_status'    => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $barcode_path);

    if (is_wp_error($attach_id)) {
        return $attach_id;
    }

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $barcode_path);
    wp_update_attachment_metadata($attach_id, $attach_data);

    return $attach_id;
}


$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $item_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Check if the purchase rquest exists
    $sql = $wpdb->prepare("SELECT * FROM wp_zn_met_requests WHERE id = %d;", $item_id);
    $result = $wpdb->get_row($sql);
	
	$met_data = array(
	'item_name' => $result->name,
	'brand_name' => $result->brand,
	'category' => $result->category,
	'location' => 'Company Store',
	'quantity' => $result->quantity,
	'price' => $result->price,
	'exp_date' => $result->expdate,
	'image' => $result->image,
	'item_description' => $result->description,
	'states' => 'Fresh Stock',
	'type' => 'Select',

	
	);
	
	
	$resp = save_comp_material_store($met_data);
	
	$barcode_attachment_id = generate_and_upload_barcode($resp);
	
    $met_data_n = array(
	        'item_id' => $resp,
	        'barcode' => $barcode_attachment_id,
            );
			  
save_comp_material_store($met_data_n);
	
    if (!empty($barcode_attachment_id)) {
		

	
	
	
        // Update the order with the barcode attachment ID
        //$wpdb->update($table_name, ['barcode' => $barcode_attachment_id], ['item_id' => $info_id]);
    }
	


    if ($result) {
        // Delete the purchase rquest
       // $sql = $wpdb->prepare("DELETE FROM wp_zn_met_requests WHERE id = %d;", $item_id);
        //$deleted = $wpdb->query($sql);

        if ($deleted !== false) {
            status_header(200);
            wp_redirect($homeurl . '/inventory/company-materials');
            exit;
        } else {
            echo "Error: sending failed.";
        }
    } else {
        echo "Purchase Rquest not found for ID: " . $item_id;
    }
} else {
    echo 'No ID provided';
}
?>
