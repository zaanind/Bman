<?php  
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator', 'employee');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// Process payment if "Pay" is clicked
if (isset($_GET['do_payment'])) {
    global $wpdb;
    $employee_id = intval($_GET['do_payment']);
    $current_date = date('Y-m-d');

    // Get payment type
    $payment_type = $wpdb->get_var($wpdb->prepare("SELECT payment_type FROM wp_zn_system_employee WHERE employee_id = %d", $employee_id));

    // Calculate next payment date
    $next_payment = 'NULL';
    if ($payment_type === 'weekly') {
        $next_payment = date('Y-m-d', strtotime($current_date . ' +1 week'));
    } elseif ($payment_type === 'monthly') {
        $next_payment = date('Y-m-d', strtotime($current_date . ' +1 month'));
    }

    // Update last_payment and next_payment
    $wpdb->query($wpdb->prepare("
        UPDATE wp_zn_system_employee 
        SET last_payment = %s, next_payment = %s 
        WHERE employee_id = %d
    ", $current_date, $next_payment, $employee_id));

    wp_redirect(get_site_url() . "/accounting/salaries");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos'); 
    $active_sub_m = get_query_var('active_sub_m'); 
    include_once('header.php');
    ?>
    <title>Salaries | <?php echo get_bloginfo('name'); ?></title>
</head>
<body>
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">

                <div class="mb-3">
                    <h1 class="h3 d-inline align-middle">Salaries</h1>
                </div>

                <div class="row">
                    <div class="col-12">        
                        <div class="card">  
                            <div class="card-body">
                                <table id="datatables-reponsive" class="table table-striped" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Email</th>
                                            <th>Hours Worked</th>
                                            <th>Hourly Rate</th>
                                            <th>Total Salary</th>
                                            <th>Last Payment</th>
                                            <th>Next Payment</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        global $wpdb;
                                        $employees = $wpdb->get_results("
                                            SELECT employee_id, email, salary, last_payment, next_payment, payment_type
                                            FROM wp_zn_system_employee
                                        ");
                                        
                                        $today_date = date('Y-m-d');



                                        foreach ($employees as $row) {
                                           
                                            // Get the start date for the period based on payment type (weekly or monthly)
                                            if ($row->payment_type === 'weekly') {
                                                $start_date = date('Y-m-d', strtotime('last Sunday')); // Start of the previous week
                                                $end_date = date('Y-m-d'); // Today
                                            } elseif ($row->payment_type === 'monthly') {
                                                $start_date = date('Y-m-01'); // Start of the current month
                                                $end_date = date('Y-m-d'); // Today
                                            } else {
                                                $start_date = 'No Data';
                                                $end_date = 'No Data';
                                            }
                                        
                                            $salary_data = json_decode($row->salary, true);
                                            $hourly_rate = isset($salary_data['hourly']) ? floatval($salary_data['hourly']) : 0;

                                            $hours_worked = $wpdb->get_var($wpdb->prepare("
                                                SELECT SUM(TIMESTAMPDIFF(HOUR, check_in, check_out)) 
                                                FROM wp_zn_system_attendance 
                                                WHERE employee_id = %d
                                                AND verification = 'admin' 
                                                AND check_in >= %s 
                                                AND check_out <= %s
                                            ", $row->employee_id,$start_date, $end_date));
                                            $hours_worked = $hours_worked ?: 0;

                                            $total_salary = $hourly_rate * $hours_worked;

                                            // Determine last and next salary payment dates
                                            $last_payment_date = $row->last_payment ?: 'No Data';

                                            if ($row->last_payment) {
                                                if ($row->payment_type === 'weekly') {
                                                    $next_payment_date = date('Y-m-d', strtotime($row->last_payment . ' +1 week'));
                                                } elseif ($row->payment_type === 'monthly') {
                                                    $next_payment_date = date('Y-m-d', strtotime($row->last_payment . ' +1 month'));
                                                } else {
                                                    $next_payment_date = 'No Data';
                                                }
                                            } else {
                                                $next_payment_date = 'No Data';
                                            }

                                            // Enable "Pay Now" if:
                                            // - There is no last payment (first-time payment)
                                            // - OR next payment is due today
                                            // - OR next payment is overdue
                                            if (!$row->last_payment || $next_payment_date === $today_date || ($next_payment_date !== 'No Data' && $next_payment_date < $today_date)) {
                                                $pay_link = "<a class='dropdown-item' href='?do_payment=" . $row->employee_id . "'>Pay Now</a>";
                                            } else {
                                                $pay_link = "<span class='dropdown-item text-muted'>Pay (Not Due)</span>";
                                            }

                                            echo "<tr>";
                                                echo "<td>" . esc_html($row->email) . "</td>";
                                                echo "<td>" . esc_html($hours_worked) . "</td>";
                                                echo "<td>$" . esc_html(number_format($hourly_rate, 2)) . "</td>";
                                                echo "<td>$" . esc_html(number_format($total_salary, 2)) . "</td>";
                                                echo "<td>" . esc_html($last_payment_date) . "</td>";
                                                echo "<td>" . esc_html($next_payment_date) . "</td>";
                                                echo "<td>
                                                        <div class='btn-group'>
                                                            <button type='button' class='btn btn-primary dropdown-toggle' data-bs-toggle='dropdown' aria-expanded='false'>
                                                                Actions
                                                            </button>
                                                            <ul class='dropdown-menu'>
                                                                <li>$pay_link</li>
                                                            </ul>
                                                        </div>
                                                      </td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div> 
                        </div> 
                    </div> 
                </div> 
            </div> 
        </main>

        <?php include_once('footer.php'); ?>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    jQuery("#datatables-reponsive").DataTable({
        responsive: true
    });
});
</script>
</body>
</html>
