
	
		<nav id="sidebar" class="sidebar js-sidebar collapsed">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="<?php echo get_site_url(); ?>">
		          <span class="align-middle"><?php echo get_bloginfo( 'name' ); ?></span> </a>



     <!--Load ul menu based on roles-->
			
			
			
    <?php
	
	$current_user = wp_get_current_user();
    $user_roles = $current_user->roles; // Get user roles (array)
	// Define menu files based on roles
    $menu_files = [
       'administrator' => '/menus/admin_sidebar.php',
       'employee' => '/menus/employee_sidebar.php',
	   'salesman' => '/menus/salesman_sidebar.php',
       'editor'        => 'menu-editor.php',

	   ];
	   
	// Find the first matching role
    $menu_file = '/menus/menu-default.php'; // Default menu
    foreach ($user_roles as $role) {
      if (isset($menu_files[$role])) {
        $menu_file = $menu_files[$role];
        break;
       }
    }

	
	// Include the menu file
    include __DIR__ . '/' . $menu_file;

	?>
			
			
			
			<!--end of ul loading-->




				<!--div class="sidebar-cta">
					<div class="sidebar-cta-content">
						<strong class="d-inline-block mb-2">Upgrade to Pro</strong>
						<div class="mb-3 text-sm">
							Are you looking for more components? Check out our premium version.
						</div>
						<div class="d-grid">
							<a href="upgrade-to-pro.html" class="btn btn-primary">Upgrade to Pro</a>
						</div>
					</div>
				</div-->
			</div>
		</nav>