<?php  
$homeurl = get_site_url();  

$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator', 'employee');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

global $wpdb;
$tools_table     = $wpdb->prefix . 'zn_inventory_comp_tools';
$materials_table = $wpdb->prefix . 'zn_inventory_comp_meterials';
$stocks_table    = $wpdb->prefix . 'zn_system_stocks';

if (isset($_GET['id']) && !empty($_GET['id'])) {     
    $stock_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection      

    // Fetch stock details before updating     
    $sql = $wpdb->prepare("SELECT item_id, type, quantity, is_request_passed, checked_at FROM $stocks_table WHERE stock_id = %d;", $stock_id);     
    $stock = $wpdb->get_row($sql);      

    if (!empty($stock)) {         
        $today = current_time('mysql'); // Get current time from MySQL

        // Check if already marked today
        $checked_today = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) FROM $stocks_table 
            WHERE stock_id = %d AND DATE(checked_at) = CURDATE();
        ", $stock_id));

        if ($checked_today == 0) {
            // Update checked_at column with current timestamp
            $wpdb->query($wpdb->prepare("
                UPDATE $stocks_table 
                SET checked_at = %s 
                WHERE stock_id = %d;
            ", $today, $stock_id));
        }


        // Redirect to previous page        
        echo "<script>history.back()</script>";         
        exit;     
    } else {         
        echo "Stock not found.";     
    } 
} else {     
    echo "No ID provided."; 
} 
?>
