<?php 
$homeurl = get_site_url();  


$wpuser_ob = wp_get_current_user();
$allowed_roles = array('administrator',);


$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break; 
    }
}

if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}



$tools_table     = $wpdb->prefix . 'zn_inventory_comp_tools';
$materials_table = $wpdb->prefix . 'zn_inventory_comp_meterials';


if (isset($_GET['id']) && !empty($_GET['id'])) {     
    global $wpdb;     
    $stock_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection      

    // Fetch stock details before updating     
    $sql = $wpdb->prepare("SELECT item_id, type, quantity, is_request_passed FROM {$wpdb->prefix}zn_system_stocks WHERE stock_id = %d;", $stock_id);     
    $stock = $wpdb->get_row($sql);      

    if (!empty($stock)) {         


        // Update is_request_passed to 1 (approve request)
        $updated  = $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}zn_system_stocks SET is_request_passed = 1 WHERE stock_id = %d;", $stock_id));

        if ($updated !== false) {
            if ($stock->type == 'tool') {
                $wpdb->query("UPDATE {$tools_table} SET quantity = quantity - {$stock->quantity} WHERE tool_id = {$stock->item_id}");
            } elseif ($stock->type == 'material') {
                $wpdb->query("UPDATE {$materials_table} SET quantity = quantity - {$stock->quantity} WHERE item_id = {$stock->item_id}");
            }
        } 
        
        // Redirect to previous page        
        echo "<script>history.back()</script>";         
        exit;     
    } else {         
        echo "Stock not found.";     
    } 
} else {     
    echo "No ID provided."; 
} 
?>
