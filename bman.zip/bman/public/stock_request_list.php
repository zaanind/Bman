<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    $active_page = get_query_var('active_page_wp_pos');
    $active_sub_m = get_query_var('active_sub_m');
    include_once('header.php');



    ?>
    <title>Project Stocks | <?php echo get_bloginfo('name'); ?></title>
</head>

<body>
    <div class="wrapper">
        <?php include_once('sidebar.php'); ?>
        <div class="main">
            <?php include_once('navbar.php'); ?>
            <main class="content">
                <div class="container-fluid p-0">
                   
                    <div class="mb-3">
                        <h1 class="h3 d-inline align-middle">Project Stocks </h1>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <table id="datatables-reponsive" class="table table-striped" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Image</th>
                                                <th>Item</th>
                                                <th>Type</th>
                                                <th>Category</th>
                                                <th>Quantity</th>
                                                <th>States</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php
                                            global $wpdb;
                                            $today = date('Y-m-d'); // Get today's date in the correct format
                                            $items = $wpdb->get_results("SELECT * FROM wp_zn_system_stocks ORDER BY is_request_passed ASC");
                                            foreach ($items as $row) {
                                                $image_url = "";
                                                $image_link = json_decode($row->image);
                                                if (isset($image_link->id)) {
                                                    $image = wp_get_attachment_image_src($image_link->id, 'table_90x90');
                                                    $image_url = $image ? $image[0] : ($image_link->url ?? '');
                                                }

                                                // State logic
                                                $state_text = $row->states;
                                                $state_class = "";
     // Daily Check Status
     $checked_today = (!empty($row->checked_at) && date('Y-m-d', strtotime($row->checked_at)) == $today);
     if (!$checked_today) {
         $state_text = "Not Checked Today";
         $state_class = "text-danger";
     }

                                                if ($row->quantity < 1) {
                                                    $state_text = ($row->quantity == 0) ? "Stock End" : "Low Quantity";
                                                    $state_class = "text-danger";
                                                }

                                                if ($row->exp_date && $row->exp_date <= $today) {
                                                    $state_text = "Expired";
                                                    $state_class = "text-danger";
                                                }
                                                 

                                                $approval_item =  (int) $row->is_request_passed;
                                                if ($approval_item <= 0) {
                                                    $state_text = "Pending";
                                                    $state_class = "text-warning";
                                                }

                                                if ($approval_item == 2) {
                                                    $state_text = "Pending Delete";
                                                    $state_class = "text-danger";
                                                }


                                               





                                                echo '<tr>';
                                                echo "<td><image src='" . esc_url($image_url) . "' style='width: 60px;'/></td>";
                                                echo "<td>" . $row->item_name . "</td>";
                                                echo "<td>" . $row->type . "</td>";
                                                echo "<td>" . $row->category . "</td>";
                                                echo "<td>" . $row->quantity . "</td>";
                                                echo "<td class='" . $state_class . "'>" . $state_text. "</td>"; // Add the class to the <td>

                                                echo "<td> <div class='btn-group'> <button type='button' class='btn btn-primary dropdown-toggle' data-bs-toggle='dropdown' aria-expanded='false'>Actions</button> 
                                                <ul class='dropdown-menu'>
                                                <li><a class='dropdown-item' href='" . get_site_url() . "/accounting/stock_requests/view_stock?id=" . $row->stock_id . "'>Info</a></li>
                                                  <li><a class='dropdown-item' href='" . get_site_url() . "/accounting/stock_requests/approve?id=" . $row->stock_id . "'>Approve</a></li>
                                                  <li><a class='dropdown-item' href='" . get_site_url() . "/projects/stocks/delete?id=" . $row->stock_id . "'>Delete</a></li>
                                                </ul></div></td>";

                                                echo '</tr>';
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



            </main>


            <?php include_once('footer.php'); ?>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Datatables Responsive
            $("#datatables-reponsive").DataTable({
                responsive: true

            });
        });
    </script>

</body>

</html>