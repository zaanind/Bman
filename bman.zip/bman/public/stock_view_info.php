<?php
session_start();

// 1) Check user roles
$homeurl = get_site_url();
$wpuser_ob = wp_get_current_user();
// If you want employees to view too, add them here:
$allowed_roles = array('administrator','employee');

$has_allowed_role = false;
foreach ($wpuser_ob->roles as $role) {
    if (in_array($role, $allowed_roles)) {
        $has_allowed_role = true;
        break;
    }
}
if (!$has_allowed_role) {
    status_header(401);
    wp_redirect($homeurl . '/unauthorized');
    exit;
}

// 2) Fetch the material record from DB
global $wpdb;
$table_name = $wpdb->prefix . 'zn_system_stocks'; // Keep the same name used in your insert code

$stock_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$stock_id) {
    // If no ID, go back to listing page
    wp_redirect($homeurl . '/accounting/stock_requests');
    exit;
}

// Get the record
$item = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table_name} WHERE stock_id = %d", $stock_id)
);

$state_text = $item->states;
$state_class = "";
$today = date('Y-m-d');

if ($item->quantity <= 2) {
    $state_text = ($item->quantity == 0) ? "Stock End" : "Low Quantity";
    $state_class = "text-danger";
}

if ($item->exp_date && $item->exp_date <= $today) {
    $state_text = "Expired";
    $state_class = "text-danger";
}


$approval_item =  (int) $item->is_request_passed;
if ($approval_item <= 0) {
    $state_text = "Pending";
    $state_class = "text-warning";
}

if ($approval_item == 2) {
    $state_text = "Pending Delete";
    $state_class = "text-danger";
}

// Daily Check Status
$checked_today = (!empty($item->checked_at) && date('Y-m-d', strtotime($item->checked_at)) == $today);
if (!$checked_today) {
    $state_text = "Not Checked Today";
    $state_class = "text-danger";
}



// If record not found, redirect
if (!$item) {
    wp_redirect($homeurl . '/accounting/stock_requests');
    exit;
}



$active_page = get_query_var('active_page_wp_pos');
$active_sub_m = get_query_var('active_sub_m');
include_once('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Stock Details | <?php echo get_bloginfo('name'); ?></title>

    <style>
    .vertical-steps {
      /* Single border on the entire UL for a continuous line */
      border-left: 3px solid #28a745;
      list-style: none;
      margin-left: 20px;
      margin-top: 10px;
      padding: 0;
      position: relative;
    }

    .vertical-steps li {
      position: relative;
     /* padding: 1rem 1rem 1rem 2.5rem;  extra left padding for circle */
     padding:16px;
    }

    /* Optional spacing between items */
     /* .vertical-steps li + li {
    margin-top: 2rem;
    }*/

    /* The circle for each step */
    .vertical-steps li::before {
      content: "";
      position: absolute;
      /* Center the circle on the left border (which is at x=0) */
      left: -11px;       /* half of circle width (20px / 2) */
      top: 1rem;         /* place circle near the top of each item */
      width: 20px;
      height: 20px;
      border: 2px solid #28a745;
      background-color: #fff;
      border-radius: 50%;
      z-index: 1;        /* circle appears above the line */
    }

    /* Active or completed steps can be filled in green */
    .vertical-steps li.active::before {
      background-color: #28a745;
    }
  </style>
</head>
<body>
    
<div class="wrapper">
    <?php include_once('sidebar.php'); ?>
    <div class="main">
        <?php include_once('navbar.php'); ?>

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3">Stock Details</h1>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Stock Details</h5>
                            </div>
                            <div class="card-body">
                                
                         
                            <!-- Location History Animation -->
                            <div class="mb-3">
                                    <label class="form-label">Location History:</label>
                                    <?php
                                    $locations = json_decode($item->location_history, true); // Decode JSON to an array
                                    
                                    
                                    if (!empty($locations) && is_array($locations)) {
                                        echo '<ul class="vertical-steps">';
                                        foreach ($locations as $location) {

                                            echo '<li class="active"> 
                                            <p> '.$location.' </p>
                                            </li>';
                                        
                                        
                                        } } else {
                                      
                                            echo '<li class="active"> 
                                            <p>No Location History Recorded</p>
                                            </li>';
                                      
                                        }
                                        echo '</ul>';
                                    ?>


<!--ul class="vertical-steps">
    <li class="active">
      <h5>Pickup Location</h5>
      <p>1234 Very Long Street Name, City, State, ZIP</p>
    </li>
    <li class="active">
      <h5>In Transit</h5>
      <p>Warehouse Hub, 5678 Another Long Street, City, State</p>
    </li>
    <li class="active">
      <h5>Out for Delivery</h5>
      <p>Local Distribution Center, 99 Example Rd, City, ZIP</p>
    </li>
    <li class="active">
      <h5>Delivered</h5>
      <p>Customer Address, 1010 Destination Lane, City, ZIP</p>
    </li>
  </ul-->


                                    <!--input type="text" class="form-control"
                                           value="<?php echo esc_html($item->location_history); ?>" 
                                           readonly-->
                                           
                                </div>

                            
                            <!-- Name -->
                                <div class="mb-3">
                                    <label class="form-label">Name:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->item_name); ?>" 
                                           readonly>
                                </div>

                                <!-- Description -->
                                <div class="mb-3">
                                    <label class="form-label">Description:</label>
                                    <textarea class="form-control" rows="3" readonly>
                                        <?php echo esc_textarea($item->product_description); ?>
                                    </textarea>
                                </div>

                                
                                <div class="mb-3">
    <label class="form-label">Expire Date:</label>
    <input type="date" class="form-control" name="expire_date" value="<?php
    if (!empty($item->exp_date) && $item->exp_date !== '0000-00-00') {
        // Format the date to YYYY-MM-DD for HTML5 date input
        $formatted_date = date("Y-m-d", strtotime($item->exp_date));
        echo esc_attr($formatted_date);
    }
    ?>">
</div>

                                <!-- Type -->
                                <div class="mb-3">
                                    <label class="form-label">Type:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->type); ?>" 
                                           readonly>
                                </div>

                                <!-- Color (if you use it) -->
                                <!--div class="mb-3">
                                    <label class="form-label">Color:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->color); ?>" 
                                           readonly>
                                </div-->

                                <!-- Brand -->
                                <div class="mb-3">
                                    <label class="form-label">Brand:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->brand_name); ?>" 
                                           readonly>
                                </div>

                                <!-- Category -->
                                <div class="mb-3">
                                    <label class="form-label">Category:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->category); ?>" 
                                           readonly>
                                </div>

                                <!-- Price -->
                                <div class="mb-3">
                                    <label class="form-label">Price:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->price); ?>" 
                                           readonly>
                                </div>

                                <!-- States -->
                                <div class="mb-3">
                                    <label class="form-label">States:</label>
                                    <input type="text" class="form-control <?php echo $state_class; ?>" value="<?php echo esc_html($state_text); ?>" readonly>
                                </div>

                                <!-- Quantity -->
                                <div class="mb-3">
                                    <label class="form-label">Quantity:</label>
                                    <input type="number" class="form-control"
                                           value="<?php echo esc_html($item->quantity); ?>" 
                                           readonly>
                                </div>

                                             <!-- Location -->
                                <div class="mb-3">
                                    <label class="form-label">Location:</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo esc_html($item->location); ?>" 
                                           readonly>
                                </div>


              

                            </div> <!-- card-body -->
                        </div> <!-- card -->
                    </div> <!-- col-12 -->
                </div> <!-- row -->
            </div> <!-- container-fluid -->
        </main>

        <?php include_once('footer.php'); ?>
    </div> <!-- main -->
</div> <!-- wrapper -->
</body>
</html>