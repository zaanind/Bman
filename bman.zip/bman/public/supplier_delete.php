<?php
// supplier_delete.php - located in the 'public' directory of your plugin

$homeurl = get_site_url();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    global $wpdb;
    $supplier_id = intval($_GET['id']); // Ensure ID is an integer to prevent SQL injection

    // Fetch supplier details (optional, but good practice to check if supplier exists)
    $sql = $wpdb->prepare("SELECT supplier_id FROM wp_pos_system_suppliers WHERE supplier_id = %d;", $supplier_id);
    $result = $wpdb->get_results($sql);

    if (!empty($result)) {
        // Delete the supplier from the database
        $sql = $wpdb->prepare("DELETE FROM wp_pos_system_suppliers WHERE supplier_id = %d;", $supplier_id);
        $wpdb->query($sql);

        status_header(200);
        wp_redirect($homeurl . '/inventory/suppliers');
        exit;
    } else {
        echo "Supplier not found.";
    }
} else {
    echo 'No ID provided';
}
?>
