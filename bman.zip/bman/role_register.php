<?php


function add_manager(){
	$role_name = 'manager';
    $capabilities = array(
        'read' => true,
        'edit_posts' => false,
        'publish_posts' => false,
      
    );


    add_role($role_name, 'Manager', $capabilities);
	
}


function add_employee(){
	$role_name = 'employee';
    $capabilities = array(
        'read' => true,
        'edit_posts' => false,
        'publish_posts' => false,
      
    );

    
    add_role($role_name, 'Employee', $capabilities);
	
}



function add_salesman(){
	$role_name = 'salesman';
    $capabilities = array(
        'read' => true,
        'edit_posts' => false,
        'publish_posts' => false,
      
    );

    
    add_role($role_name, 'Sales Man', $capabilities);
	
}





function add_custom_role() {
add_manager();
add_employee();
add_salesman();

}


//activated via index.php
//add_action('init', 'add_custom_role');


?>